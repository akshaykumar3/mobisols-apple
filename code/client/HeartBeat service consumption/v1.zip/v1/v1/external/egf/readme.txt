Electric Game Framework is a private library written by Grzegorz
Adam Hankiewicz for the purpose of supporting games made by Electric
Hands Software.

The code here is an extract and will be replaced with the full
library once it is open sourced. For more information contact
gradha@elhaso.com.

You are free to use the files of this directory under the BSD license
(http://www.opensource.org/licenses/bsd-license.php) independently
from the full library and whatever its licensing conditions will
be whenever it is released.
