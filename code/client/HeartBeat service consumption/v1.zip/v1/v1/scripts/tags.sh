#!/bin/sh

~/bin/objctags -R external src
