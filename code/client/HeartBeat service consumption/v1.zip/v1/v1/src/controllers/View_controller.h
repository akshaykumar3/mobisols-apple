// vim:tabstop=4 shiftwidth=4 encoding=utf-8 syntax=objc

#import <UIKit/UIKit.h>

@interface View_controller : UIViewController
{
}

- (void)warn:(NSString*)text title:(NSString*)title;

@end
