// vim:tabstop=4 shiftwidth=4 encoding=utf-8 syntax=objc

#import <UIKit/UIKit.h>

@interface Log_tab : UIViewController
{
	UILabel *todo_;
}

- (id)init;

@end
