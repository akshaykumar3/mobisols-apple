Graphical resources are copyrighted by Electric Hands Software 2011.

The eFaber logo on the splash screen is copyrighted by eFaber Soluciones
Inteligentes, S.L. (http://efaber.net/) and is used with permission.

You are not allowed to use any of these graphics without prior
written permission from Grzegorz Adam Hankiewicz or Aritz Albaizar.
