//
//  AppDelegate.h
//  monapp
//
//  Created by Snow Leopard User on 30/06/2011.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#ifdef PHONEGAP_FRAMEWORK
	#import <PhoneGap/PhoneGapDelegate.h>
#else
	#import "PhoneGapDelegate.h"
#endif

@interface AppDelegate : PhoneGapDelegate {

	NSString* invokeString;
	
	BOOL abort_after_alert_;
}

// invoke string is passed to your app on launch, this is only valid if you 
// edit monapp.plist to add a protocol
// a simple tutorial can be found here : 
// http://iphonedevelopertips.com/cocoa/launching-your-own-application-via-a-custom-url-scheme.html

@property (copy)  NSString* invokeString;
- (void)handle_error:(NSString*)message do_abort:(BOOL)do_abort;
@end

/// Read these variables to know what is supported on the device.
extern BOOL g_is_multitasking;
extern BOOL g_location_changes;
extern BOOL g_region_monitoring;

