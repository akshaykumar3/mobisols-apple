//
//  AppDelegate.m
//  monapp
//
//  Created by Snow Leopard User on 30/06/2011.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "AppDelegate.h"
#import "GPS.h"
#import "macro.h"
#import "RPReachability.h"

#ifdef PHONEGAP_FRAMEWORK
	#import <PhoneGap/PhoneGapViewController.h>
#else
	#import "PhoneGapViewController.h"
#endif

static NSString *REACH_HOST = @"github.com";


static void _set_globals(void);
@implementation AppDelegate

@synthesize invokeString;
#pragma mark -
#pragma mark Application lifecycle
- (id) init
{	
	/** If you need to do any extra app-specific initialization, you can do it here
	 *  -jm
	 **/
    return [super init];
}



/**
 * This is main kick off after the app inits, the views and Settings are setup here. (preferred - iOS4 and up)
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	printf("launching application\n");
	[[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
	_set_globals();
	
	/** Set up the reachability class. This works slowly, so let it be first. */
	[RPReachability init_with_host:REACH_HOST];

	NSArray *keyArray = [launchOptions allKeys];
	if ([launchOptions objectForKey:[keyArray objectAtIndex:0]]!=nil) 
	{
		NSURL *url = [launchOptions objectForKey:[keyArray objectAtIndex:0]];
		self.invokeString = [url absoluteString];
		NSLog(@"monapp launchOptions = %@",url);
	}
	
	return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

// this happens while we are running ( in the background, or from within our own app )
// only valid if monapp.plist specifies a protocol to handle
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url 
{
	 // Do something with the url here
	NSString* jsString = [NSString stringWithFormat:@"handleOpenURL(\"%@\");", url];
	[self.webView stringByEvaluatingJavaScriptFromString:jsString];
	
	return YES;
}

-(id) getCommandInstance:(NSString*)className
{
	/** You can catch your own commands here, if you wanted to extend the gap: protocol, or add your
	 *  own app specific protocol to it. -jm
	 **/
	return [super getCommandInstance:className];
}

/**
 Called when the webview finishes loading.  This stops the activity view and closes the imageview
 */
- (void)webViewDidFinishLoad:(UIWebView *)theWebView 
{
	// only valid if monapp.plist specifies a protocol to handle
	if(self.invokeString)
	{
		// this is passed before the deviceready event is fired, so you can access it in js when you receive deviceready
		NSString* jsString = [NSString stringWithFormat:@"var invokeString = \"%@\";", self.invokeString];
		[theWebView stringByEvaluatingJavaScriptFromString:jsString];
	}
	return [ super webViewDidFinishLoad:theWebView ];
}

- (void)webViewDidStartLoad:(UIWebView *)theWebView 
{
	return [ super webViewDidStartLoad:theWebView ];
}

/**
 * Fail Loading With Error
 * Error - If the webpage failed to load display an error with the reason.
 */
- (void)webView:(UIWebView *)theWebView didFailLoadWithError:(NSError *)error 
{
	return [ super webView:theWebView didFailLoadWithError:error ];
}

/**
 * Start Loading Request
 * This is where most of the magic happens... We take the request(s) and process the response.
 * From here we can re direct links and other protocalls to different internal methods.
 */
- (BOOL)webView:(UIWebView *)theWebView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	return [ super webView:theWebView shouldStartLoadWithRequest:request navigationType:navigationType ];
}


- (BOOL) execute:(InvokedUrlCommand*)command
{
	return [ super execute:command];
}


/** Something stole the focus of the application.
 * Or the user might have locked the screen. Change to medium gps tracking.
 */
- (void)applicationWillResignActive:(UIApplication *)application
{
	[[GPS get] set_accuracy:MEDIUM_ACCURACY reason:@"Lost focus."];
	printf("Application is in medium accuracy\n");
}

/** The application regained focus.
 * This is the pair to applicationWillResignActive.
 */
- (void)applicationWillEnterForeground:(UIApplication *)application
{
	[[GPS get] set_accuracy:HIGH_ACCURACY reason:@"Gained focus."];
	printf("AppDelegate.m: ForeGroundMode is on, Application enter HIGH_ACCURACY\n");
}

/** The user quit the app, and we are supporting background operation.
 * Suspend GUI dependant timers and log status change.
 *
 * This method is only called if the app is running on a device
 * supporting background operation. Otherwise applicationWillTerminate
 * will be called instead.
 */
- (void)applicationDidEnterBackground:(UIApplication *)application
{
	[[GPS get] set_accuracy:LOW_ACCURACY reason:@"Entering background mode."];
	// Give notification to user that the app entered backgrond mode.
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle: @"Alert"
						  message: @"Application entered background mode"
						  delegate: nil
						  cancelButtonTitle:@"Dismiss"
						  otherButtonTitles:nil];
	[alert show];
	//[alert release];
	
	printf("AppDelegate.m: BackGroundMode is on, Application entered LOW_ACCURACY\n");
}

/** We were raised from the dead.
 * Revert bad stuff done in applicationDidEnterBackground to be nice.
 */
- (void)applicationDidBecomeActive:(UIApplication *)application
{
	[[GPS get] set_accuracy:HIGH_ACCURACY reason:@"Raising from background."];
	printf("Application is active\n");
}

/** Application shutdown. Save cache and stuff...
 * Note that the method could be called even during initialisation,
 * so you can't make any guarantees about objects being available.
 *
 * If background running is supported, applicationDidEnterBackground
 * is used instead.
 */
- (void)applicationWillTerminate:(UIApplication *)application
{
	printf("Application is terminated by the User\n");
	if ([GPS get].gps_is_on)
		//[db_ log:@"Terminating app while GPS was on..."];
		printf("terminated while gps is on\n");
	//[db_ flush];
	//[db_ close];
	
	// Save pending changes to user defaults.
	//NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	//[defaults synchronize];
}

#pragma mark -
#pragma mark Memory management

/** Low on memory. Try to free as much as we can.
 */
/*
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
	[db_ flush];
}
 */
-(void)dealloc
{
	[ super dealloc ];
}

#pragma mark Normal methods
- (void)handle_error:(NSString*)message do_abort:(BOOL)do_abort
{
	if (do_abort)
		abort_after_alert_ = YES;
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
													message:NON_NIL_STRING(message) delegate:self
										  cancelButtonTitle:(do_abort ? @"Abort" : @"OK") otherButtonTitles:nil];
	[alert show];
	[alert release];
	//DLOG(@"Error: %@", message);
}

#pragma mark UIAlertViewDelegate protocol

- (void)alertView:(UIAlertView *)alertView
clickedButtonAtIndex:(NSInteger)buttonIndex
{
	//if (abort_after_alert_) {
	//	DLOG(@"User closed dialog which aborts program. Bye bye!");
		exit(1);
	
}

@end
#pragma mark Global functions

BOOL g_is_multitasking = NO;
BOOL g_location_changes = NO;
BOOL g_region_monitoring = NO;


/** Updates the state of some global variables.
 * These are variables like g_is_multitasking, which can be read
 * by any one any time. Call this function whenever you want,
 * preferably during startup.
 */
static void _set_globals(void)
{
	UIDevice* device = [UIDevice currentDevice];
	
	if ([device respondsToSelector:@selector(isMultitaskingSupported)])
		g_is_multitasking = device.multitaskingSupported;
	else
		g_is_multitasking = NO;
	
	g_location_changes = NO;
	SEL getter = @selector(significantLocationChangeMonitoringAvailable);
	if ([CLLocationManager respondsToSelector:getter])
		if ([CLLocationManager performSelector:getter])
			g_location_changes = YES;
	
	getter = @selector(regionMonitoringAvailable);
	if ([CLLocationManager respondsToSelector:getter])
		if ([CLLocationManager performSelector:getter])
			g_region_monitoring = YES;
}

// vim:tabstop=4 shiftwidth=4 syntax=objc
