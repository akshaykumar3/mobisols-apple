gtp.dict = {
	"dev_reg_errormsg": "Could not connect to server",
	"loginform_username": "UserName Required",
	"loginform_password": "Password Required",
	"loginform_pwd_fail": "Password do not match",
	"login_failure": "Incorrect Username or Password",
	"regform_invalidemail": "Enter valid email ID",
	"regform_pwds": "Passwords do not match",
	"newcar_success": "Added Vehicle Successfully",
	"newcar_failure": "Error, Failed adding a car",
	"updatecar_success": "Updated car Successfully",
	"updatecar_failure": "Error updating the car",
	"deletecar_success": "Removed car successfully",
	"deletecar_failure": "Error deleting the car",
	"datevalidity": "Invalid end date",
	"Activated": "Settings are saved, Active car is",
	"vd-updated": "Updated vehicle details",
	"deletevehicle": "Removed car successfully"
};