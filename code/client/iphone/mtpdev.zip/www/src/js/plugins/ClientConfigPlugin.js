var ClientConfigPlugin = function(){
    
};

ClientConfigPlugin.prototype.getClientConfig = function() {
    // discuss and implement.
};

ClientConfigPlugin.prototype.setClientConfig = function(config){
    // config is encoded json.
    console.log('client config plugin invoked in javascript');
    PhoneGap.exec('ClientConfig.setConfiguration', config);
}; 

PhoneGap.addConstructor(function() {
    if(!window.plugins) {
        console.log('window.plugins created');
        window.plugins = {};
    }
    window.plugins.ClientConfig = new ClientConfigPlugin();
    return window.plugins.ClientConfig;
});