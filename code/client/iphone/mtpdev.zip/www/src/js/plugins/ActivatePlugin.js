var ActivatePlugin = function(){
    
}

ActivatePlugin.prototype.activate = function() {
    console.log('activate plugin is invoked from javascript');
    PhoneGap.exec('Activate.setActive'); 
   }

ActivatePlugin.prototype.deactivate = function(){
    PhoneGap.exec('Activate.setInactive');
}

PhoneGap.addConstructor(function() {
    if(!window.plugins) {
        console.log('ActiPlug window.plugins created');
        window.plugins = {};
    }
    window.plugins.ActivatePlugin = new ActivatePlugin();
    return window.plugins.ActivatePlugin;
});
