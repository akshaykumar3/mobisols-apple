var TollDetailsPlugin = function(){
    
};

TollDetailsPlugin.prototype.setDetails = function(encodedJson){
    PhoneGap.exec('TollLocations.setTollDetails', encodedJson); 
};   

PhoneGap.addConstructor(function() {
    if(!window.plugins) 
        window.plugins = {};
    window.plugins.TollDetailsPlugin= new TollDetailsPlugin();
    return window.plugins.TollDetailsPlugin;
});