var DeviceDetailsPlugin = function(){
    
};

DeviceDetailsPlugin.prototype.getValue = function() {
    // need to discuss and code.
};

DeviceDetailsPlugin.prototype.setDetails = function(encodedJson){
    console.log(' dev details plugin javascript invoked');
    PhoneGap.exec('DeviceDetails.setDetails', encodedJson); 
};   

PhoneGap.addConstructor(function() {
    if(!window.plugins) {
        console.log('window.plugins created');
        window.plugins = {};
    }
    window.plugins.DeviceDetailsPlugin= new DeviceDetailsPlugin();
    return window.plugins.DeviceDetailsPlugin;
});