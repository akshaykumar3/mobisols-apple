//
//  ClientConfig.h
//  mtpdev
//
//  Created by Harish Balijepalli on 10/24/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "PhoneGapCommand.h"

@interface ClientConfig:PhoneGapCommand {
    
}

- (void) setConfiguration:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options;
@end