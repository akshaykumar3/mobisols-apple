#import "TollLocations.h"
#import "Singleton.h"
#import "JSONKit.h"
#include <stdio.h>

@implementation TollLocations

-(void) setTollDetails:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options
{
    printf("toll details invoked from native code\n");
    NSData *temps = [[arguments objectAtIndex:0] dataUsingEncoding:NSUTF8StringEncoding];
    JSONDecoder *jsonKitDecoder = [JSONDecoder decoder];
    NSArray *resobj = [jsonKitDecoder objectWithData:temps];
    [[Singleton instance] setToll_locs:resobj];
    NSLog(@"Toll details count from native code %d", [resobj count]);
}

@end