#import "Activate.h"
#import "Singleton.h"
#import "AppDelegate.h"
#include <stdio.h>

@implementation Activate

-(void) setActive:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options
{
    // invoke heart beat here.
	[[Singleton instance] setAppState:true];
    printf("App is enabled and heartbeat is invoked\n");
    [(CLLocationManager*)[Singleton instance].locationManager startUpdatingLocation];
}

-(void) setInactive:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options
{
   	[[Singleton instance] setAppState:false];
    printf("App is disabled\n");
}

@end