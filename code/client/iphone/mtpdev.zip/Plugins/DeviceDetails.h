//
//  DeviceDetails.h
//  mtpdev
//
//  Created by Harish Balijepalli on 10/24/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PhoneGapCommand.h"

@interface DeviceDetails:PhoneGapCommand {
    
}

- (void) setDetails:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options;

@end