
#import "DeviceDetails.h"
#import "Singleton.h"
#import "JSONKit.h"
#include <stdio.h>



@implementation DeviceDetails

-(void) setDetails:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options
{
    printf("device details plugin invoked\n");
    NSLog(@"received data %@",[arguments objectAtIndex:0]);
    NSData *temps = [[arguments objectAtIndex:0] dataUsingEncoding:NSUTF8StringEncoding];
    JSONDecoder *jsonKitDecoder = [JSONDecoder decoder];
    NSDictionary *resobj = [jsonKitDecoder objectWithData:temps];
    NSLog(@"received password %@", [resobj objectForKey:@"password"]);
    [[Singleton instance] setDevDetails:resobj];
    NSLog(@"%@",[[[Singleton instance] devDetails] objectForKey:@"username"]);
}

@end