

#import "Singleton.h"

@implementation Singleton

static Singleton *ins;

@synthesize locationManager;
@synthesize devDetails;
@synthesize config;
@synthesize toll_locs;
@synthesize AppState;

// #pragma mark Singleton Methods
+ (Singleton *)instance {
    
    if(!ins) {
       ins = [[Singleton alloc] init];
    }
    return ins;
}

-(id)init {
    // Can do any initializations here.
    return self;
}

// todo deallocate -memory management

@end