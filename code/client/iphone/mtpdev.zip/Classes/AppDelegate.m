//
//  AppDelegate.m
//  mtpdev
//
//  Created by Snow Leopard User on 18/10/2011.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "AppDelegate.h"
#import "ASIHTTPRequest.h"
#import "JSONKit.h"
#import "Singleton.h"
#ifdef PHONEGAP_FRAMEWORK
	#import <PhoneGap/PhoneGapViewController.h>
#else
	#import "PhoneGapViewController.h"
#endif

@implementation AppDelegate

@synthesize invokeString;

- (id) init
{	
	/** If you need to do any extra app-specific initialization, you can do it here
	 *  -jm
	 **/
	//td = [[NSMutableArray alloc] init];
    return [super init];
}

/**
 * This is main kick off after the app inits, the views and Settings are setup here. (preferred - iOS4 and up)
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	
	NSArray *keyArray = [launchOptions allKeys];
	if ([launchOptions objectForKey:[keyArray objectAtIndex:0]]!=nil) 
	{
		NSURL *url = [launchOptions objectForKey:[keyArray objectAtIndex:0]];
		self.invokeString = [url absoluteString];
		NSLog(@"mtpdev launchOptions = %@",url);
	}
	//TODO -  if(locationmanager.locationServicesEnabled == NO) - show alert to user
	locationManager = [[CLLocationManager alloc] init];
	locationManager.delegate = self;
	locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
	locationManager.desiredAccuracy = kCLLocationAccuracyBest; 
	
    [[Singleton instance] setLocationManager:locationManager];
	
	/*NSURL *url2 = [NSURL URLWithString:@"http://mbtest.dyndns.dk:6004/devserver/services/TollDetailsList"];
	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url2];
	
	//TODO - get username and pwd from the shared store
	[request setUsername:@"harish@mobisols.com"];
	[request setPassword:@"mobisols"];
	[request startSynchronous];
	NSError *error = [request error];
	if (!error) {
		NSData *response = [request responseData];
		//NSLog(@"test response - %@",response);
		//store toll location to an object
		JSONDecoder *jsonKitDecoder = [JSONDecoder decoder];
		NSDictionary *resobj = [jsonKitDecoder objectWithData:response];
		NSLog(@"total count: %d", [resobj count]);
		
		NSDictionary *temp = [resobj objectForKey:@"response"];
		[toll_det autorelease];
		toll_det = [[temp objectForKey:@"tollDetailsList"] retain];
        [[Singleton instance] setToll_locs:[temp objectForKey:@"tollDetailsList"]];
		NSLog(@"total toll locations count %d", [toll_det count]);
		
		//[locationManager startUpdatingLocation];
		//[self doHeartBeat];
				
		//Do region monitoring for the 50% distance of current location from the nearest toll
		//When the region monitoring call back(didEnterRegion),stopRegionMonioring do (1) again
		//give notification to user if the nearest toll is < 100 meters
	}*/
		
	//
	return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

// Finds nearest toll based on current location
- (void)doHeartBeat {
    
    NSArray *toll_det = [[Singleton instance] toll_locs];
	printf("heart beat function invoked\n");
	
	// nearestTollIndex stores the nearest toll's index.
	int i,min_dis = 40000000, nearestTollIndex=0, tdcount;
	tdcount = [toll_det count];
	for(i = 0; i < tdcount; i++) {
		NSDictionary *obj = [toll_det objectAtIndex:i];
		CLLocation *tempPoint;
		double lat = [[obj valueForKey:@"latitude"] doubleValue];
		double lng = [[obj valueForKey:@"longitude"] doubleValue];
		tempPoint = [[CLLocation alloc] initWithLatitude:lat longitude:lng];
		
		if([last_pos distanceFromLocation:tempPoint] < min_dis) {
			nearestTollIndex = i;
			min_dis = [last_pos distanceFromLocation:tempPoint];
		}			
		//NSLog(@" lat is %@, long is %@ ", [obj valueForKey:@"latitude"], [obj valueForKey:@"longitude"]);
	}
	
	printf("nearest toll location index from heart beat is %d, minimum distance is %d\n",nearestTollIndex,min_dis);
	
	// Display notification if minimum distance is less than 50m(dis is fetched from configuration).
	if (min_dis<100) {
		
		[self showNotification : @"You crossed a toll"];
		
		if([[toll_det objectAtIndex:nearestTollIndex] valueForKey :@"isCovered"]==@"Y")
		{	
			[self showNotification : @"You crossed a toll"];
			// Todo synchronous server call to store the heart beat.
			
		}
		else {
			[self showNotification : @"Toll is not covered"];
		}

	}
	
	double lat = [[[toll_det objectAtIndex:nearestTollIndex] valueForKey:@"latitude"] doubleValue];
	double lng = [[[toll_det objectAtIndex:nearestTollIndex] valueForKey:@"longitude"] doubleValue];
	CLLocationCoordinate2D loc = CLLocationCoordinate2DMake(lat, lng); 
	CLRegion *region = [[CLRegion alloc] initCircularRegionWithCenter:loc radius:(min_dis/2) identifier:@"curloc"];
	[locationManager startMonitoringForRegion:region desiredAccuracy:kCLLocationAccuracyBest];
	[region release];
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
	printf("From didUpdateToLocation latitude=%f, longitude=%f\n",newLocation.coordinate.latitude, newLocation.coordinate.longitude);
	// Save the recently fetched coordinates.
	[last_pos autorelease];
	 last_pos = [newLocation retain];
	[locationManager stopUpdatingLocation];
	// Repeat heartbeat.
	[self doHeartBeat];
}

-(void) locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"loc_man failed error: %@", [error description]);
}

- (void) locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region     {
    NSLog(@"Exited Region, App state is %d", [[Singleton instance] AppState]);
	// Stop monitoring for that region.
	[locationManager stopMonitoringForRegion:region];
    if([[Singleton instance] AppState] == 1)
	[locationManager startUpdatingLocation];
	
}
// this happens while we are running ( in the background, or from within our own app )
// only valid if mtpdev.plist specifies a protocol to handle
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url 
{
	// Do something with the url here
	NSString* jsString = [NSString stringWithFormat:@"handleOpenURL(\"%@\");", url];
	[self.webView stringByEvaluatingJavaScriptFromString:jsString];
	
	return YES;
}

-(id) getCommandInstance:(NSString*)className
{
	/** You can catch your own commands here, if you wanted to extend the gap: protocol, or add your
	 *  own app specific protocol to it. -jm
	 **/
	return [super getCommandInstance:className];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	// [[GPS get] set_accuracy:LOW_ACCURACY reason:@"Entering background mode."];
	printf("AppDelegate.m: BackGroundMode is on, Application entered LOW_ACCURACY\n");
	
	dataWebService = [[NSMutableData data] retain];
	NSURL *url = [NSURL URLWithString:@"http://mbtest.dyndns.dk:6004/tstserver/services/VehicleTypeList"];
	NSMutableURLRequest *request = [[NSMutableURLRequest requestWithURL:url] retain];
    NSURLConnection *myConnection = [NSURLConnection connectionWithRequest:request delegate:self];
    
    [myConnection start];
	//[self doHeartBeat];
	//[self showNotification:@"I am from background"];
	printf("End of applicationDidEnterBackground method.\n");
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [dataWebService setLength:0];
	printf("1: didReceiveResponse triggered\n");
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [dataWebService appendData:data];
	printf("2: didReceiveData triggered\n");
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    NSString *responseString = [[NSString alloc] initWithData:dataWebService encoding:NSUTF8StringEncoding];
    
    NSLog(@"Response: %@",responseString);
    
    [responseString release];
    
    [dataWebService release];
	printf("3: connectionDidFinishLoading triggered and response Fetched\n");

}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"Eror during connection: %@", [error description]);
}
/**
 Called when the webview finishes loading.  This stops the activity view and closes the imageview
 */
- (void)webViewDidFinishLoad:(UIWebView *)theWebView 
{
	// only valid if mtpdev.plist specifies a protocol to handle
	if(self.invokeString)
	{
		// this is passed before the deviceready event is fired, so you can access it in js when you receive deviceready
		NSString* jsString = [NSString stringWithFormat:@"var invokeString = \"%@\";", self.invokeString];
		[theWebView stringByEvaluatingJavaScriptFromString:jsString];
	}
	return [ super webViewDidFinishLoad:theWebView ];
}

- (void)webViewDidStartLoad:(UIWebView *)theWebView 
{
	return [ super webViewDidStartLoad:theWebView ];
}

/**
 * Fail Loading With Error
 * Error - If the webpage failed to load display an error with the reason.
 */
- (void)webView:(UIWebView *)theWebView didFailLoadWithError:(NSError *)error 
{
	return [ super webView:theWebView didFailLoadWithError:error ];
}

/**
 * Start Loading Request
 * This is where most of the magic happens... We take the request(s) and process the response.
 * From here we can re direct links and other protocalls to different internal methods.
 */
- (BOOL)webView:(UIWebView *)theWebView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	return [ super webView:theWebView shouldStartLoadWithRequest:request navigationType:navigationType ];
}


- (BOOL) execute:(InvokedUrlCommand*)command
{
	return [ super execute:command];
}

- (void)dealloc
{
	[ super dealloc ];
}

-(void) showNotification: (NSString*)msg {
	
	/* Here we cancel all previously scheduled notifications */
	[[UIApplication sharedApplication] cancelAllLocalNotifications];
	
	UILocalNotification *localNotification = [[UILocalNotification alloc] init];
	
	localNotification.fireDate = [[NSDate alloc] init];
	NSLog(@"Notification will be shown on: %@",localNotification.fireDate);
	
	localNotification.timeZone = [NSTimeZone defaultTimeZone];
	localNotification.alertBody = msg;
	localNotification.alertAction = NSLocalizedString(@"View details", nil);
	
	/* Here we set notification sound and badge on the app's icon "-1" 
	 means that number indicator on the badge will be decreased by one 
	 - so there will be no badge on the icon */
	
	localNotification.soundName = UILocalNotificationDefaultSoundName;
	localNotification.applicationIconBadgeNumber = -1;
	
	[[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}

@end
