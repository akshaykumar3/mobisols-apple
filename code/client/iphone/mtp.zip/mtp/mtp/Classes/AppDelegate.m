//
//  AppDelegate.m
//  mtpdev
//
//  Created by Snow Leopard User on 18/10/2011.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "AppDelegate.h"
#import "ASIFormDataRequest.h"
#import "JSONKit.h"

#import "Singleton.h"
#ifdef PHONEGAP_FRAMEWORK
#import <PhoneGap/PhoneGapViewController.h>
#else
#import "PhoneGapViewController.h"
#endif

#define kTransitionDuration	0.75    // for the flip view animation

#pragma mark -

@implementation AppDelegate

@synthesize invokeString;

- (id) init
{	
	/** If you need to do any extra app-specific initialization, you can do it here
	 *  -jm
	 **/
	//td = [[NSMutableArray alloc] init];
    lastCoveredTollIndex = -1;
    return [super init];
}

/**
 * This is main kick off after the app inits, the views and Settings are setup here. (preferred - iOS4 and up)
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	
	NSArray *keyArray = [launchOptions allKeys];
	if ([launchOptions objectForKey:[keyArray objectAtIndex:0]]!=nil) 
	{
		NSURL *url = [launchOptions objectForKey:[keyArray objectAtIndex:0]];
		self.invokeString = [url absoluteString];
		NSLog(@"mtpdev launchOptions = %@",url);
	}
	//TODO -  if(locationmanager.locationServicesEnabled == NO) - show alert to user
/*    
#ifdef FAKE_CORE_LOCATION
    locationManager = [[[FTLocationSimulator alloc] init] autorelease];
#else
    locationManager = [[[CLLocationManager alloc] init] autorelease];
#endif
*/
	locationManager = [[CLLocationManager alloc] init];
	locationManager.delegate = self;
	locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
	locationManager.desiredAccuracy = kCLLocationAccuracyBest; 
	
    [[Singleton instance] setLocationManager:locationManager];
    isSigLocUpdate = false;
    
	return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Memory management. Deallocating.
    NSLog(@"Application is terminated");
}

// Finds nearest toll based on current location
- (void)doHeartBeat {
    
    //[self serverHeartBeat : @"HB"];
    
    NSArray *toll_det = [[Singleton instance] toll_locs];
    
	// nearestTollIndex stores the nearest toll's index.
	int i,min_dis = 40000000, nearestTollIndex=0, tdcount;
	tdcount = [toll_det count];
	for(i = 0; i < tdcount; i++) {
		NSDictionary *obj = [toll_det objectAtIndex:i];
		CLLocation *tempPoint;
		double lat = [[obj valueForKey:@"latitude"] doubleValue];
		double lng = [[obj valueForKey:@"longitude"] doubleValue];
		tempPoint = [[CLLocation alloc] initWithLatitude:lat longitude:lng];
		
		if([last_pos distanceFromLocation:tempPoint] < min_dis) {
			nearestTollIndex = i;
			min_dis = [last_pos distanceFromLocation:tempPoint];
		}			

	}
	
	printf("last toll - %d, nearest -  %d, minimum distance is %d\n",lastCoveredTollIndex,nearestTollIndex,min_dis);
    NSLog(@"lat =%lf long=%lf",last_pos.coordinate.latitude,last_pos.coordinate.longitude);
	
	// Display notification if minimum distance is less than 200m(dis is fetched from configuration).
	if (min_dis < 200 && lastCoveredTollIndex!=nearestTollIndex) {
        
		NSString *tMsg = [NSString stringWithFormat:@"Toll cost=$%d",nearestTollIndex];
        NSLog(@"Toll covered status is %@", [[toll_det objectAtIndex:nearestTollIndex] valueForKey:@"isCovered"]);
		
		if([[[toll_det objectAtIndex:nearestTollIndex] valueForKey :@"isCovered"] isEqualToString:@"Y"])
		{	
			// Todo synchronous server call to store the heart beat.
            [self showNotification :tMsg];
		}
		else
        {
            [self showNotification : @"Sorry. Toll is not covered"];
        }
        [self serverHeartBeat : @"TC"];
        lastCoveredTollIndex = nearestTollIndex;   
	}
    if(min_dis > 200 && lastCoveredTollIndex == nearestTollIndex)
    {
        lastCoveredTollIndex = -1;
    }
    if(min_dis > 2500 &&! isSigLocUpdate)
    {
        NSLog(@"Switching to significant updates");
        
        [(CLLocationManager*)[Singleton instance].locationManager stopUpdatingLocation];
        [(CLLocationManager*)[Singleton instance].locationManager startMonitoringSignificantLocationChanges];
        isSigLocUpdate = true;
        
        [self showNotification:@"Significant GPS"];
        [self serverHeartBeat : @"SHB"];
    }
    else if(min_dis <=2500 && isSigLocUpdate)
    {
        NSLog(@"Switching to continuous updates");
        [(CLLocationManager*)[Singleton instance].locationManager stopMonitoringSignificantLocationChanges];
        [(CLLocationManager*)[Singleton instance].locationManager startUpdatingLocation];
        isSigLocUpdate = false;
        
        [self showNotification:@"Continuous GPS"];
        [self serverHeartBeat : @"CHB"];
    }
    
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
	// Save the recently fetched coordinates.
	[last_pos autorelease];
    last_pos = [newLocation retain];
    
	// start doing heart beat.
	[self doHeartBeat];
}

-(void) locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"loc_man failed error: %@", [error description]);
}

-(void) locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region {
    // Check wheter this event is fired if region is created around current location.
    NSLog(@"Entered region");
}

- (void) locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region     {
    NSLog(@"Exited Region, App state is %d", [[Singleton instance] AppState]);
	// Stop monitoring for that region.
	[locationManager stopMonitoringForRegion:region];
    if([[Singleton instance] AppState] == 1) {
        [locationManager startUpdatingLocation];
        NSLog(@"location update started");
    }
	
}
// this happens while we are running ( in the background, or from within our own app )
// only valid if mtpdev.plist specifies a protocol to handle
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url 
{
	// Do something with the url here
	NSString* jsString = [NSString stringWithFormat:@"handleOpenURL(\"%@\");", url];
	[self.webView stringByEvaluatingJavaScriptFromString:jsString];
	
	return YES;
}

-(id) getCommandInstance:(NSString*)className
{
	/** You can catch your own commands here, if you wanted to extend the gap: protocol, or add your
	 *  own app specific protocol to it. -jm
	 **/
	return [super getCommandInstance:className];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // todo Change accuracy to low if toll is significantly away from tolls.
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [dataWebService setLength:0];
	printf("1: didReceiveResponse triggered\n");
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [dataWebService appendData:data];
	printf("2: didReceiveData triggered\n");
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    NSString *responseString = [[NSString alloc] initWithData:dataWebService encoding:NSUTF8StringEncoding];
    
    NSLog(@"Response: %@",responseString);
    
    [responseString release];
    
    [dataWebService release];
	printf("3: connectionDidFinishLoading triggered and response Fetched\n");
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"Eror during connection: %@", [error description]);
}
/**
 Called when the webview finishes loading.  This stops the activity view and closes the imageview
 */
- (void)webViewDidFinishLoad:(UIWebView *)theWebView 
{
	// only valid if mtpdev.plist specifies a protocol to handle
	if(self.invokeString)
	{
		// this is passed before the deviceready event is fired, so you can access it in js when you receive deviceready
		NSString* jsString = [NSString stringWithFormat:@"var invokeString = \"%@\";", self.invokeString];
		[theWebView stringByEvaluatingJavaScriptFromString:jsString];
	}
	return [ super webViewDidFinishLoad:theWebView ];
}

- (void)webViewDidStartLoad:(UIWebView *)theWebView 
{
	return [ super webViewDidStartLoad:theWebView ];
}

/**
 * Fail Loading With Error
 * Error - If the webpage failed to load display an error with the reason.
 */
- (void)webView:(UIWebView *)theWebView didFailLoadWithError:(NSError *)error 
{
	return [ super webView:theWebView didFailLoadWithError:error ];
}

/**
 * Start Loading Request
 * This is where most of the magic happens... We take the request(s) and process the response.
 * From here we can re direct links and other protocalls to different internal methods.
 */
- (BOOL)webView:(UIWebView *)theWebView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	return [ super webView:theWebView shouldStartLoadWithRequest:request navigationType:navigationType ];
}


- (BOOL) execute:(InvokedUrlCommand*)command
{
	return [ super execute:command];
}

- (void)dealloc
{
	[ super dealloc ];
}

- (void) serverHeartBeat :(NSString *) type
{
    
    NSLog(@"server hearbeat invoked");
    NSURL *url = [NSURL URLWithString:@"http://mbtest.dyndns.dk:6004/devserver/services/secure/HeartBeat"];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    NSString *latitude = [NSString stringWithFormat:@"%lf", last_pos.coordinate.latitude];
    
    NSString *longitude = [NSString stringWithFormat:@"%lf", last_pos.coordinate.longitude];
    NSString *postString = @"{";
    
    postString = [postString stringByAppendingString:@"\"deviceId\":\""];
    postString = [postString stringByAppendingString:[[[Singleton instance] devDetails] objectForKey:@"deviceId"]];
    postString = [postString stringByAppendingString:@"\","];
    
    postString = [postString stringByAppendingString:@"\"deviceType\":\""];
    postString = [postString stringByAppendingString:@"iPhone"];
    postString = [postString stringByAppendingString:@"\","];
    
    postString = [postString stringByAppendingString:@"\"latitude\":\""];
    postString = [postString stringByAppendingString:
                  latitude];
    postString = [postString stringByAppendingString:@"\","];
    
    postString = [postString stringByAppendingString:@"\"longitude\":\""];
    postString = [postString stringByAppendingString:longitude];
    postString = [postString stringByAppendingString:@"\","];
    
    postString = [postString stringByAppendingString:@"\"angle\":\""];
    postString = [postString stringByAppendingString:@"0"];
    postString = [postString stringByAppendingString:@"\","];
    
    postString = [postString stringByAppendingString:@"\"vmlType\":\""];
    postString = [postString stringByAppendingString:type];
    postString = [postString stringByAppendingString:@"\","];
    
    postString = [postString stringByAppendingString:@"\"tollSessionId\":\""];
    postString = [postString stringByAppendingString:@""];
    postString = [postString stringByAppendingString:@"\""];
    
    
    
    
    postString = [postString stringByAppendingString:@"}"];
    
    
    [request addBasicAuthenticationHeaderWithUsername:[[[Singleton instance] devDetails] objectForKey:@"username"] andPassword:[[[Singleton instance] devDetails] objectForKey:@"password"]];
    
    
    [request setPostValue:[[[Singleton instance] devDetails] objectForKey:@"username"]  forKey:@"username"];
    [request setPostValue:postString forKey:@"json"];
    
    //[request appendPostData:postString];
    NSLog(@"before calling request");
    
    [request startSynchronous];
    NSLog(@"after calling request");
    NSError *error = [request error];
    if (!error) {
        NSString *response = [request responseString];
        NSLog(@"response = %@", response);
    }
    else
    {
        NSLog(@"error");
        NSLog(@"%@",[error description]);
    }
    
    
}

-(void) showNotification: (NSString*)msg {
    
    if( [[UIApplication sharedApplication] applicationState] == UIApplicationStateBackground) {
        NSLog(@"Application is running in the background");
        
        /* Here we cancel all previously scheduled notifications */
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
        
        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        
        localNotification.fireDate = [[NSDate alloc] init];
        NSLog(@"Notification will be shown on: %@",localNotification.fireDate);
        
        localNotification.timeZone = [NSTimeZone defaultTimeZone];
        localNotification.alertBody = msg;
        localNotification.alertAction = NSLocalizedString(@"View details", nil);
        
        /* Here we set notification sound and badge on the app's icon "-1" 
         means that number indicator on the badge will be decreased by one 
         - so there will be no badge on the icon */
        
        localNotification.soundName = UILocalNotificationDefaultSoundName;
        localNotification.applicationIconBadgeNumber = -1;
        
        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    } 
    else if([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
        NSLog(@"Application is active in foreground");
        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"Toll Crossing"
                                                            message:msg delegate:self 
                                                  cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];
        [alertView release];            
    }
	
}

@end
