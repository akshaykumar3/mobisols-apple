/*
 *  Singleton.h
 *  mtpdev
 *
 *  Created by Harish Balijepalli on 10/23/11.
 *  Copyright 2011 mobisols. All rights reserved.
 *
 */
#import <CoreLocation/CoreLocation.h>

@interface Singleton : NSObject {
@private
    bool AppState;
    NSDictionary *config;
    NSArray *toll_locs;
    NSDictionary *devDetails;
    CLLocationManager *locationManager;
}

+ (Singleton *)instance;

// specifying retain in property specifies that the setter should retain the input value.
@property (assign) bool AppState;
@property (assign) CLLocationManager* locationManager;
@property (retain) NSDictionary* devDetails;
@property (retain) NSArray* toll_locs;
@property (retain) NSDictionary* config;

@end
