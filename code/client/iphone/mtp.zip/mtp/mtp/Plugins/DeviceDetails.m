
#import "DeviceDetails.h"
#import "Singleton.h"
#import "JSONKit.h"
#include <stdio.h>



@implementation DeviceDetails

-(void) setDetails:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options
{
    // get user related info and save it in singleton.
    printf("DeviceDetails native plugin invoked\n");
    NSData *temps = [[arguments objectAtIndex:0] dataUsingEncoding:NSUTF8StringEncoding];
    JSONDecoder *jsonKitDecoder = [JSONDecoder decoder];
    NSDictionary *resobj = [jsonKitDecoder objectWithData:temps];
    [[Singleton instance] setDevDetails:resobj];
    NSLog(@"%@",[[[Singleton instance] devDetails] objectForKey:@"username"]);
    
    //[temps autorelease];
    //[resobj autorelease];
}

@end