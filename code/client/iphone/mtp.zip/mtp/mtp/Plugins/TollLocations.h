//
//  TollLocations.h
//  mtpdev
//
//  Created by Harish Balijepalli on 10/25/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "PhoneGapCommand.h"
#import <PhoneGap/PGPlugin.h>

@interface TollLocations:PGPlugin {
    
}

- (void) setTollDetails:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options;

@end