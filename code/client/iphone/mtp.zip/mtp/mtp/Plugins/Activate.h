/*
 *  Activate.h
 *  Activate
 *
 *  Created by Snow Leopard User on 07/07/2011.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#import <Foundation/Foundation.h>
//#import "PhoneGapCommand.h"
#import <PhoneGap/PGPlugin.h>

@interface Activate:PGPlugin {
    
}

- (void) setActive:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options;

- (void) setInactive:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options;

@end