#import "ClientConfig.h"
#import "Singleton.h"
#import "JSONKit.h"
#include <stdio.h>

@implementation ClientConfig

-(void) setConfiguration:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options
{
    printf("ClientConfig native plugin invoked \n");
    NSData *temps = [[arguments objectAtIndex:0] dataUsingEncoding:NSUTF8StringEncoding];
    JSONDecoder *jsonKitDecoder = [JSONDecoder decoder];
    NSDictionary *resobj = [jsonKitDecoder objectWithData:temps];
    [[Singleton instance] setConfig:resobj];
    
    //[temps autorelease];
    //[resobj autorelease];
}

@end