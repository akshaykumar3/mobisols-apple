console.log('hello world is loaded');

function HelloWorld()
{
	console.log('helloworld instance created');
};

HelloWorld.prototype.printMessage= function(message)
{
	PhoneGap.exec('HelloWorldCommand.show',message);
};

HelloWorld.install=function()
{
	if(!window.plugins)
	{
		window.plugins={};
	}
	window.plugins.helloworld = new HelloWorld();
	return window.plugins.helloworld;
}

PhoneGap.addConstructor(HelloWorld.install);