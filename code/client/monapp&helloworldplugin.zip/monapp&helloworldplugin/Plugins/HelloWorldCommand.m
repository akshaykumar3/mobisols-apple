#import "HelloWorldCommand.h"
#include <stdio.h>

@implementation HelloWorldCommand

-(void) printMessage {
	printf("I am invoked from JavaScript\n");
}

@end