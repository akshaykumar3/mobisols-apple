/*
 *  HelloWorldCommand.h
 *  monapp&plugin
 *
 *  Created by Snow Leopard User on 05/07/2011.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

@interface HelloWorldCommand

- (void) printMessage;

@end

