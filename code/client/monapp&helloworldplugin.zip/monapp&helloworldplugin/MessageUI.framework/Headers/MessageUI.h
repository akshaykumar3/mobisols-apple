/*
 *  MessageUI.h
 *  MessageUI
 *
 *  Copyright 2009, 2010 Apple Inc. All rights reserved.
 *
 */


#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MFMessageComposeViewController.h>
