console.log('hello world is loaded');

function HelloWorld()
{
	console.log('helloworld instance created');
};

HelloWorld.prototype.printMessage= function()
{
	PhoneGap.exec('HelloWorldCommand.printMessage');
};

HelloWorld.install=function()
{
	if(!window.plugins)
	{
		console.log('windows.plugins created');
		window.plugins={};
	}
	window.plugins.helloworld = new HelloWorld();
	return window.plugins.helloworld;
}

PhoneGap.addConstructor(HelloWorld.install);