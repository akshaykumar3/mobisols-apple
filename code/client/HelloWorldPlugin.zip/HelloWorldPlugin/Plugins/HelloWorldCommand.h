/*
 *  HelloWorldCommand.h
 *  HelloWorldPlugin
 *
 *  Created by Snow Leopard User on 07/07/2011.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#import <Foundation/Foundation.h>
#import "PhoneGapCommand.h"

@interface HelloWorldCommand: PhoneGapCommand {
    
}

- (void) printMessage:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options;
@end