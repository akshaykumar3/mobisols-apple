#import "HelloWorldCommand.h"
#include <stdio.h>

@implementation HelloWorldCommand

-(void) printMessage:(NSMutableArray*)arguments withDict:(NSMutableDictionary*)options
{
	printf("I am invoked from JavaScript\n");
}

@end