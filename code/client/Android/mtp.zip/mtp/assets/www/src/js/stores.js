Ext.ns('gtp.stores');

// Store for Cars Model
var carsList = new Ext.data.Store({
	model: 'Cars',
	sorters: 'reg',
	getGroupString : function(record) {
		return record.get('reg')[0];
	},
	data: [{
		reg: '4GPB5',
		state: 'CA',
		type: 'Sedan',
		startDate: new Date('12/7/2010'),
		endDate: new Date('12/12/2010'),
		active: true
	}]
});

// Store for Tolls.
var tolldetails=new Ext.data.Store({
	model: 'Tolls',
	data: [{
		 latitude: 37.49885,
		 longitude: -122.198452,
		 covered: true,
		 description: "illinois entry toll road",
		 price: '$1',
		 url: 'www.toll1.com'
	}]
});

// Store for paid Tolls.
var paidTolls = new Ext.data.Store({
	model: 'PaidTolls',
	getGroupString : function(record) {
		return record.get('date');
	},
	data: [{
		date: '2011-01-01',
		amount:'$2.50',
		location:'I-15N, Escondido',
		reg: '4GPB5'
	},{
		date:'2011-02-21',
		amount:'$2.50',
		location:'I-15N, Kentucky',
		reg: '4GPB5'
	}]
});

// Store for newwebservice urls.
var webServices=new Ext.data.Store({
	model: 'WebServices',
	data: [{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/ClientConfiguration',
		service: 'clientconfig'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/UserRegistration',
		service: 'regnewuser'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/DeviceRegistration',
		service: 'registerdevice'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/Login',
		service: 'logging'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/AccountDetails',
		service: 'acdetails'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/HeartBeat',
		service: 'heartbeat'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/VehicleDetails',
		service: 'addcar'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/TollDetailsList',
		service: 'tolldetails'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/VehicleTypeList',
		service: 'vehicletypes'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/CcTypeList',
		service: 'cctypes'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/OwnerTypeList',
		service: 'ownertypes'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/ServicePlansList',
		service: 'serviceplans'
	},{
		url: 'http://tollpass.dyndns-server.com:6001/newweb/services/NearestToll',
		service: 'nearesttoll'
	}] 
});

// Stores for logging heartbeat.
gtp.stores.LogHeartBeat= new Ext.data.Store({
	model: 'HeartBeatLog'
});