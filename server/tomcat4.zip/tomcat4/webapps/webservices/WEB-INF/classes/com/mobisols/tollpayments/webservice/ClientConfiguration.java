package com.mobisols.tollpayments.webservice;


public interface ClientConfiguration {
	Integer compVersionId=0;
	String key=null;
	String value=null;
	public Integer getCompVersionId();
	public void setCompVersionId(Integer compVersionId);
	public String getKey();
	public void setKey(String key);
	public String getValue();
	public void setValue(String value);
	
}
