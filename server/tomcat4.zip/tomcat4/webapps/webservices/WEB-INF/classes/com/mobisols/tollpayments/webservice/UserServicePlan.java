package com.mobisols.tollpayments.webservice;

public interface UserServicePlan {
	String name=null;
	String description=null;
	String tollOpName=null;
	public String getName();
	public void setName(String name);
	public String getDescription();
	public void setDescription(String description);
	public String getTollOpName();
	public void setTollOpName(String tollOpName);

}
