package com.mobisols.tollpayments.webservice;

import java.util.HashMap;

public interface HeartBeatResponse {
	HashMap<String, String> hash=null;
	
	public HashMap<String, String> getHash();

	public void setHash(HashMap<String, String> hash);
}
