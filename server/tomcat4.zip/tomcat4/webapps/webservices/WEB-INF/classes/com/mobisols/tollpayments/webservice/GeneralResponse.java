package com.mobisols.tollpayments.webservice;

public interface GeneralResponse {
	String description=null;
	public String getDescription();

	public void setDescription(String description);
}
