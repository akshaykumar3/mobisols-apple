package com.mobisols.tollpayments.webservice;

public interface VMLType {

	String name=null;
	String description=null;

	public String getName();
	public void setName(String name);
	public String getDescription();
	public void setDescription(String description);
}
