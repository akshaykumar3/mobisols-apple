package com.mobisols.tollpayments.webservice;

public interface Location {
	double latitude=0.0f;
	double longitude=0.0f;
	public double getLatitude();

	public void setLatitude(double latitude);

	public double getLongitude();

	public void setLongitude(double longitude);
}
