package com.mobisols.tollpayments.webservice;

public interface SimpleAppRegistration {

}
