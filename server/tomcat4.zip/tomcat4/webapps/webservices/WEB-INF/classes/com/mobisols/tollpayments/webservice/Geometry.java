package com.mobisols.tollpayments.webservice;

public interface Geometry {
	double latitude1=0.0f;
	double longitude1=0.0f;
	double latitude2=0.0f;
	double longitude2=0.0f;
	public double getLatitude1();
	public void setLatitude1(double latitude1);
	public double getLongitude1();
	public void setLongitude1(double longitude1);
	public double getLatitude2();
	public void setLatitude2(double latitude2);
	public double getLongitude2();
	public void setLongitude2(double longitude2);
}
