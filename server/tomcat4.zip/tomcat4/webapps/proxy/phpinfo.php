<?php

echo phpinfo();

?>