<?php

header('Content-Type: application/x-ns-proxy-autoconfig');

require('./cache/pac.php');

?>
