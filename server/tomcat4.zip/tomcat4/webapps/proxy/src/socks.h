#ifndef __SOCKS_H
#define __SOCKS_H

int processSocksUserHeader(Connection *this);
void checkWaitForZero(Connection *this);
void sendSocksReply(Connection *this);

#endif
