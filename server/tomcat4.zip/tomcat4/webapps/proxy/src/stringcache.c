
#include "pserver.h"
#include "adler32.h"
#include "stringcache.h"

/* StringCache *****************************************/




void
initStringCache(StringCache *this)
{
	assert(this!=NULL);
	memset(this,0,sizeof(this[0]));
}

static StringCacheBucket *
findStringCacheBucket(StringCache *this,const char *key)
{
	unsigned long adler32num;
	int bucket;
	StringCacheBucket *itemsBucket;

	assert(this!=NULL);
	assert(key!=NULL);

	adler32num=adler32(0,key,strlen(key));
	bucket=adler32num%STRINGCACHE_ITEMS;
	itemsBucket=this->items+bucket;
	return itemsBucket;
}


StringCacheItem *
newStringCacheItem(StringCache *this,const char *key,const char *val)
{
	StringCacheItem *item;
	StringCacheBucket *itemsBucket;

	assert(this!=NULL);
	assert(key!=NULL);
	assert(val!=NULL);
	itemsBucket=findStringCacheBucket(this,key);

	item=pserver_malloc(sizeof(item[0]));
	item->lastCheck=time(NULL);
	item->key=strdup(key);
	item->val=strdup(val);
	if(itemsBucket->firstItem!=NULL) {
		assert(itemsBucket->firstItem->prev==NULL);
		itemsBucket->firstItem->prev=item;
	}
	item->prev=NULL;
	item->next=itemsBucket->firstItem;
	itemsBucket->firstItem=item;

	itemsBucket->totalItems++;
	this->totalItems++;
	return item;
}

StringCacheItem *
findStringCacheItem(StringCache *this,const char *key)
{
	StringCacheBucket *itemsBucket;
	StringCacheItem *item;

	assert(this!=NULL);
	assert(key!=NULL);
	itemsBucket=findStringCacheBucket(this,key);
	for(item=itemsBucket->firstItem; item!=NULL; item=item->next) {
		if(strcmp(item->key,key)==0) { return item; }
	}
	return NULL;
}

StringCacheItem *
replaceStringCacheItem(StringCache *this,
		const char *key,const char *val,
		int updateLastCheck)
{
	StringCacheItem *item;

	assert(this!=NULL);
	assert(key!=NULL);
	assert(val!=NULL);
	item=findStringCacheItem(this,val);
	if(item==NULL) {
		item=newStringCacheItem(this,key,val);
	} else {
		free(item->val);
		if(updateLastCheck) { item->lastCheck=time(NULL); }
		item->val=strdup(val);
	}
	return item;
}


static void
removeStringCacheItemFromBucket(StringCacheBucket *itemsBucket,StringCacheItem *item)
{
	assert(itemsBucket!=NULL);
	assert(item!=NULL);
	assert(item->key!=NULL);
	assert(item->val!=NULL);

	if(item->next!=NULL) { item->next->prev=item->prev; }
	if(item->prev!=NULL) { item->prev->next=item->next; }
	else {
		assert(itemsBucket->firstItem==item);
		itemsBucket->firstItem=item->next;
	}
	free(item->key);
	free(item->val);
	free(item);
	itemsBucket->totalItems--;
}
void
removeStringCacheItem(StringCache *this,StringCacheItem *item)
{
	StringCacheBucket *itemsBucket;

	assert(this!=NULL);
	assert(item!=NULL);
	assert(item->key!=NULL);

	itemsBucket=findStringCacheBucket(this,item->key);
	removeStringCacheItemFromBucket(itemsBucket,item);
	this->totalItems--;
}


void
clearStringCache(StringCache *this)
{
	StringCacheBucket *itemsBucket;
	StringCacheItem *item;

	assert(this!=NULL);
	
	itemsBucket=this->items;
	for(itemsBucket=this->items; itemsBucket<(this->items+STRINGCACHE_ITEMS); itemsBucket++) {
		while((item=itemsBucket->firstItem)!=NULL) {
			removeStringCacheItemFromBucket(itemsBucket,item);
			this->totalItems--;
		}
		assert(itemsBucket->totalItems==0);
		assert(itemsBucket->firstItem==NULL);
	}
	assert(this->totalItems==0);
}

#ifndef NDEBUG

void
assertStringCacheItem(StringCacheItem *this)
{
	assert(this!=NULL);
	assert(this->key!=NULL);
	assert(this->val!=NULL);
}


int
assertStringCacheBucket(StringCacheBucket *this)
{
	StringCacheItem *item;
	int c=0;

	assert(this!=NULL);
	item=this->firstItem;
	if(this->firstItem!=NULL) {
		assert(this->firstItem->prev==NULL);
	}
	while(item!=NULL) {
		if(item->next!=NULL) {
			assert(item->next->prev==item);
		}
		assertStringCacheItem(item);
		item=item->next;
		c++;
	}
	assert(this->totalItems==c);
	return c;
}

void
assertStringCache(StringCache *this)
{
	int c;
	int total=0;

	assert(this!=NULL);
	for(c=0; c<STRINGCACHE_ITEMS; c++) {
		total+=assertStringCacheBucket(this->items+c);
	}
	assert(total==this->totalItems);
}

#endif

