#ifndef __URL_H
#define __URL_H

#define MAX_URL_LEN 8196


typedef struct Url {
	char *scheme;
	char *host;
	int port;
	char *path;
	char *query;
}Url;

STATIC_INLINE int
getUrlConnectPort(Url *this) 
{
	if(this->port==0) {
		this->port=strcasecmp(this->scheme,"https")==0?443:80;
	}
	return this->port;
}



void clearUrl(Url *this);
int parse_url(Url *this,char *url);
void encodeUrl(char *to, int len,const char *from);

#endif
