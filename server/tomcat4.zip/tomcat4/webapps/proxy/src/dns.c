
#include "pserver.h"
#include "server.h"
#include "connection.h"
#include "connmessages.h"
#include "dns.h"
	
/* dns *********************************/

/* disconnect from any running dns threads */
void
disconnectDnsLookup(Connection *this)
{
	assert(this!=NULL);
	lockConnection(this);
	if(this->dnsLookup!=NULL) {
		this->dnsLookup->connection=NULL;
		this->dnsLookup=NULL;
		closePipeFds(this);
	}
	unlockConnection(this);
}



/* called by main loop when dns results for a connection is available */
int
finishDnsThread(Connection *this)
{
	assert(this!=NULL);
	assert((this->flags&CONNECTION_WEB_CONNECTION));
	assert(!(this->flags&CONNECTION_DNS_DONE_PROCESSED));
	assert(this->flags&CONNECTION_DNS_DONE);

#ifndef NDEBUG
	{ int i;
	for(i=0; i<this->hostAddrsTotal; i++) {
		debugLog(10,"%x: finishDnsThread: received dns from thread: ip:%s->%s\n",(unsigned int)this,
			this->parsedUrl.host,inet_ntoa_l(this->hostAddrs[i].addr));
	}
	}
#endif

	this->flags|=CONNECTION_DNS_DONE_PROCESSED;
	this->lastActivity=time(NULL);


	/* only do dns if the connection hasn't been cancelled or started
	 * reading from the cache,etc. during the time it took
	 * for us to look up
	 */
	if(this->url!=NULL) {
		closePipeFds(this);
		if(this->hostAddr==0) {
			debugLog(5,"host lookup fail:%x,%s\n",(unsigned int)this->otherConnection,this->otherConnection->parsedUrl.host);
			errorConnection(this,"Could not find: %s<br /><a href=\"diagdns.php?host=%s\">Diagnose DNS</a><br />",
				this->otherConnection->parsedUrl.host,
				this->otherConnection->parsedUrl.host);
			closeConnection(this);
			return 0;
		} else {
			debugLog(10,"host lookup done:%x,%s\n",(unsigned int)this->otherConnection,this->otherConnection->parsedUrl.host);
			/* dns lookup is done, lets connect up */
			if(connectToAddress(this)==INVALID_SOCKETFD) {
				return 0;
			}
		}
	} else {
		assert(this->conn!=INVALID_SOCKETFD);
	}
	return 1;
}

static void
freeDnsLookup(DnsLookup *this)
{
	assert(this!=NULL);

	FREE_PTR(this->hostToLookup);
	if(this->connection!=NULL) {
		this->connection->dnsLookup=NULL;
	}
	free(this);
}

#ifdef _MSC_VER
#define USE_GETADDRINFO 1
#endif

#ifdef _WIN32
static unsigned __stdcall
dnsThread(DnsLookup *this)
#else
static void *
dnsThread(DnsLookup *this)
#endif
{
#ifdef USE_GETADDRINFO
	struct addrinfo aiHints;
	struct addrinfo *aiList = NULL;
#else
	struct hostent *hostEntry;
#endif
	int retry=0;

	assert(this!=NULL);
	assert(this->hostToLookup!=NULL);
	debugLog(15,"dns lookup piped: %s\n",
		this->hostToLookup);

	this->server->totalDnsRunning++;
	while(retry<2) {
#ifdef USE_GETADDRINFO
		int retVal;
		char portToLookup[64];
		snprintf(portToLookup,sizeof(portToLookup),"%i",this->portToLookup);
		memset(&aiHints, 0, sizeof(aiHints));
		aiHints.ai_family = AF_INET;
		aiHints.ai_socktype = SOCK_STREAM;
		aiHints.ai_protocol = IPPROTO_TCP;

		if((retVal=getaddrinfo(this->hostToLookup,portToLookup,&aiHints,&aiList))!=0) {
			if(aiList!=NULL) { freeaddrinfo(aiList); aiList=NULL; }
		}
#else
		hostEntry=gethostbyname(this->hostToLookup);
		if(hostEntry!=NULL && ((struct in_addr *)hostEntry->h_addr_list[0])->s_addr==0) {
			errorLog(this->server,"huh? dns returned 0: %s",this->hostToLookup);
			usleep(250000);
			retry++;
			continue;
		}
		if(this->connection!=NULL && hostEntry!=NULL && ((struct in_addr *)hostEntry->h_addr_list[0])->s_addr==this->connection->server->localhost && strcmp(this->hostToLookup,"localhost")!=0) {
			errorLog(this->server,"huh? found localhost: %s",this->hostToLookup);
			/* for some strange reason this sometimes returns 127.0.0.1 */
			usleep(250000);
			retry++;
			continue;
		}
#endif
		break;
	}


	if(this->connection!=NULL) {
		Connection *connection;
		connection=this->connection;

		lockConnection(connection);
		FREE_PTR(connection->hostAddrs);
		connection->hostAddrsTotal=0;
		connection->flags|=CONNECTION_DNS_DONE;
#ifdef USE_GETADDRINFO
		if(aiList!=NULL) {
			int i;
			struct addrinfo *aiPtr;
			aiPtr=aiList;
			memcpy(&connection->hostAddr,&(((struct sockaddr_in *)(aiPtr->ai_addr))->sin_addr),
				sizeof(connection->hostAddr));
			i=0;
			while(aiPtr!=NULL) {
				i++;
				aiPtr=aiPtr->ai_next;
			}
			connection->hostAddrsTotal=i;
			connection->hostAddrsUpto=1;
			connection->hostAddrs=pserver_malloc(sizeof(connection->hostAddrs[0])*i);
			aiPtr=aiList;
			
			for(i=0; aiPtr!=NULL; i++,aiPtr=aiPtr->ai_next) {
				memcpy(&connection->hostAddrs[i].addr,&(((struct sockaddr_in *)(aiPtr->ai_addr))->sin_addr),sizeof(connection->hostAddrs[i].addr));
				connection->hostAddrs[i].port=connection->hostPort;
				connection->hostAddrs[i].otherProxy=NULL;
			}
			freeaddrinfo(aiList); aiList=NULL;
		}
#else
		if(hostEntry!=NULL) {
			int i;

			connection->hostAddr=((struct in_addr *)hostEntry->h_addr_list[0])->s_addr;
			i=0;
			while(hostEntry->h_addr_list[i]!=NULL) {
				i++;
			}
			connection->hostAddrsTotal=i;
			connection->hostAddrsUpto=1;
			connection->hostAddrs=pserver_malloc(sizeof(connection->hostAddrs[0])*i);

			for(i=0; hostEntry->h_addr_list[i]!=NULL; i++) {
				connection->hostAddrs[i].addr=((struct in_addr *)hostEntry->h_addr_list[i])->s_addr;
				connection->hostAddrs[i].port=connection->hostPort;
				connection->hostAddrs[i].otherProxy=NULL;
			}
		}
#endif
		if(connection->pipeFds[1]!=INVALID_SOCKETFD) {
#if USE_SOCKET_PIPE
			send(connection->pipeFds[1],"",1,0);
#else
			write(connection->pipeFds[1],"",1);
#endif
		}
		connection->flags&=-1^CONNECTION_DNS_THREAD_RUNNING;
		unlockConnection(connection);
	}

	debugLog(10,"finishDns: host looked up:%x,%s\n",(unsigned int)this->connection,this->hostToLookup);
	this->server->totalDnsRunning--;
	freeDnsLookup(this);
#ifdef _WIN32
	_endthread();
	return 0;
#else
	return NULL;
#endif
}


#if USE_SOCKET_PIPE
static int
createSocketPipe(SOCKETFD *pipeFds)
{
	int port;
	struct sockaddr_in addr;
	SOCKETFD listenSock;
	struct sockaddr_in acceptAddr;
	socklen_t acceptAddrLen=sizeof(acceptAddr);
	int ok=0;

	assert(pipeFds!=NULL);

	memset(&addr,0,sizeof(addr));
	addr.sin_family=AF_INET;
	addr.sin_addr.s_addr=inet_addr("127.0.0.1");
	listenSock=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	pipeFds[1]=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	debugLog(20,"creating pipe with sockets: listen:%i, fd:%i\n",listenSock,pipeFds[1]);
	if(pipeFds[0]==INVALID_SOCKETFD || pipeFds[1]==INVALID_SOCKETFD) {
		return 0;
	}
	for(port=8192; port<16384; port++) {
		addr.sin_port=htons(port);
		if(bind(listenSock,(struct sockaddr *)&addr,sizeof(addr))==0) { ok=1; break; }
	}
	if(!ok) { return 0; }
	if(listen(listenSock,1)<0) { return 0; }
	debugLog(20,"pipe created on port:%i\n",ntohs(port));
	if(connect(pipeFds[1],(struct sockaddr *)&addr,sizeof(addr))<0) {
		return 0;
	}
	pipeFds[0]=accept(listenSock,(struct sockaddr *)&acceptAddr,&acceptAddrLen);
	closesocket(listenSock);

	debugLog(20,"pipe connected: in:%i, out:%i\n",pipeFds[0],pipeFds[1]);
	return 1;
}
#endif

int
createDnsThread(Connection *this)
{
	int pipeFds[2];

	assert(this!=NULL);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
	assert(this->otherConnection!=NULL);
	assert(this->otherConnection->parsedUrl.host!=NULL);
	assert(this->dnsLookup==NULL);
	assert(this->hostPort!=0);

	if(this->flags&CONNECTION_DNS_THREAD_RUNNING) {
		char ch;
		assert(this->conn!=INVALID_SOCKETFD);
		debugLog(10,"Whoops, dns thread already running wait for the other dns to stop\n");
		read(this->conn,&ch,1);
	}
	this->flags|=CONNECTION_DNS_THREAD_RUNNING;

	this->dnsLookup=pserver_malloc(sizeof(this->dnsLookup[0]));
	assert(this->dnsLookup!=NULL);
	memset(this->dnsLookup,0,sizeof(this->dnsLookup[0]));
	this->dnsLookup->connection=this;
	this->dnsLookup->server=this->server;
	this->dnsLookup->hostToLookup=strdup(this->otherConnection->parsedUrl.host);
	this->dnsLookup->portToLookup=getUrlConnectPort(&this->otherConnection->parsedUrl);

#if USE_SOCKET_PIPE
	createSocketPipe(pipeFds);
#else
	pipe(pipeFds);
#endif
	assert(this->webConn==INVALID_SOCKETFD);
	this->webConn=this->conn;
	this->conn=pipeFds[0];
	memcpy(this->pipeFds,pipeFds,sizeof(this->pipeFds));

	debugLog(15,"pipe dns lookup: %s(fdin:%i,fdout:%i)\n",
		this->dnsLookup->hostToLookup,this->conn,pipeFds[1]);
	if(pthread_create(&this->dnsThread,NULL,(void *(*)(void *))&dnsThread,this->dnsLookup)!=0) {
		errorLog(this->server,"Could not create thread: %s",pserver_strerror(errno));
	}
#ifndef _WIN32
	pthread_detach(this->dnsThread);
#endif
	return 1;
}







