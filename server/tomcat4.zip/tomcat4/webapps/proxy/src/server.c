
#include "pserver.h"
#include "access.h"
#include "server.h"
#include "anonproxy.h"
#include "connection.h"
#include "connmessages.h"
#include "readconfig.h"
#include "cleancache.h"
#include "dns.h"
#include "ssl.h"

/* log file *********************************/


static void
closeErrorLogFile(Server *this)
{
	assert(this!=NULL);
	if(this->errorOut!=NULL) {
		fclose(this->errorOut);
		this->errorOut=NULL;
	}
}

static int
openLogFile(Server *this)
{
	assert(this!=NULL);
	if((this->logFileOut=pserver_fopen(this->logFile,"ab"))==NULL) {
		errorLog(this,"Cannot open log file: %s,%s\n",this->logFile,pserver_strerror(errno));
		return 0;
	}
	return 1;
}

static void
closeLogFile(Server *this)
{
	assert(this!=NULL);
	if(this->logFileOut!=NULL) {
		fflush(this->logFileOut);
		fclose(this->logFileOut);
#ifdef _WIN32
		/* for some reason I can't rename the file if I don't close it like this first in mingw */
		pserver_close(fileno(this->logFileOut));
#endif
		this->logFileOut=NULL;
	}
}

int
rotateLogFile(Server *this)
{
	char nfile[FILENAME_MAX];
	char nfile2[FILENAME_MAX];
	struct stat st;
	int upto;

	assert(this!=NULL);
	closeLogFile(this);

	for(upto=this->maxLogRotate; upto>0; upto--) {
		snprintf(nfile,sizeof(nfile),"%s.%i",this->logFile,upto);
		if(upto==this->maxLogRotate) {
			if(stat(nfile,&st)==0) {
				if(unlink(nfile)!=0) {
					errorLog(this,"Could not remove logfile: %s,%s\n",nfile,pserver_strerror(errno));
				}
			}
		}

		snprintf(nfile2,sizeof(nfile2),"%s.%i",this->logFile,upto-1);
		if(stat(nfile2,&st)==0) {
			if(rename(nfile2,nfile)!=0) {
				errorLog(this,"Could not rename logfile: %s->%s,%s\n",nfile2,nfile,pserver_strerror(errno));
			}
		}
	}

	snprintf(nfile,sizeof(nfile),"%s.0",this->logFile);
	if(rename(this->logFile,nfile)!=0) {
		errorLog(this,"Could not rename logfile: %s->%s,%s\n",this->logFile,nfile,pserver_strerror(errno));
		return 0;
	}

	openLogFile(this);
	return 1;
}


#if 0
static void *
testProxyThread(Connection *this)
{
	/*~~~ test and register an anon proxy */

	appendWriteBufStatic(this,"HTTP/1.0 200 Ok\n\n");

	return NULL;
}

static void
startTestProxyThread(Connection *this)
{
	THREAD_HANDLE tpThread;
	pthread_create(&tpThread,NULL,(void *(*)(void *))testProxyThread,this);
}
#endif



/* main *********************************/


STATIC_INLINE int
readBufferOk(Connection *this)
{
	Connection *otherConnection;
	assert(this!=NULL);

	if(this->flags&CONNECTION_READ_AGAIN) { return 1; }

	if((otherConnection=this->otherConnection)==NULL) { 
		/* we shouldn't have a connection where the web connection
		 * is alive but the user connection is dead
		 */
		if(!(this->flags&CONNECTION_CLOSE) ) {
			assert(!(this->flags&CONNECTION_WEB_CONNECTION));
		}
		return 1; 
	}
	if(otherConnection->flags&(CONNECTION_CLOSE|CONNECTION_RETRY_WRITE)) {
		/* 
		 * the other connection is about to close but hasn't really closed yet 
		 * Or we need to retry write which means we can't realloc the buffer
		 * */
		return 0;
	}


	if(getStringBufLen(&otherConnection->writeBuf)<32000
	) {
		/* stop reading if there's alot on the queue to be
		 * sent to the other connection
		 */
#if 0
		if(this->ssl!=NULL && SSL_want_write(this->ssl)) {
			return 0;
		}
#endif
		return 1;
	}
	return 0;
}

STATIC_INLINE int
writeBufferOk(Connection *this)
{
	assert(this!=NULL);
	debugLog(25,"connection:%x, connected:%x,dnsdone:%x,lastact:%i,writebufempty:%i\n",
		(unsigned int)this,
		(this->flags&CONNECTION_SOCKET_CONNECTED),
		(this->flags&CONNECTION_DNS_DONE_PROCESSED),
		this->lastActivity,
		isStringBufEmpty(&this->writeBuf)
		);

#if 0
		if(this->ssl!=NULL && SSL_want_write(this->ssl)) {
			return 1;
		}
#endif

	if(
		(this->flags&CONNECTION_SOCKET_CONNECTED)
		&& (this->flags&CONNECTION_DNS_DONE_PROCESSED)
		&& !isStringBufEmpty(&this->writeBuf)
	) {
		/* we're connected and the dns has been looked up too 
		 * sometimes it is connected but to a previous host that's
		 * not the same dns
		 */
		assert(!(this->flags&CONNECTION_READ_CACHE));
		assert(this->pipeFds[0]==INVALID_SOCKETFD); /* we don't want to write to dns */
		return 1;
	}
	return 0;
}


Connection *
getNewConnection(Server *this,Connection *creator)
{
	Connection *newConnection;

	assert(this!=NULL);
	if(creator!=NULL)
		assertConnection(creator);

	newConnection=pserver_malloc(sizeof(newConnection[0]));
	memset(newConnection,0,sizeof(newConnection[0]));

	debugLog(5,"getNewConnection: %x\n",(unsigned int)newConnection);
	if(creator!=NULL) {
		creator->otherConnection=newConnection;
		newConnection->otherConnection=creator;
		newConnection->flags|=(creator->flags&CONNECTION_WEB_CONNECTION)?0:CONNECTION_WEB_CONNECTION;
		newConnection->userAddr=creator->userAddr;
		newConnection->userPort=creator->userPort;
	}

	newConnection->nextConnection=this->firstConnection;
	if(this->firstConnection!=NULL) {
		this->firstConnection->prevConnection=newConnection;
	}
	this->firstConnection=newConnection;
	this->totalConnections++;

	newConnection->pipeFds[0]=newConnection->pipeFds[1]=INVALID_SOCKETFD;
	ftime(&newConnection->startTime);
	newConnection->lastActivity=time(NULL);
	newConnection->server=this;
	newConnection->conn=INVALID_SOCKETFD;
	newConnection->recvBodyLen=newConnection->recvLen=0;
	newConnection->webConn=INVALID_SOCKETFD;
	newConnection->webContentLength=-1;
#ifdef _WIN32
	newConnection->lock=CreateMutex(NULL,FALSE,NULL);
#else
	pthread_mutex_init(&newConnection->lock,NULL);
#endif

	return newConnection;
}







/* main loop *********************************/


static int
checkTimeouts(Server *this)
{
	time_t t;
	Connection *conn;
	int timedOuts;
	int checkTimeout=0;

	assert(this!=NULL);
	t=time(NULL);
	if(this->nextTimeoutCheck<t) {
		this->nextTimeoutCheck=t+2;
		checkTimeout=1;
	}
	timedOuts=0;

	checkAnonKeys(&this->anonProxy,t);

	conn=this->firstConnection;
	while(conn!=NULL) {
		Connection *nextConn;
		nextConn=conn->nextConnection;

		if(conn->flags&CONNECTION_CLOSE) {
			closeMarkedConnection(this,conn);
		}
		else if(checkTimeout 
		&& conn->flags&CONNECTION_WEB_CONNECTION
		&& !(conn->flags&CONNECTION_SOCKS)
		/* if the other connection hasn't done the header 
		 * then we're in keep-alive mode. 
		 * Don't do timeouts when waiting in keep-alive mode.
		 */
		&& !(conn->otherConnection!=NULL && !isHeaderDone(conn->otherConnection))
		) {
			int ok=1;
			time_t lastActivity=conn->lastActivity;
			if(isProxyKeyOk(conn)) {
				/* wait a bit less if it's from another proxy,
				 * so that we can send them an error message
				 * first before they create their own
				 */
				lastActivity-=5;
			}
			if((conn->totalRecvLen>0 && !(conn->flags&CONNECTION_CMD_CONNECT)) || conn->recvBodyLen>0) {
				/* those silly places that take 
				 * a long time to download large datasets ,etc. 
				 */
				if(t>=(lastActivity+this->dataTimeOutSeconds)) { ok=0; }
			} else {
				if(isToProxy(conn)) {
					/* don't waste time connecting to slow proxys */
					if(t>=(conn->lastActivity+conn->server->anonProxy.timeout)) {
						ok=0;
					}
				} else if(t>=(lastActivity+this->timeOutSeconds)) {
					ok=0;
				}
			}
			if(checkTimeout) {
				debugLog(25,"%x:checkTimeout: recvlen:%i, time:%i -> lastact:%i\n",conn,conn->recvLen,t,conn->lastActivity);
			}
			if(!ok
			&& (!isReconnectOk(conn)
			 || connectToNextAddress(conn)==INVALID_SOCKETFD)
			) {
				/* char mess[1024]; */
				/* don't close the user's connection 
				 * on timed outs cause we still need 
				 * to send them a "timed out" message. 
				 * The users's connection will close in
				 * checkClose
				 */
				debugLog(5,"timed out: %x\n",(unsigned int)conn);
				conn->errorImg="img/timed_out.jpg";
				/*~~~ BUG: debug stuff */
			
				/* 
				sprintf(mess,"Timed out, %s, %i",ctime(&conn->lastActivity),time(NULL)-conn->lastActivity); 
				sendDiagnoseMessage(conn,mess);
				*/
				sendDiagnoseMessage(conn,"Timed out");

	/* ~~~ what if user times out? we currently depend on the OS to send an error */
				closeConnection(conn);
				timedOuts++;
			}
		}
		conn=nextConn;
	} 
	return timedOuts;
}

static void
removePidFile(Server *this)
{
	assert(this!=NULL);
	unlink(this->pid_file);
}

static void
writePidFile(Server *this)
{
	FILE *pidh;
	char line[256];

	assert(this!=NULL);
	if((pidh=pserver_fopen(this->pid_file,"wb"))==NULL) {
		errorLog(this,"Cannot open pid file: %s (%s)\n",this->pid_file,pserver_strerror(errno));
		return;
	}
	snprintf(line,sizeof(line),"%i",getpid());
	fputs(line,pidh);
	fclose(pidh);
}

static void
closeAllConnections(Server *this)
{
	Connection *conn;

	assert(this!=NULL);

	conn=this->firstConnection;
	while(conn!=NULL) {
		Connection *nextConn;
		nextConn=conn->nextConnection;
		closeConnection(conn);
		conn=nextConn;
	}
}


static void
clearServer(Server *this)
{
	assert(this!=NULL);
	if(this->listenSocket!=INVALID_SOCKETFD) {
		closesocket(this->listenSocket);
		this->listenSocket=INVALID_SOCKETFD;
	}
#if USE_SSL
	if(this->anonListenSocket!=INVALID_SOCKETFD) {
		closesocket(this->anonListenSocket);
		this->anonListenSocket=INVALID_SOCKETFD;
	}
#endif
	closeAllConnections(this);
	closeLogFile(this);
	removePidFile(this);
	closeErrorLogFile(this);
	clearStringCache(&this->ipAddresses);
	clearStringCache(&this->macAddresses);
	clearStringCache(&this->authenticatedUsers);
	clearAnonProxy(&this->anonProxy);
}

static int
checkCleanCache(Server *this)
{
	time_t t=time(NULL);

	assert(this!=NULL);

	if(t<this->nextCleanCache) {
		return 0;
	}
	if(findCacheItems(&this->cleanCache)) {
		removeCacheItems(&this->cleanCache,((LONG_LONG)this->maxCacheMegs)*1000000L);
		clearCleanCache(&this->cleanCache);
		this->nextCleanCache=t+(60*60*24);
		return 1;
	}
	return 1;
}

/* called when nothing much is happening */
static void
checkIdle(Server *this)
{
	assert(this!=NULL);
	checkCleanCache(this);
	if(this->logFileOut!=NULL) {
		fflush(this->logFileOut);
	}

}


static SOCKETFD
getListenSocket(Server *this,int port)
{
	struct sockaddr_in listenAddr;
	SOCKETFD listenSocket;
	int listenTimeout=0;

	assert(this!=NULL);
	assert(port!=0);

	listenSocket=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	memset(&listenAddr,0,sizeof(listenAddr));
	listenAddr.sin_family=AF_INET;
	listenAddr.sin_port=htons(port);
	if(listenSocket==INVALID_SOCKETFD) {
		errorLog(this,"Cannot start server: %s\n",sockErrorStr());
	}

	while(1) {
		if(bind(listenSocket,(struct sockaddr *)&listenAddr,sizeof(listenAddr))<0) {
			if(
#ifndef _WIN32
			errno!=EADDRINUSE || 
#endif
			listenTimeout++>20) {
				errorLog(this,"Cannot start server, not going to wait around: %s\n",sockErrorStr());
				closesocket(listenSocket);
				return INVALID_SOCKETFD;
			}
			errorLog(this,"waiting for port %i to become available: %s\n",port,sockErrorStr());
			Sleep(5000);
			continue;
		}
		break;
	}
	if(listen(listenSocket,16)<0) {
		errorLog(this,"Cannot listen on port server: %s\n",sockErrorStr());
		return 0;
	}
	debugLog(5,"Listening on port:%i, fd:%i\n",port,listenSocket);

	return listenSocket;
}


static int
checkAnonSetup(Server *this)
{
	assert(this!=NULL);

	if(!isUseAnon(&this->anonProxy)) { return 1; }
#if USE_SSL
	if(this->anonListenSocket==INVALID_SOCKETFD) {
		if((this->anonListenSocket=getListenSocket(this,this->anonProxy.listenPort))==INVALID_SOCKETFD) {
			return 0;
		}
	}
	if(this->sslCtx==NULL) {
		this->sslCtx=newSSLCtx(this);
	}
#endif
	return 1;
}

static Connection *
acceptNewConnection(Server *this,SOCKETFD listenSocket) 
{
	struct sockaddr_in acceptAddr;
	int newSock;
	Connection *newConn;
	socklen_t acceptAddrLen=sizeof(acceptAddr);

	assert(this!=NULL);
	newSock=accept(listenSocket,(struct sockaddr *)&acceptAddr,&acceptAddrLen);
	nonBlockSocket(newSock,1);
	newConn=getNewConnection(this,NULL);
	newConn->conn=newSock;
	newConn->flags|=CONNECTION_SOCKET_CONNECTED|CONNECTION_DNS_DONE_PROCESSED;
	newConn->userAddr=acceptAddr.sin_addr.s_addr;
	newConn->userPort=ntohs(acceptAddr.sin_port);
	debugLog(5,"Accept:%x: from:%s:%i\n",(unsigned int)newConn,inet_ntoa_l(newConn->userAddr),newConn->userPort);
	return newConn;
}

#if USE_SSL
static Connection *
acceptNewSSLConnection(Server *this,SOCKETFD listenSocket) 
{
	Connection *newConn;
	BIO *bio;
	int r;

	assert(this!=NULL);
	assert(listenSocket!=INVALID_SOCKETFD);
	newConn=acceptNewConnection(this,listenSocket);
	debugLog(5,"Accept SSL:%x, fd:%i from:%s:%i\n",(unsigned int)newConn,newConn->conn,inet_ntoa_l(newConn->userAddr),newConn->userPort);
#if 1
	if((bio=BIO_new_socket(newConn->conn,0))==NULL
#endif
	|| (newConn->ssl=SSL_new(this->sslCtx))==NULL
	) {
		errorConnection(newConn,"SSL error: %s",ERR_error_string(ERR_get_error(),NULL));
		return newConn;
	}

#if 0
	SSL_set_fd(newConn->ssl,newConn->conn);
	bio=SSL_get_rbio(newConn->ssl);
#else
	SSL_set_bio(newConn->ssl,bio,bio);
	BIO_set_nbio_accept(bio,1);
	BIO_set_nbio(bio,1);
#if 0
	SSL_set_accept_state(newConn->ssl);
#endif
#endif
	newConn->sslBIO=bio;

	debugLog(25,"accepting..\n");
	if((r=SSL_accept(newConn->ssl))<0) {
		int sslErr=SSL_get_error(newConn->ssl,r);
		if(sslErr!=SSL_ERROR_WANT_READ && sslErr!=SSL_ERROR_WANT_WRITE) {
			errorConnection(newConn,"SSL accept error: %s",ERR_error_string(sslErr,NULL));
		}
	}
	debugLog(25,"new SSL: %x\n",(unsigned int)newConn->ssl);

	return newConn;
}
#endif


static const char serverInfoFile[]="./server.info";

static void
saveServerInfo(Server *this)
{
	FILE *fd;

	assert(this!=NULL);

	debugLog(20,"Save server info to: %s\n",serverInfoFile);
	if((fd=pserver_fopen(serverInfoFile,"wb"))==NULL) {
		errorLog(this,"cannot save to server info file: %s,err:%s\n",serverInfoFile,pserver_strerror(errno));
		return;
	}
	writeServerStats(&this->webStats,fd);
	writeServerStats(&this->cachedStats,fd);
	writeServerStats(&this->nonWebStats,fd);
	writeServerStats(&this->anonStats,fd);
	fclose(fd);
}

static void
readServerInfo(Server *this)
{
	FILE *fd;

	assert(this!=NULL);

	debugLog(20,"Read server info from: %s\n",serverInfoFile);
	if((fd=pserver_fopen(serverInfoFile,"rb"))==NULL) {
		/* errorLog(this,"cannot read server info file: %s,err:%s\n",serverInfoFile,pserver_strerror(errno)); */
		return;
	}
	readServerStats(&this->webStats,fd);
	readServerStats(&this->cachedStats,fd);
	readServerStats(&this->nonWebStats,fd);
	readServerStats(&this->anonStats,fd);
	fclose(fd);
}

/* 
 * The main server loop
 */
int
startServer(Server *this)
{
	time_t nextSaveServerInfo=-1;
#ifdef USE_POLL
	struct pollfd *fds=NULL;
#endif

	assert(this!=NULL);

	readServerInfo(this);
	thread_setup();
	writePidFile(this);
	if(!openLogFile(this)) { return 0; }

	/* save/read key when restarting */
	readAnonKeys(&this->anonProxy);

	if((this->listenSocket=getListenSocket(this,this->listenPort))==INVALID_SOCKETFD) {
		return 0;
	}


	/* main loop.... */
	while(1) {
#ifdef USE_POLL
		struct pollfd *fdsUpto,*fdsEnd;
#else
		fd_set rFds;
		fd_set wFds;
		fd_set eFds;
		struct timeval selectTimeout;
		unsigned int fdMax;
#endif
		int listenSockets=1;
		int readFileFds;
		Connection *conn;
		int fdsSelected;
		time_t currentTime;

		readFileFds=0;

		assertServer(this);
		if(this->serverFlags&SERVER_SHUTDOWN && (this->shutdownConnection==NULL || isStringBufEmpty(&this->shutdownConnection->writeBuf))) {
			/* shutting down and shutdown message has been sent */
			saveServerInfo(this);
			break;
		}
		currentTime=time(NULL);
		if(currentTime>=nextSaveServerInfo) {
			nextSaveServerInfo=currentTime+(60*10);
			saveServerInfo(this);
		}
		checkConfig(this,currentTime);
		if(!checkAnonSetup(this)) { break; }
		checkTimeouts(this);


#ifdef USE_POLL

		if(fds!=NULL) { free(fds); }
		fds=pserver_malloc(sizeof(fds[0])*(this->totalConnections+2));
		fds[0].fd=this->listenSocket;
		fds[0].events=POLLIN|POLLPRI;
		fds[0].revents=0;
		fdsUpto=fds+1;
#if USE_SSL
		if(isUseAnon(&this->anonProxy)) {
			assert(this->anonListenSocket!=INVALID_SOCKETFD);
			fdsUpto->fd=this->anonListenSocket;
			fdsUpto->events=POLLIN|POLLPRI;
			fdsUpto->revents=0;
			listenSockets++;
			fdsUpto++;
		}
#endif

#else

		selectTimeout.tv_sec=5;
		selectTimeout.tv_usec=0;

		fdMax=0;
		FD_ZERO(&rFds);
		FD_ZERO(&eFds);
		FD_ZERO(&wFds);
		assert(this->listenSocket>0);
		FD_SET(this->listenSocket,&rFds);
		if(this->listenSocket>fdMax) { fdMax=this->listenSocket; }
#if USE_SSL
		if(isUseAnon(&this->anonProxy)) {
			assert(this->anonListenSocket>0);
			FD_SET(this->anonListenSocket,&rFds);
			if(this->anonListenSocket>fdMax) { fdMax=this->anonListenSocket; }
			listenSockets++;
		}
#endif
#endif

		for(conn=this->firstConnection; conn!=NULL; conn=conn->nextConnection) {
#ifndef NDEBUG
			assertConnection(conn);
#endif
			if(conn->conn==INVALID_SOCKETFD) { continue; }
#ifdef DONT_SELECT_FILE_FDS
			/* windows select() won't work on file fds */
			if(conn->flags&CONNECTION_READ_CACHE) {
				if(readBufferOk(conn)) {
					readFileFds++;
				}
				continue;
			}
#endif
			if(conn->flags&CONNECTION_READ_AGAIN) {
				readFileFds++;
				continue;
			}

#ifdef USE_POLL
			fdsUpto->events=0;
			fdsUpto->fd=conn->conn;
#else
			assert(conn->conn>0);
			FD_SET(conn->conn,&eFds);
			if(conn->conn>fdMax) { fdMax=conn->conn; }
#endif

			/* don't read if the other side has got too much stuff to send in the queue */
			if(readBufferOk(conn)) {
				debugLog(20,"%x: pollread(web:%x): fd:%i, port:%i, %s\n",
					(unsigned int)conn,
					conn->flags&CONNECTION_WEB_CONNECTION,
					conn->conn,
					conn->flags&CONNECTION_WEB_CONNECTION?conn->hostPort:conn->userPort,
					conn->url);
#ifdef USE_POLL
				fdsUpto->events|=POLLIN|POLLPRI;
			}
			fdsUpto->events|=POLLERR|POLLHUP;
#else
				assert(conn->conn>0);
				FD_SET(conn->conn,&rFds);
			}
#endif
#if DEBUGLVL >=25
	{
		struct timeb t;
		ftime(&t);
		debugLog(25,"%x:%i.%03i: poll: fd:%i, other:%x %s,head:%i\n",(unsigned int)conn,(int)t.time,(int)t.millitm,conn->conn,(unsigned int)conn->otherConnection,conn->url,conn->headerLineUpto);
	}
#endif

			if(writeBufferOk(conn)) {
				debugLog(20, "pollwrite: %x,fd:%i\n",(unsigned int)conn,conn->conn);

#ifdef USE_POLL
				fdsUpto->events|=POLLOUT;
			}
			fdsUpto->revents=0;
			fdsUpto++;
#else
				assert(conn->conn>0);
				FD_SET(conn->conn,&wFds);
			}
#endif
		}
#ifdef USE_POLL
		fdsEnd=fdsUpto;
		debugLog(25,"poll: total:%i, filefds:%i\n",(fdsEnd-fds),readFileFds);
#endif


#ifdef USE_POLL
		if((fdsSelected=poll(fds,fdsEnd-fds,readFileFds>0?0:5000))==0) {
			/* nothing happening see if we should clean the cache */
			if(readFileFds==0) {
				checkIdle(this);
			       	continue; 
			}
		}
#else
		if(readFileFds>0) {
			/* we will definately have a select read on a local file fd, lets not wait around */
			selectTimeout.tv_sec=0;
			selectTimeout.tv_usec=1;
		}


		if((fdsSelected=select(fdMax+1,&rFds,&wFds,&eFds,&selectTimeout))==0) {
			/* we're not idle if we've just quickly selected file fds */
			if(readFileFds==0) {
				checkIdle(this);
			       	continue; 
			}
		}
#endif
		if(fdsSelected<0) {
			errorLog(this,"problem with select/poll: %s\n",sockErrorStr());
		}

	/********** select/poll finished **********/

#if DEBUGLVL >=20
	{
		struct timeb t;
		ftime(&t);
		debugLog(20,"poll done: %i.%03i, fds:%i\n",(int)t.time,(int)t.millitm,fdsSelected);
	}
#endif
		if(
#ifdef USE_POLL
			fds[0].revents&(POLLIN|POLLPRI)
#else
			FD_ISSET(this->listenSocket,&rFds)
#endif
		) {
			acceptNewConnection(this,this->listenSocket);
			/* we have to continue here,
			 * the next loop depends on the connection list
			 * being in the same order.
			 */
			continue;
		}

#if USE_SSL
		if(isUseAnon(&this->anonProxy) &&
#ifdef USE_POLL
			fds[1].revents&(POLLIN|POLLPRI)
#else
			FD_ISSET(this->anonListenSocket,&rFds)
#endif
		) {
			acceptNewSSLConnection(this,this->anonListenSocket);
			/* we have to continue here,
			 * the next loop depends on the connection list
			 * being in the same order.
			 */
			continue;
		}
#endif

#ifdef USE_POLL
		fdsUpto=fds+listenSockets;
#endif
		conn=this->firstConnection;
		while(conn!=NULL) {
			Connection *nextConn;
			nextConn=conn->nextConnection;

			if(conn->conn==INVALID_SOCKETFD) { 
				/* fds would not be set if this was an invalid socketfd 
				 * lets go to the next connection.
				 */
				conn=nextConn;
				continue;
			}


			if(conn->flags&CONNECTION_READ_AGAIN
#ifdef DONT_SELECT_FILE_FDS
			|| conn->flags&CONNECTION_READ_CACHE
#endif
			) {
				conn->flags&=-1^CONNECTION_READ_AGAIN;
				debugLog(20,"%x: reading without select/poll\n",(unsigned int)conn);
				if(!readConnection(conn)) {
					closeConnection(conn);
				}
				conn=nextConn;
				continue;
			}

#ifdef USE_POLL
			assert(conn->conn==fdsUpto->fd);
			assert(fdsUpto<fdsEnd);
#endif
 
			if(conn->flags&CONNECTION_CLOSE) {
				closeMarkedConnection(this,conn);
#ifdef USE_POLL
			} else if(fdsUpto->revents&(POLLHUP)) {
				int close=1;
				/* don't close on dns lookups */
				debugLog(10,"hup: %x closing\n",(unsigned int)conn);
				/* we're not connected this this host anymores... */
				if(isReconnectOk(conn)) {
					if(connectToNextAddress(conn)==INVALID_SOCKETFD) {
						if(isToProxy(conn)) {
							sendDiagnoseMessage(conn,"Could not connect to any proxy");
						} else {
							sendDiagnoseMessage(conn,"Could not connect");
						}
					} else { close=0; }
				}
				if(close) {
					closeConnection(conn);
				}
			} else if(fdsUpto->revents&(POLLERR)) {
#else
			} else if(FD_ISSET(conn->conn,&eFds)) {
#endif
				/* try other looked up ip addresses if any */
				if(!isReconnectOk(conn)
				|| connectToNextAddress(conn)==INVALID_SOCKETFD) {
					debugLog(10,"connerror:%x,%s\n",(unsigned int)conn,sockErrorStr());
					sendDiagnoseMessage(conn,"Error with connection");
					closeConnection(conn);
				}
			} else {

				if(
#ifdef USE_POLL
				fdsUpto->revents&(POLLIN|POLLPRI)
#else
				FD_ISSET(conn->conn,&rFds)
#endif
				) {
					if(conn->pipeFds[0]==conn->conn) {
						finishDnsThread(conn);
					} else if(!readConnection(conn)) {
						closeConnection(conn);
					}
				} else if(
#ifdef USE_POLL
					fdsUpto->revents&(POLLOUT)
#else
					FD_ISSET(conn->conn,&wFds)
#endif
				) {
					if(!writeConnection(conn)) {
						closeConnection(conn);
					}
				}
			}
/* nextConnJump:; */
#ifdef USE_POLL
			fdsUpto++;
#endif
			conn=nextConn;
		}
	}
#ifdef USE_POLL
	if(fds!=NULL) { free(fds); }
#endif
	clearServer(this);
	thread_cleanup();
	return 1;
}


#ifndef NDEBUG
void
assertServer(Server *this) 
{
	int c;
	Connection *conn;

	assert(this!=NULL);
	assert(this->configFile!=NULL);
	if(this->configFileLoaded==0) {
		return;
	}
	/* config file loaded, everything else should be started */
	assert(this->configFileLoaded<time(NULL));
	assert(this->pid_file!=NULL);
	assert(this->ourUrl!=NULL);
	assert(this->logFile!=NULL);
	assert(this->errorOut!=NULL);
	assert(this->listenSocket!=INVALID_SOCKETFD);

	/* check the list of connections are ok */
	if(this->firstConnection!=NULL) {
		assert(this->firstConnection->prevConnection==NULL);
	}
	conn=this->firstConnection;
	c=0;
	while(conn!=NULL) {
		if(conn->nextConnection!=NULL) {
			assert(conn->nextConnection->prevConnection==conn);
		}
		c++;
		conn=conn->nextConnection;
	}
	assert(this->totalConnections==c);

	for(c=0; c<this->totalAccesses; c++) {
		assertAccess(this->accesses+c);
	}
	assertStringCache(&this->authenticatedUsers);
	assertStringCache(&this->macAddresses);
	assertStringCache(&this->ipAddresses);
	assertServerStats(&this->webStats);
	assertServerStats(&this->cachedStats);
	assertServerStats(&this->nonWebStats);
	assertServerStats(&this->anonStats);
}

#endif


