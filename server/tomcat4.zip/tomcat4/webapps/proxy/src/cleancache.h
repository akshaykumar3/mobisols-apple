#ifndef __CLEANCACHE_H
#define __CLEANCACHE_H

typedef struct CleanCacheItem {
	unsigned long fileNum;
	int fileNum2;
	time_t lastAcc;
	time_t size;
}CleanCacheItem;

typedef struct CleanCacheDir {
	DIR *dir;
	char *dirName;
}CleanCacheDir;

typedef struct CleanCache {
	CleanCacheDir *dirs;
	int uptoDirs,totalDirs;
	CleanCacheItem *cacheItems;
	struct Server *server;
	int totalCacheItems,uptoCacheItems;
	unsigned LONG_LONG totalBytes;
	int done;
}CleanCache;


int findCacheItems(CleanCache *this);
int removeCacheItems(CleanCache *this,LONG_LONG maxBytes);
void clearCleanCache(CleanCache *this);


#endif
