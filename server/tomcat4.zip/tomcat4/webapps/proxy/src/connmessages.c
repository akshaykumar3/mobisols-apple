
#include "pserver.h"
#include "server.h"
#include "connection.h"
#include "usagestats.h"
#include "connmessages.h"

/* messages *********************************/

#undef USE_JS_ERRORS

void
sendBaseHref(Connection *this)
{
	assert(this!=NULL);

#ifdef USE_JS_ERRORS	
	appendWriteBufStatic(this,"<script type='text/javascript'>\nanonProxyServerUrl='");
	appendWriteBufVar(this,this->server->ourUrl);
	appendWriteBufStatic(this,"';\nfunction printImg(url) { document.writeln(anonProxyServerUrl+url);\n}\n</script>");
#else
	appendWriteBufStatic(this,"<base href=\"");
	appendWriteBufVar(this,this->server->ourUrl);
	appendWriteBufStatic(this,"\">");
#endif
}

static void
getWriteBaseHrefJs(Connection *this,char *dest,int destLen,const char *prefix,const char *suffix) 
{
	assert(this!=NULL);
	assert(dest!=NULL);
	assert(destLen>0);
	assert(prefix!=NULL);
	assert(suffix!=NULL);

#ifdef USE_JS_ERRORS	
	snprintf(dest,destLen,"<script type='text/javascript'>\ndocument.write(\"%s\"); document.write(anonProxyServerUrl); document.write(\"%s\");\n</script>\n",prefix,suffix);
#else
	snprintf(dest,destLen,"%s%s",prefix,suffix);
#endif
}

static void
sendWithBaseHref(Connection *this,const char *prefix,const char *suffix) 
{
	char dest[4096];

	assert(this!=NULL);
	assert(prefix!=NULL);
	assert(suffix!=NULL);

	getWriteBaseHrefJs(this,dest,sizeof(dest),prefix,suffix);
	appendWriteBufVar(this,dest);
}


void
errorConnectionMess(Connection *this,const char *mess,const char *httpMess)
{
	Connection *userConn;

	assert(this!=NULL);
	assert(mess!=NULL);
	assert(httpMess!=NULL);

	userConn=(this->flags&CONNECTION_WEB_CONNECTION)?this->otherConnection:this;

	if(this->flags&CONNECTION_SOCKS) {
		if(!isHeaderDone(this)) {
			static char errReply[]={5,1,0,1,0,0,0,0,0,0};
			appendWriteBuf(userConn,errReply,sizeof(errReply));
		}
		return;
	}
	if(userConn->url==NULL) {
		/* maybe an error on a keep-alive? */
		return;
	}

	if(userConn->sentLen==0 && isStringBufEmpty(&userConn->writeBuf)) {
		char googleUrl[MAX_URL_LEN];
		int status;
		assert(userConn->url!=NULL);
		debugLog(5,"send error mess:%s\n",mess);
		appendWriteBufStatic(userConn,"HTTP/1.0 ");
		status=atoi(httpMess);
		if(userConn->otherConnection!=NULL) {
			userConn->otherConnection->status=status;
		}
		appendWriteBufVar(userConn,httpMess);
		appendWriteBufStatic(userConn,"\r\nContent-Type: text/html\r\nPragma: no-cache\r\nCache-control: no-cache\r\nAnon-Proxy: message\r\n\r\n<html><head><title>Error</title></head>");
		if(!(userConn->anonFlags&CONNECTION_FROM_PROXY)) {
			sendBaseHref(userConn);
		}
		appendWriteBufStatic(userConn,"<body>");
		sendWithBaseHref(userConn,"<link rel=stylesheet href='","anon_proxy_server.css' /><center>");
		appendWriteBufStatic(userConn,"<table border=0><tr><td class=etd>");
		sendWithBaseHref(userConn,"<img src='",this->errorImg==NULL?"img/question.jpg":this->errorImg);
		appendWriteBufStatic(userConn,"' /></td><td class=etd><h2>");
		appendWriteBufVar(userConn,mess);

		if(status!=403 && userConn->flags&CONNECTION_CMD_GET) {
			appendWriteBufStatic(userConn,"<p /><a href=\"http://www.google.com/search?q=cache%3a");
			encodeUrl(googleUrl,sizeof(googleUrl),userConn->url);
			appendWriteBufVar(userConn,googleUrl);
			appendWriteBufStatic(userConn,"\">Search Google Cache</a>");
		}

		appendWriteBufStatic(userConn,"</h2></td></table><br /><br />");
		if(userConn->flags&CONNECTION_CMD_GET) {
			appendWriteBufStatic(userConn,"<a class=smallf href=\"");
			appendWriteBufVar(userConn,userConn->url);
			appendWriteBufStatic(userConn,"\">");
			appendWriteBufVar(userConn,userConn->url);
			appendWriteBufStatic(userConn,"</a><br /><table border=0><tr><td class=etd><font class=smallf><script language=javascript>\n\nvar d=new Date(); document.writeln(d.toString());\n\n</script></font></td></table>\n");
		}
		appendWriteBufStatic(userConn,"</center></body></html>");
	}
}



void
errorConnection(Connection *this,const char *mess,...)
{
	char messBuf[8196];
	va_list args;

	assert(this!=NULL);
	assert(mess!=NULL);

	va_start(args,mess);
	pserver_vsnprintf(messBuf,sizeof(messBuf),mess,args);
	va_end(args);

	errorConnectionMess(this,messBuf,"404 Error");
}

void
messConnection(Connection *this,const char *status, const char *mess,...)
{
	char messBuf[8196];
	int len;
	va_list args;

	assert(this!=NULL);
	assert(status!=NULL);
	assert(mess!=NULL);

	if(this->sentLen>0) { return; }

	va_start(args,mess);
	len=pserver_vsnprintf(messBuf,sizeof(messBuf),mess,args);
	va_end(args);
	appendWriteBufStatic(this,"HTTP/1.0 ");
	appendWriteBufVar(this,status);
	appendWriteBufStatic(this,"\r\nContent-Type: text/html\r\n\r\n<html><body>");
	appendWriteBuf(this,messBuf,len);
	appendWriteBufStatic(this,"</body></html>");

}

void
sendDiagnoseMessage(Connection *this, const char *mess)
{
	char timedOutMess[4096];
	char link[4096];
	char linkSuffix[4096];

	assert(this!=NULL);
	assert(mess!=NULL);

	snprintf(linkSuffix,sizeof(linkSuffix),"diagconnect.php?host=%s&port=%i'>",
		this->parsedUrl.host,this->parsedUrl.port);
	getWriteBaseHrefJs(this,link,sizeof(link),"<a href='",linkSuffix);
	snprintf(timedOutMess,sizeof(timedOutMess),"%s<p />%sDiagnose Connection</a><br />",
		mess,link);
	errorConnection(this,timedOutMess);
}


void
logConnection(Connection *this)
{
	const char *cache;
	struct timeb tv;
	long msecDiff;
	char *qmark;
	char proxyBuf[64];
	char url[MAX_URL_LEN]="";

	assert(this!=NULL);
	assert(this->url!=NULL);



	if(!(this->flags&CONNECTION_WEB_CONNECTION)
	|| this->flags&CONNECTION_CMD_INTERNAL
	|| this->server->logFileOut==NULL)  { 
		return;
	}


	updateConnServerStats(this,totalRequests++);
	calcConnectionStats(this->server,this);
	if(isProxyKeyOk(this) && isAnonLogs(&this->server->anonProxy)) {
		return;
	}
	if(this->server->maxLogFileSize<=0 || this->server->maxLogRotate<=0) {
		/* no logging */
		return;
	}

	ftime(&tv);
	if(this->flags&CONNECTION_USING_UNEXPIRED) {  cache="unexpired"; }
	else if(this->flags&CONNECTION_READ_CACHE) {  cache="read"; }
	else if(this->flags&CONNECTION_WRITE_CACHE) {  cache="write"; }
	else if(this->flags&(CONNECTION_NO_READ_CACHE)) { cache="no-read"; }
	else if(this->flags&(CONNECTION_NO_WRITE_CACHE)) {  cache="no-write"; }
	else {  cache="none"; }

	msecDiff=getMSecDiff(&tv,&this->startTime);

	if((qmark=strchr(this->url,'?'))!=NULL) {
		strncpy(url,this->url,qmark-this->url);
	}

	if(isToProxy(this)) {
		snprintf(proxyBuf,sizeof(proxyBuf),"proxy:%s:%i",inet_ntoa_l(this->hostAddr),ntohs(this->hostPort));
	} else {
		qstrncpy(proxyBuf,inet_ntoa_l(this->hostAddr),sizeof(proxyBuf));
	}
	fprintf(this->server->logFileOut,"%x\t%s\t%s%s:%i\t%s\t%i%s\t%li.%03li\t%i\t%s\t%s\t%s\n",
		(unsigned int)time(NULL),cache,
		isProxyKeyOk(this)?"proxy:":"",
		inet_ntoa_l(this->userAddr),
		ntohs(this->userPort),
		this->authUser==NULL?"":this->authUser,
		this->recvBodyLen,
		(this->webContentLength>0 && this->recvBodyLen!=this->webContentLength)?"incomplete":"",
		msecDiff/1000,
		msecDiff%1000,
		this->status,
		this->flags&CONNECTION_SOCKS?"SOCKS":this->cmd,
		proxyBuf,
		url[0]==0?this->url:url
		);

	if(ftell(this->server->logFileOut)>this->server->maxLogFileSize) {
		rotateLogFile(this->server);
	}
	if(time(NULL)>this->server->nextLogFileFlush) {
		fflush(this->server->logFileOut);
		this->server->nextLogFileFlush=time(NULL)+2;
	}
}

