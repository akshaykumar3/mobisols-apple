#ifndef __USAGESTATS_H
#define __USAGESTATS_H

typedef struct UsageStats {
	LONG_LONG totalRequests;
	LONG_LONG totalBytes;
}UsageStats;

/*
 * Server usage statistics
 */
typedef struct ServerStats {
	UsageStats total;
	UsageStats hours[24];
	UsageStats dayOfWeek[7];

	/* Everything after this isn't saved to disk on restart... */
	time_t startTime;
	time_t currentHourEnd;
	struct tm currentHour;
}ServerStats;


struct Connection;

void sendUsageStatsArray(struct Connection *this,
	UsageStats *usages,int total,const char *name,
	const char *totalName);

void writeServerStats(ServerStats *this,FILE *fd);
void readServerStats(ServerStats *this,FILE *fd);

void calcServerStatsHour(ServerStats *this,time_t t);
void calcConnectionStats(struct Server *this,struct Connection *conn);

#ifndef NDEBUG
void assertServerStats(ServerStats *this);
#else
#define assertServerStats(x)
#endif




STATIC_INLINE void
updateServerStatsHour(ServerStats *this)
{
	time_t t;

	t=time(NULL);
	if(this->currentHourEnd==0 || t>=this->currentHourEnd) { calcServerStatsHour(this,t); }
}


#define updateServerStats(tstats,upd)	\
{	\
	ServerStats *t=tstats;		\
	updateServerStatsHour((t));	\
	(t)->dayOfWeek[(t)->currentHour.tm_wday].upd;	\
	(t)->hours[(t)->currentHour.tm_hour].upd;	\
	(t)->total.upd;	\
}

#define updateConnServerStats(conn,upd) \
{	\
	if(conn->flags&CONNECTION_READ_CACHE) {	\
		updateServerStats(&conn->server->cachedStats,upd);	\
	}	\
	if(conn->anonFlags&CONNECTION_PROXY_KEY_OK) {	\
		updateServerStats(&conn->server->anonStats,upd);	\
	}	\
	if(conn->flags&CONNECTION_SOCKS) {	\
		updateServerStats(&conn->server->nonWebStats,upd);	\
	} else {	\
		updateServerStats(&conn->server->webStats,upd);	\
	}	\
}


#endif
