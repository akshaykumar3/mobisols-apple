

#include "pserver.h"
#include "stringbuf.h"

/* StringBuf *****************************************/




void
allocStringBuf(StringBuf *this,int len)
{
	assert(this!=NULL);
	if(this->readUpto>32000) {
		/* recreate when len is up to a certian point */
		char *newBuf;

		this->len=(this->upto-this->readUpto)+len+8196;
		newBuf=pserver_malloc(this->len);
		memcpy(newBuf,this->buf+this->readUpto,this->upto-this->readUpto);
		free(this->buf); this->buf=newBuf;
		this->upto-=this->readUpto;
		this->readUpto=0;

		debugLog(10,"realloc string buf: %x,len:%i\n",(unsigned int)this,this->len);
	}
	else if(this->buf==NULL || (this->upto+len+1)>=this->len) {
		int allocMore;
		/* lets get more */
		allocMore=this->buf==NULL && len<4096?4096:32784;
		this->len+=len>allocMore?len:allocMore;
		this->buf=realloc(this->buf,this->len);
	}
}


void
appendStringBuf(StringBuf *this,const char *data,int len)
{
	assert(this!=NULL);
	assert(data!=NULL);
	assert(len>=0);

	if(len==0) { return; }
	if(isStringBufEmpty(this)) { 
		this->readUpto=this->upto=0; 
	}
	allocStringBuf(this,len);
	memcpy(this->buf+this->upto,data,len);
	this->upto+=len;
	this->buf[this->upto]=0;
}

void
appendStringBufFromStringBuf(StringBuf *this,StringBuf *from)
{
	assert(this!=NULL);
	assert(from!=NULL);

	if(isStringBufEmpty(from)) { return; }
	appendStringBuf(this,
		from->buf+from->readUpto,
		from->upto-from->readUpto);
}


/* get a line from string buf excluding lf */
int
getLineFromStringBuf(StringBuf *this,StringBuf *destLine)
{
	char *p,*start,*bufEnd;
	int len;

	assert(this!=NULL);
	assert(destLine!=NULL);
	if(isStringBufEmpty(this)) { return -1; }
	start=p=this->buf+this->readUpto;
	bufEnd=this->buf+this->upto;
	while(*p!='\n') { 
		if(p>=bufEnd) { return -1; }
		p++; 
	}
	len=(p-start);
	appendStringBuf(destLine,start,len);
	this->readUpto+=len+1;
	return len;
}

void
clearStringBuf(StringBuf *this)
{
	assert(this!=NULL);
	if(this->buf!=NULL) { free(this->buf); this->buf=NULL; }
	this->len=this->readUpto=this->upto=0;
}



