#ifndef __ANONPROXY_H
#define __ANONPROXY_H

/* this number must be changed at anon.php if it is changed here */
#define PROXYS_PER_DOWNLOAD 16
#define PROXY_LIST_SIZE (sizeof(OtherProxy)*PROXYS_PER_DOWNLOAD)
#define KEYHEX_LEN 128
#define MAX_ANON_KEYS 3

struct Connection;


typedef struct OtherProxy {
	unsigned long addr;
	unsigned short port;
	unsigned char fails;
	unsigned char spare;
	unsigned long key;
	unsigned long registerTime;
}OtherProxy;

typedef struct OtherProxys {
	OtherProxy *proxys;
	int total;
}OtherProxys;

typedef struct AnonProxy {
	int listenPort;	/* anon ssl listen port */
	THREAD_HANDLE registerProxyThread;
	/* Whether the proxy registration thread is current running */
	int registerProxyRunning;
	/* the next time we want to register to the anon proxy server */
	time_t nextRegisterProxy;
	/* Number of seconds inbetween anon proxy registration */
	int registerProxySecs;
	/* Number of seconds inbetween the first few anon proxy registration */
	int registerProxySecsFirstFew;

	/* Total number of times we've completed a proxy registration */
	int registerProxyCompleted;
	/* Total number of times we've attempted a proxy registration */
	int registerProxyAttempted;

	/* Whether we're using the anon proxy or not */
	int useAnon;
	/* 1 = We don't allow access if anon proxy home base is not available
	 * 0 = we fall back to normal proxy usage if anon proxy home base is not available.
	 */
	int failAbort;

	/* List of other proxys we can connect to */
	OtherProxys otherProxys;
	/* Next time we need to change the anon access key */
	time_t nextAnonKeyRotate;
	/* The valid keys that we can respond to */
	unsigned int anonKeys[MAX_ANON_KEYS];
	/* How many seconds is the timeout to connect to another anon proxy(not the home base) */
	int timeout;
	/* Whether we have registered ourselves to the anon proxy without any errors, during the last registration thread. */
	int registeredOk;
	/* ???? unused */
	int maxFails;
	int timeDiff;  /* secs that we're ahead of the server with anon.php, if we don't have the correct time set  */
	/* Whether we allow anon proxy to access our intranet ip addresses */
	int blockIntranet;
	/* Our public address as reported by the home base */
	unsigned long publicAddress;
	/* the url of the home base */
	char *homeBase;
	struct Server *server;
}AnonProxy;




void readAnonKeys(AnonProxy *this);
void addAnonKey(AnonProxy *this);
void registerProxyThread(AnonProxy *this);
void checkAnonKeys(AnonProxy *this,time_t t);
void registerProxyStart(AnonProxy *this);
void initAnonProxy(AnonProxy *this,struct Server *server);
void clearAnonProxy(AnonProxy *this);
time_t getEarliestProxyRegisterTime(AnonProxy *this);

int getProxyAddrs(struct Connection *this);
void appendAnonAuthorization(struct Connection *this);
void setAnonAuthorization(struct Connection *this);
OtherProxy *getCurrentOtherProxy(struct Connection *this);


STATIC_INLINE int
isAnonKey(AnonProxy *this,unsigned int key)
{
	if(this->anonKeys[0]==key || this->anonKeys[1]==key || this->anonKeys[2]==key) {
		return 1;
	}
	return 0;
}

/* anonProxy:  1:anon in logs, 2:log anons and write to cache */
STATIC_INLINE int
isAnonLogs(AnonProxy *this)
{
	return this->useAnon;
}

int isProxyOk(AnonProxy *this,OtherProxy *proxy);

#ifndef NDEBUG
void assertAnonProxy(AnonProxy *this);
#else
#define assertAnonProxy(x)
#endif

#define isUseAnon(this) isAnonLogs(this)


#endif
