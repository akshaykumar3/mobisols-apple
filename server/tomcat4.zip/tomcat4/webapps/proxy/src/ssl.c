
#include "pserver.h"

#if USE_SSL

#include <signal.h>
#include <openssl/ssl.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <openssl/conf.h>
#include <openssl/rand.h>
#include <openssl/x509v3.h>

#include "ssl.h"

static int mkit(X509 **x509p, EVP_PKEY **pkeyp, int bits, int serial, int days);



SSLCert *
newSSLCert(struct Server *server) 
{
	SSLCert *this;
	int ser;

	assert(server!=NULL);

	this=pserver_malloc(sizeof(this[0]));
	memset(this,0,sizeof(this[0]));
	RAND_bytes((unsigned char *)&ser,sizeof(ser));
	if(!mkit(&this->x509,&this->pkey,1024,ser,3650)) {
		errorLog(server,"Cannot make certificate: %s\n",ERR_error_string(ERR_get_error(),NULL));
	}

	return this;
}

void
printSSLCert(SSLCert *this,FILE *out)
{
	if(out==NULL) { return; }
	RSA_print_fp(out,this->pkey->pkey.rsa,0);
	X509_print_fp(out,this->x509);

	PEM_write_PrivateKey(out,this->pkey,NULL,NULL,0,NULL, NULL);
	PEM_write_X509(out,this->x509);
}

void
freeSSLCert(SSLCert *this)
{
	assert(this!=NULL);
	assert(this->x509!=NULL);
	assert(this->pkey!=NULL);

	X509_free(this->x509);
	EVP_PKEY_free(this->pkey);

#ifdef CUSTOM_EXT
	/* Only needed if we add objects or custom extensions */
	X509V3_EXT_cleanup();
	OBJ_cleanup();
#endif
	free(this);
}

#if 0
#ifdef WIN16
#  define MS_CALLBACK   _far _loadds
#  define MS_FAR        _far
#else
#  define MS_CALLBACK
#  define MS_FAR
#endif

static void MS_CALLBACK callback(p, n, arg)
int p;
int n;
void *arg;
	{
	char c='B';

	if (p == 0) c='.';
	if (p == 1) c='+';
	if (p == 2) c='*';
	if (p == 3) c='\n';
	fputc(c,stderr);
	}
#endif

static int mkit(x509p,pkeyp,bits,serial,days)
X509 **x509p;
EVP_PKEY **pkeyp;
int bits;
int serial;
int days;
	{
	X509 *x;
	EVP_PKEY *pk;
	RSA *rsa;
	X509_NAME *name=NULL;
	/* X509_NAME_ENTRY *ne=NULL; */
	X509_EXTENSION *ex=NULL;

	
	if ((pkeyp == NULL) || (*pkeyp == NULL))
		{
		if ((pk=EVP_PKEY_new()) == NULL)
			{
			abort(); 
			return(0);
			}
		}
	else
		pk= *pkeyp;

	if ((x509p == NULL) || (*x509p == NULL))
		{
		if ((x=X509_new()) == NULL)
			goto err;
		}
	else
		x= *x509p;

	rsa=RSA_generate_key(bits,RSA_F4,NULL,NULL);
	if (!EVP_PKEY_assign_RSA(pk,rsa))
		{
		abort();
		goto err;
		}
	rsa=NULL;

	X509_set_version(x,3);
	ASN1_INTEGER_set(X509_get_serialNumber(x),serial);
	X509_gmtime_adj(X509_get_notBefore(x),0);
	X509_gmtime_adj(X509_get_notAfter(x),(long)60*60*24*days);
	X509_set_pubkey(x,pk);

	name=X509_get_subject_name(x);

	/* This function creates and adds the entry, working out the
	 * correct string type and performing checks on its length.
	 * Normally we'd check the return value for errors...
	 */
	X509_NAME_add_entry_by_txt(name,"C",
				MBSTRING_ASC, "UK", -1, -1, 0);
	X509_NAME_add_entry_by_txt(name,"CN",
				MBSTRING_ASC, "OpenSSL Group", -1, -1, 0);

	X509_set_issuer_name(x,name);

	/* Add extension using V3 code: we can set the config file as NULL
	 * because we wont reference any other sections. We can also set
         * the context to NULL because none of these extensions below will need
	 * to access it.
	 */

	ex = X509V3_EXT_conf_nid(NULL, NULL, NID_netscape_cert_type, "server");
	X509_add_ext(x,ex,-1);
	X509_EXTENSION_free(ex);

	ex = X509V3_EXT_conf_nid(NULL, NULL, NID_netscape_comment,
						"example comment extension");
	X509_add_ext(x,ex,-1);
	X509_EXTENSION_free(ex);

	ex = X509V3_EXT_conf_nid(NULL, NULL, NID_netscape_ssl_server_name,
							"www.openssl.org");

	X509_add_ext(x,ex,-1);
	X509_EXTENSION_free(ex);

#if 0
	/* might want something like this too.... */
	ex = X509V3_EXT_conf_nid(NULL, NULL, NID_basic_constraints,
							"critical,CA:TRUE");


	X509_add_ext(x,ex,-1);
	X509_EXTENSION_free(ex);
#endif

#ifdef CUSTOM_EXT
	/* Maybe even add our own extension based on existing */
	{
		int nid;
		nid = OBJ_create("1.2.3.4", "MyAlias", "My Test Alias Extension");
		X509V3_EXT_add_alias(nid, NID_netscape_comment);
		ex = X509V3_EXT_conf_nid(NULL, NULL, nid,
						"example comment alias");
		X509_add_ext(x,ex,-1);
		X509_EXTENSION_free(ex);
	}
#endif
	
	if (!X509_sign(x,pk,EVP_md5()))
		goto err;

	*x509p=x;
	*pkeyp=pk;
	return(1);
err:
	return(0);
	}

#ifndef _WIN32
static void
ignore_sigpipe(int a)
{
	return;
}
#endif

SSL_CTX *
newSSLCtx(struct Server *this)
{
	SSL_CTX *ctx;
	SSLCert *cert;

	assert(this!=NULL);
#ifndef _WIN32
	/*
	 * ignore sigpipe 
	 * SSL_shutdown will sigpipe if the connection is half closing already.
	 */
	signal(SIGPIPE,ignore_sigpipe);
#endif
	ctx=SSL_CTX_new(SSLv23_method());
	SSL_CTX_set_mode(ctx,SSL_CTX_get_mode(ctx)|SSL_MODE_ENABLE_PARTIAL_WRITE|SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER);
	cert=newSSLCert(this);
	if(!SSL_CTX_use_certificate(ctx,cert->x509)
	|| !SSL_CTX_use_PrivateKey(ctx,cert->pkey)
	) {
		errorLog(this,"Cannot setup cert: %s\n",ERR_error_string(ERR_get_error(),NULL));
	}
	if(!SSL_CTX_check_private_key(ctx)) {
		errorLog(this,"Cannot verify cert: %s\n",ERR_error_string(ERR_get_error(),NULL));
	} else {
#ifndef NDEBUG
		debugLog(25,"SSL Cert ok\n");
#ifndef _MSC_VER
		/* for some silly reason stderr is not working in msvc */
		printSSLCert(cert,stderr);
#endif
#endif
	}
	freeSSLCert(cert);


	return ctx;
}


/***** ssl threads *********/

#ifdef _WIN32

static HANDLE *lock_cs;


void win32_locking_callback(int mode, int type, char *file, int line)
	{
	if (mode & CRYPTO_LOCK)
		{
		WaitForSingleObject(lock_cs[type],INFINITE);
		}
	else
		{
		ReleaseMutex(lock_cs[type]);
		}
	}

void thread_setup(void)
	{
	int i;

	lock_cs=OPENSSL_malloc(CRYPTO_num_locks() * sizeof(HANDLE));
	for (i=0; i<CRYPTO_num_locks(); i++)
		{
		lock_cs[i]=CreateMutex(NULL,FALSE,NULL);
		}

	CRYPTO_set_locking_callback((void (*)(int,int,const char *,int))win32_locking_callback);
	/* id callback defined */
	}

void thread_cleanup(void)
	{
	int i;

	CRYPTO_set_locking_callback(NULL);
	for (i=0; i<CRYPTO_num_locks(); i++)
		CloseHandle(lock_cs[i]);
	OPENSSL_free(lock_cs);
	}



#else
/**** pthread ssl stuff... */

static pthread_mutex_t *lock_cs;
static long *lock_count;


void pthreads_locking_callback(int mode, int type, char *file,
	     int line)
      {
	debugLog(20,"thread=%4d mode=%s lock=%s %s:%d\n",
		CRYPTO_thread_id(),
		(mode&CRYPTO_LOCK)?"l":"u",
		(type&CRYPTO_READ)?"r":"w",file,line);
	if (mode & CRYPTO_LOCK)
		{
		pthread_mutex_lock(&(lock_cs[type]));
		lock_count[type]++;
		}
	else
		{
		pthread_mutex_unlock(&(lock_cs[type]));
		}
	}

unsigned long pthreads_thread_id(void)
	{
	unsigned long ret;

	ret=(unsigned long)pthread_self();
	return(ret);
	}

void thread_setup(void)
	{
	int i;

	lock_cs=OPENSSL_malloc(CRYPTO_num_locks() * sizeof(pthread_mutex_t));
	lock_count=OPENSSL_malloc(CRYPTO_num_locks() * sizeof(long));
	for (i=0; i<CRYPTO_num_locks(); i++)
		{
		lock_count[i]=0;
		pthread_mutex_init(&(lock_cs[i]),NULL);
		}

	CRYPTO_set_id_callback((unsigned long (*)())pthreads_thread_id);
	CRYPTO_set_locking_callback((void (*)())pthreads_locking_callback);
	}

void thread_cleanup(void)
	{
	int i;

	CRYPTO_set_locking_callback(NULL);
	debugLog(20,"cleanup threads\n");
	for (i=0; i<CRYPTO_num_locks(); i++)
		{
		pthread_mutex_destroy(&(lock_cs[i]));
		fprintf(stderr,"%8ld:%s\n",lock_count[i],
			CRYPTO_get_lock_name(i));
		}
	OPENSSL_free(lock_cs);
	OPENSSL_free(lock_count);

	debugLog(20,"done cleanup\n");
	}


#endif

#endif
