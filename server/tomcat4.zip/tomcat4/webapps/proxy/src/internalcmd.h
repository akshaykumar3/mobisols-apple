#ifndef __INTERNALCMD_H
#define __INTERNALCMD_H

int internalCommand(struct Connection *this,const char *);

#endif
