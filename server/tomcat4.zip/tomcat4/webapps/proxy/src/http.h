#ifndef __HTTP_H
#define __HTTP_H

int processUserHeaderLine(Connection *this,char *httpLine);
int processWebHeaderLine(Connection *this,const char *httpLine);

#endif
