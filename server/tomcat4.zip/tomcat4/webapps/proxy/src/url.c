
#include "pserver.h"
#include "url.h"

/* urls *********************************/


void
clearUrl(Url *this)
{
	assert(this!=NULL);
	FREE_PTR(this->scheme);
	FREE_PTR(this->host);
	FREE_PTR(this->path);
	FREE_PTR(this->query);
	this->port=0;
}

/* will wreck the url */
int
parse_url(Url *this,char *url)
{
	char *colon;
	char *path;
	char *query;
	int ch;

	assert(this!=NULL);
	assert(url!=NULL);
	colon=strchr(url,':');
	if(colon==NULL) { return 0; }
	if(colon[1]=='/') {
		*colon++=0;
		this->scheme=strdup(url);
		while(*colon=='/') { colon++; }
	} else {
		/* no scheme, must have came from CONNECT */
		this->scheme=strdup("https");
		colon=url;
	}

	path=colon;
	while((ch=*path)!=0) {
		if(ch==':') {
			*path++=0;
			this->port=atoi(path);
		} else if(ch=='/') { break; }
		path++;
	}
	if(path==colon) {
		/* no host */
		this->host=strdup("");
	} else {
		*path=0;
		this->host=strdup(colon);
		*path=ch;
	}

	query=path;
	while((ch=*query)!=0) {
		if(*query=='?') { *query++=0; break; }
		query++;
	}
	this->path=strdup(path);
	this->query=strdup(query);
	debugLog(10,"parseurl: host:%s, path:%s, scheme:%s, query:%s\n",this->host,this->path,this->scheme,this->query);
	return 1;
}

static void
getHexUrlChar(char *hex,int ch) {
	assert(hex!=NULL);
	snprintf(hex,4,"%%%02x",ch);
}

void
encodeUrl(char *to, int len,const char *from)
{
	char *toEnd=to+len-4;

	assert(to!=NULL);
	assert(len>0);
	assert(from!=NULL);

	while(*from && to<toEnd) {
		int ch=*from++;
		if(isalnum(ch)) {
			*to++=ch;
			continue;
		}
		getHexUrlChar(to,ch);
		to+=3;
	}
	*to=0;
}


