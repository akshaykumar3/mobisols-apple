

#include "pserver.h"
#include "server.h"
#include "access.h"
#include "connection.h"
#include "connmessages.h"
#include "usagestats.h"
#include "anonproxy.h"


/* internal commands *********************************/





static void
sendAnonProxyStats(Connection *this)
{
	char line[1024];
	int lineLen;
	OtherProxys *otherProxys;
	OtherProxy *proxy;
	AnonProxy *anonProxy;
	time_t earliestRegisterTime;

	assert(this!=NULL);
	anonProxy=&this->server->anonProxy;
	otherProxys=&anonProxy->otherProxys;

	earliestRegisterTime=getEarliestProxyRegisterTime(anonProxy);
	proxy=otherProxys->proxys+otherProxys->total-1;
	for(;proxy>=otherProxys->proxys; proxy--) {
		if(proxy->registerTime<earliestRegisterTime)  { break; }
		if(!isProxyOk(anonProxy,proxy)) {
			continue;
		}
		lineLen=snprintf(line,sizeof(line),"Anon Proxy,%s:%i,%i,%08lx\n",
			inet_ntoa_l(proxy->addr),ntohs(proxy->port),proxy->fails,
			proxy->registerTime);
		appendWriteBuf(this,line,lineLen);
	}
}

void
sendConnectionStats(Connection *this) 
{
	Connection *conn;
	struct timeb tv;
	int connUpto=0;

	assert(this!=NULL);

	ftime(&tv);
	for(conn=this->server->firstConnection; conn!=NULL; conn=conn->nextConnection) {
		char line[1024];
		char *status;
		const char *webType;
		int lineLen;
		long msecDiff;

		status="";
		msecDiff=getMSecDiff(&tv,&conn->startTime);
		if(conn->flags&CONNECTION_SOCKET_CONNECTED) {
			status="connected";
		}
		if(conn->dnsLookup!=NULL) {
			status="dns";
		}
		if(conn->flags&CONNECTION_CLOSE) {
			status="close";
		}
		if(conn->flags&CONNECTION_READ_CACHE) {
			status="cache";
		}
		if(conn->flags&CONNECTION_WEB_CONNECTION) {
			if(conn->flags&CONNECTION_SOCKS) {
				webType="socks";
			} else { webType="web"; }
		} else { webType="user"; }
		lineLen=snprintf(line,sizeof(line),"connection,%i,%s,%s:%i,%i,%i,%li,%i,%i,%s,",
			connUpto,
			status,
			inet_ntoa_l(conn->flags&CONNECTION_WEB_CONNECTION?conn->connectedAddr:conn->userAddr),
			ntohs(conn->flags&CONNECTION_WEB_CONNECTION?conn->connectedPort:conn->userPort),
			conn->recvLen+conn->totalRecvLen,
			conn->webContentLength,
			msecDiff,
			conn->totalSentLen+conn->sentLen,
			conn->totalResets,
			webType
			);
		appendWriteBuf(this,line,lineLen);
		if(conn->url!=NULL && (!isProxyKeyOk(conn) || !isAnonLogs(&conn->server->anonProxy))) {
			appendWriteBufVar(this,conn->url);
		}
		appendWriteBufStatic(this,"\n");
		connUpto++;
	}
}

#if 0
static inline ServerStats *
getStatsForConnection(Connection *this)
{
	if(this->flags&(CONNECTION_CMD_CONNECT|CONNECTION_SOCKS)) {
		return &this->server->nonWebStats;
	}
	return &this->server->webStats;
}
#endif

static void
sendUsageStatsArray3(Connection *this,ServerStats *stats,const char *name)
{
	assert(this!=NULL);
	assert(stats!=NULL);
	assert(name!=NULL);

	sendUsageStatsArray(this,&stats->total,1,"Total",name);
	sendUsageStatsArray(this,stats->hours,24,"Hour",name);
	sendUsageStatsArray(this,stats->dayOfWeek,7,"Day of Week",name);
}


static void
sendServerStats(Connection *this)
{
	char line[256];
	int lineLen;
	time_t timeLen;
	ServerStats *stats;

	assert(this!=NULL);

	stats=&this->server->webStats;

	appendWriteBufStatic(this,"HTTP/1.0 200 Ok\r\nContent-Type: text/plain\r\n\r\n");

	timeLen=time(NULL)-stats->startTime;
	lineLen=snprintf(line,sizeof(line),"Uptime,0,%u\n",(unsigned int)timeLen);
	appendWriteBuf(this,line,lineLen);
	lineLen=snprintf(line,sizeof(line),"DnsRunning,0,%u\n",(unsigned int)this->server->totalDnsRunning);

	/* send proxy rego info */
	appendWriteBuf(this,line,lineLen);
	if(isUseAnon(&this->server->anonProxy)) {
		lineLen=snprintf(line,sizeof(line),"Anon Proxy,0,%s,%i\n",(this->server->anonProxy.registeredOk)?"ok":"fail",this->server->anonProxy.timeDiff);
		appendWriteBuf(this,line,lineLen);
	}

	sendUsageStatsArray3(this,stats,"Total");
	sendUsageStatsArray3(this,&this->server->cachedStats,"Cached");
	sendUsageStatsArray3(this,&this->server->nonWebStats,"Non Web");
	sendUsageStatsArray3(this,&this->server->anonStats,"Anon");

	sendConnectionStats(this);
	if(isUseAnon(&this->server->anonProxy)) {
		sendAnonProxyStats(this);
	}
}





int
internalCommand(Connection *this,const char *cmd)
{
	assert(this!=NULL);
	assert(cmd!=NULL);

	this->flags&=-1^CONNECTION_PROXY_KEEP_ALIVE;
	if(strncmp(cmd,"/pinganon/",10)==0) {
		unsigned int key;
		char keyStr[10];
		qstrncpy(keyStr,cmd+10,sizeof(keyStr)-1);
		key=strtoul(keyStr,NULL,16);
		if(isUseAnon(&this->server->anonProxy) && isAnonKey(&this->server->anonProxy,key)) {
			appendWriteBufStatic(this,"HTTP/1.0 200 Ok\n\npinged\n");
		} else {
			appendWriteBufStatic(this,"HTTP/1.0 500 not anon\n\npinged\n");
		}
		return 1;
	}
	else if(strcmp(cmd,"/ping")==0) {
		appendWriteBufStatic(this,"HTTP/1.0 200 Ok\n\npinged\n");
		return 1;
	}
#if 0
	else if(strncmp(cmd,"/anon",5)==0) {
		startTestProxyThread(this);
		return 1;
	}
#endif

	if(this->userAddr!=this->server->localhost) {
		Access *access;
		access=matchConnectionAccess(this,TARGET_ADMIN|TARGET_BLOCK);
		if(access==NULL || access->target==TARGET_BLOCK) {
			errorConnection(this,"no access to Internal command, localhost always has access.");
			return 1;
		}
	}

	debugLog(5,"internal command:%s\n",cmd);
	if(strcmp(cmd,"/registerProxy")==0) {
		if(!this->server->anonProxy.registerProxyRunning) {
			registerProxyStart(&this->server->anonProxy);
			messConnection(this,"200 Proxy registration started","Proxy registration started");
		} else {
			messConnection(this,"500 Already registering proxy","Proxy already registering");
		}
		return 1;
	} else if(strcmp(cmd,"/shutdown")==0) {
		this->server->serverFlags|=SERVER_SHUTDOWN;
		this->server->shutdownConnection=this;
		appendWriteBufStatic(this,"HTTP/1.0 200 Ok\r\nContent-Type: text/html\r\n\r\n<html><body>Shutting down proxy...</body></html>");
		return 1;
	} else if(strcmp(cmd,"/stats")==0) {
		sendServerStats(this);
		return 1;
	}

	errorConnection(this,"unknown command :%s",cmd);
	return 1;
}


