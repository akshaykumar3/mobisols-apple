#ifndef __ACCESS_H
#define __ACCESS_H

enum {
	STYPE_HOST=1,
	STYPE_URL,
	STYPE_DEST_IP,
	STYPE_USER_IP,
	STYPE_URL_PATH,
	STYPE_MAC_ADDRESS,
	STYPE_TIME,
	STYPE_DOW,
	STYPE_USER_AUTH,
	STYPE_LABEL,
	STYPE_URL_REGEX,
	STYPE_DATA_REGEX, 	/***** Unsupported: access is checked before data is sent */
	STYPE_PORT,
	STYPE_MAX		/* maximum number for STYPE_xxx */
};

enum {
	TARGET_BLOCK=1,
	TARGET_ALLOW=2,
	TARGET_NO_PROXY=4,
	TARGET_ADMIN=0x8,
	TARGET_NO_CACHE=0x10,
	TARGET_ANON=0x20,
	TARGET_URL=0x40,
	TARGET_OTHER_PROXY=0x80,
	TARGET_LABEL=0x100,
	TARGET_AND=0x1000
};

enum {
	ISTYPE_IS=1,
	ISTYPE_IS_NOT
};

typedef struct AccessUrl {
	int stype;
	int istype;
	char *str;
	union {
		struct {
			unsigned long min,max;
		}ip;
		struct {
			short start,end;
		}hourMin;
		struct {
			short start,end;
		}port;
		int wday;
		regex_t regex;
	}url;
}AccessUrl;

typedef struct Access {
	AccessUrl *urls;
	int urlsTotal;
	int target;
	struct Server *server;
	char *mess;
}Access;

struct Connection;
struct Server;

Access *matchConnectionAccess(struct Connection *this,int match);
void init_base64();
int isConnectionAccessOk(struct Connection *this);
void clearAccess(Access *this);
AccessUrl *newAccessUrl(Access *this);
Access *newAccess(struct Server *this);

#ifndef NDEBUG

void assertAccess(Access *this);
void assertAccessUrl(AccessUrl *this);

#else

#define assertAccessUrl(x)
#define assertAccess(x)

#endif

#endif
