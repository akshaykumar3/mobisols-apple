#ifndef __CONNMESSAGES_H
#define __CONNMESSAGES_H

void messConnection(struct Connection *this,const char *status, const char *mess,...);
void errorConnection(struct Connection *this,const char *mess,...);
void errorConnectionMess(struct Connection *this,const char *mess,const char *httpMess);
void sendDiagnoseMessage(struct Connection *this, const char *mess);
void logConnection(struct Connection *this);
void sendBaseHref(struct Connection *this);

#endif
