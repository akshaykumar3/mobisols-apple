/* 
  zlib license...

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

*/



#include "pserver.h"
#include "server.h"
#include "connection.h"
#include "access.h"
#include "readconfig.h"
#include "adler32.h"
#include "ssl.h" 

static const char *commandPath;
static char startingDir[FILENAME_MAX];
static Server *server;

/* error log *********************************/

void
errorLog(Server *this,const char *mess,...)
{
	FILE *out;
	va_list args;

	assert(mess!=NULL);

	va_start(args,mess);


	out=(this==NULL || this->errorOut==NULL)?stderr:this->errorOut;
	fprintf(out,"%08x:",(unsigned int)time(NULL));
	vfprintf(out,mess,args);
	va_end(args);
	fflush(out);
#ifndef NDEBUG
	va_start(args,mess);
	vfprintf(stderr,mess,args);
	va_end(args);
#endif
}


/* time/date *********************************/
/*
 * Mostly written for speed.
 */


#if 0
/* returns: -1/1=more than 1 month away, 0=less than 1 month away. */
static int
cmpMonthStr(const char *d1,const char *d2)
{
	int dayDiff,monthDiff;

	assert(d1!=NULL);
	assert(d2!=NULL);
	monthDiff=strncmp(d1+1,d2+1,6);
	dayDiff=strcmp(d1+7,d2+7);
	if(monthDiff==0) { return 0; }
	else if(monthDiff>0) { /* d1>d2 */
		return dayDiff>0?1:0;
	} else { /* d1<d2 */
		return dayDiff<0?-1:0;
	}
}
#endif

static void
getTimeFromStr(const char *s,int *h)
{
	assert(s!=NULL);
	assert(h!=NULL);
	h[0]=atoi(s);
	h[1]=atoi(s+3);
	h[2]=atoi(s+6);
}


static const char *weekdayStrs[7]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
static const char *monthStrs[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

STATIC_INLINE int
monthStrToNum(Server *this,const char *monthStr) 
{
	int ch;

	assert(monthStr!=NULL);

	switch(tolower(monthStr[0])) {
	case 'j': 
		ch=tolower(monthStr[2]);
		if(ch=='n') return 6;
		else if(ch=='a') return 1;
		return 7;
	case 'f': return 2;
	case 'm': if(tolower(monthStr[2])=='r') return 3;
		return 5;
	case 'a': if(tolower(monthStr[1])=='p') return 4;
		return 8;
	case 's':  return 9;
	case 'o': return 10;
	case 'n': return 11;
	case 'd': return 12;
	default:
		errorLog(this,"unknown month: %s\n",monthStr);
	}
	return 0;
}

void
timeToStr(char *dest,time_t tnum)
{
	struct tm t;

	assert(dest!=NULL);

	pserver_gmtime(&t,&tnum);
	snprintf(dest,DATE_STR_LEN,"%01i%04i%02i%02i%02i%02i%02i",
		t.tm_wday,
		t.tm_year+1900,
		t.tm_mon+1,
		t.tm_mday,
		t.tm_hour,
		t.tm_min,
		t.tm_sec
		);
}

int
strToRfc1123(char *dest,int destLen,const char *str)
{
	int weekday,year,month,day,h,m,s;
	char num[5];

	assert(str!=NULL);
	assert(str[0]!=0);
	assert(dest!=NULL);
	assert(destLen>0);

	weekday=str[0]-'0';
	((int *)&num)[0]=((int *)(str+1))[0];
	num[4]=0;
	year=atoi(num);

#define get2Digits(n,x)  \
	((short *)&num)[0]=((short *)(str+x))[0]; \
	num[2]=0; n=atoi(num);


	get2Digits(month,5);
	get2Digits(day,7);
	get2Digits(h,9);
	get2Digits(m,11);
	get2Digits(s,13);
	assert(weekday<7);
	assert(month<=12);
	return snprintf(dest,destLen,"%s, %02i %s %04i %02i:%02i:%02i GMT",
		weekdayStrs[weekday], day,monthStrs[month-1],year,
		h,m,s
		);
}

int
parseDow(Server *this,const char *str)
{
	assert(str!=NULL);
	if(strncasecmp(str,"sun",3)==0) { return 0; }
	else if(strncasecmp(str,"mon",3)==0) { return 1; }
	else if(strncasecmp(str,"tue",3)==0) { return 2; }
	else if(strncasecmp(str,"wed",3)==0) { return 3; }
	else if(strncasecmp(str,"thu",3)==0) { return 4; }
	else if(strncasecmp(str,"fri",3)==0) { return 5; }
	else if(strncasecmp(str,"sat",3)==0) { return 6; }
	else {
		errorLog(this,"Unknown day of week: %s\n",str);
	}
	return -1;
}

/*
 * Sun, 06 Nov 1994 08:49:37 GMT  ; RFC 822, updated by RFC 1123
 * Sunday, 06-Nov-94 08:49:37 GMT ; RFC 850, obsoleted by RFC 1036
 * Sun Nov  6 08:49:37 1994       ; ANSI C's asctime() format
 */
int
getDateStr(Server *this,char *dateStr,const char *from)
{
	const char *f;
	int l;
	int timeArr[3];
	int year=0,day=0,month=0,weekday=0;

	assert(this!=NULL);
	assert(dateStr!=NULL);
	assert(from!=NULL);

	dateStr[0]=0;
	f=from;
	while(isspace(*f)) f++;

	/* check for funny dates... */
	if(strncmp(f,"-1",2)==0 || strncmp(f,"now",3)==0) {
		return 1;
	}
	if(f[0]=='0') {
		const char *fspace;
		fspace=f+1;
		while(isspace(*fspace)) fspace++;
		if(*fspace==0) { return 1;  }
	}

	if((weekday=parseDow(this,f))<0) {
		return 0;
	}
#define getDateStr_skipAlnum  \
	while(isalnum(*f)) f++; \
	while(*f && !isalnum(*f)) f++;

#define getDateStr_skipAlnumColon  \
	while(isalnum(*f) || *f==':') f++; \
	while(*f && (!isalnum(*f) || *f==':')) f++;

	getDateStr_skipAlnum
	if(isdigit(*f)) { day=atoi(f); }
	else { month=monthStrToNum(this,f); }

	getDateStr_skipAlnum
	if(isdigit(*f)) { day=atoi(f); }
	else { month=monthStrToNum(this,f); }

	getDateStr_skipAlnum
	if(f[2]==':') { getTimeFromStr(f,timeArr); }
	else { year=atoi(f); }

	getDateStr_skipAlnumColon
	if(f[2]==':') { getTimeFromStr(f,timeArr); }
	else { year=atoi(f); }

	if(year<100) year+=year>50?1900:2000;

#define getDateStrCheck(d,min,max,str) \
	if(d>max || d<min) {	\
		errorLog(this,"bad " str ": %i\n",d);	\
		return 0;	\
	}

	getDateStrCheck(weekday,0,6,"weekday");
	getDateStrCheck(year,1900,9999,"year");
	getDateStrCheck(month,1,12,"month");
	getDateStrCheck(day,1,31,"day");
	getDateStrCheck(timeArr[0],0,23,"hour");
	getDateStrCheck(timeArr[1],0,60,"minute");
	getDateStrCheck(timeArr[2],0,60,"second");

	l=snprintf(dateStr,DATE_STR_LEN,"%01i%04i%02i%02i%02i%02i%02i",
		weekday,year,month,day,timeArr[0],timeArr[1],timeArr[2]);
	assert(l<DATE_STR_LEN);
	return 1;
}



long
getMSecDiff(struct timeb *t1, struct timeb *t2)
{
	return (long)(
	       	((t1->time-t2->time)*1000)
		+(t1->millitm-t2->millitm)
		);
}




const char *
sockErrorStr()
{
#ifdef _WIN32
	static char buf[64];
	snprintf(buf,sizeof(buf),"winsock err:%i",WSAGetLastError());
	return buf;
#else
	return pserver_strerror(errno);
#endif
}









/* errors *********************************/


#ifndef NDEBUG

static int debugLevel=DEBUGLVL;

void
debugLog(int lvl,const char *mess,...)
{
	va_list args;

	assert(mess!=NULL);
	if(lvl>debugLevel) { return; }

	va_start(args,mess);
	vfprintf(stderr,mess,args);
	va_end(args);
#ifdef _WIN32
	fflush(stderr);
#endif
}
#endif













static int
openErrorLogFile(Server *this)
{
	assert(this!=NULL);
	if((this->errorOut=pserver_fopen("anon_proxy_server.log","wb"))==NULL) {
		fprintf(stderr,"Cannot open error log file: %s\n",pserver_strerror(errno));
		return 0;
	}
	return 1;
}

static Server *
getNewServer()
{
	Server *server;

	server=pserver_malloc(sizeof(server[0]));
	memset(server,0,sizeof(server[0]));
	server->listenAddr=0;
	server->listenPort=8080;
	getcwd(server->baseDir,sizeof(server->baseDir));
	server->maxCacheMegs=500;
	server->dataTimeOutSeconds=300;
	server->timeOutSeconds=60;

	initAnonProxy(&server->anonProxy,server);
#if USE_SSL
	server->anonListenSocket=INVALID_SOCKETFD;
#endif

	server->nextTimeoutCheck=time(NULL)+10;
	server->webStats.startTime=time(NULL);
#if 0
	server->nextCleanCache=time(NULL)+(60*60*24);
#endif
	server->maxLogFileSize=5000000;
	server->maxLogRotate=5;
	server->cleanCache.server=server;
	server->listenSocket=INVALID_SOCKETFD;

	server->localhost=inet_addr("127.0.0.1");
	initStringCache(&server->authenticatedUsers);
	initStringCache(&server->macAddresses);
	initStringCache(&server->ipAddresses);

	chdir("cache");
	openErrorLogFile(server);

	return server;
}



static int
shutdownServer(Server *this)
{
	SOCKETFD fd;
	struct sockaddr_in connectAddr;
	char buf[1024];
	int buflen;
	int r=1;

	assert(this!=NULL);
	memset(&connectAddr,0,sizeof(connectAddr));
	connectAddr.sin_family=AF_INET;
	connectAddr.sin_port=htons(this->listenPort);
	connectAddr.sin_addr.s_addr=inet_addr("127.0.0.1");

	fd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(fd==INVALID_SOCKETFD || connect(fd,(struct sockaddr *)&connectAddr,sizeof(connectAddr))<0) {
		errorLog(this,"problem connecting to shutdown:%s, port:%i\n",sockErrorStr(),this->listenPort);
		closesocket(fd);
		return 0;
	}

#define shutdownStr "GET http://anon_proxy_server/shutdown HTTP/1.0\n\n"
	send(fd,shutdownStr,sizeof(shutdownStr)-1,0);

	/* read the header */
	buflen=recv(fd,buf,sizeof(buf)-1,0);
	if(buflen<=0) {
		errorLog(this,"problem reading from shutdown command:%s\n",sockErrorStr());
		r=0;
	} else {
		char *p;

		buf[buflen]=0;
		p=buf;
		while(!isspace(*p) && *p) p++;
		while(isspace(*p)) p++;
		if(buflen<12 || atoi(p)!=200) {
			char *lf;
			if((lf=strchr(buf,'\n'))!=NULL) { *lf=0; }
			*lf='\n';
			errorLog(this,"bad return from shutdown:%s\n",buf);
			r=0;
		}
	}

	closesocket(fd);
	return r;
}


#ifdef __WIN32
static int exceptionHandled=0;


static LONG WINAPI 
PServerUnhandledExceptionFilter(
  struct _EXCEPTION_POINTERS* ExceptionInfo
)
{
	char cmd[FILENAME_MAX*2];
	int r;

	if(exceptionHandled!=0) {
		/* Crashed while doing something in the exception handler */
		return EXCEPTION_EXECUTE_HANDLER;
	}
	exceptionHandled=1;

	usleep(3000000);
	chdir(startingDir);
	snprintf(cmd,sizeof(cmd),"\"%s\" -run",commandPath);
	errorLog(server,"Crashed, restart.  Execute: %s\n",cmd);
	if(ExceptionInfo->ExceptionRecord!=NULL) {
		errorLog(server,"Exception code:%i, address:%x\n",
			ExceptionInfo->ExceptionRecord->ExceptionCode,
			ExceptionInfo->ExceptionRecord->ExceptionAddress);
	}
	r=system(cmd);
	if(r!=0) {
		errorLog(NULL,"Problem restarting:%i\n",r);
	}
	return EXCEPTION_EXECUTE_HANDLER;
}

#endif


/* main *********************************/

int
main(int argc, char *argv[])
{
	int c;
	struct stat startWanted;
	char *p;
	int forcePort=-1;
	int doShutdown=0;
	int testConfig=0;
	char exeDir[FILENAME_MAX];

	getcwd(startingDir,sizeof(startingDir));
	commandPath=argv[0];
	qstrncpy(exeDir,argv[0],sizeof(exeDir));
	p=strchr(exeDir,0);
	while(p>=exeDir) {
		if(*p=='/' || *p=='\\') {
			*p=0;
			chdir(exeDir);
			break;
		}
		p--;
	}
#ifdef __WIN32
	SetUnhandledExceptionFilter(PServerUnhandledExceptionFilter);
#endif


	for(c=1; c<argc; c++) {
#ifndef NDEBUG
		if(strcmp(argv[c],"-debug")==0) {
			debugLevel=atoi(argv[++c]);
		} else 
#endif
		if(strcmp(argv[c],"-run")==0) {
#ifdef _WIN32
			STARTUPINFO startupInfo;
			PROCESS_INFORMATION processInfo;
			memset(&startupInfo,0,sizeof(startupInfo));
			startupInfo.cb=sizeof(startupInfo);
			startupInfo.wShowWindow=SW_HIDE;
			startupInfo.dwFlags=STARTF_USESHOWWINDOW;
			return CreateProcess(NULL,".\\pserver.exe",NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS|CREATE_NEW_CONSOLE,NULL,NULL,&startupInfo,&processInfo)!=0?0:1;
#else
			if(fork()!=0) { return 0; }
			close(1);
#endif
		} else if(strcmp(argv[c],"-shutdown")==0) {
			doShutdown=1;
		} else if(strcmp(argv[c],"-test")==0) {
			/* just test if we can start up */
			return 0;
		} else if(strcmp(argv[c],"-testConfig")==0) {
			testConfig=1;
		} else if(argv[c][0]=='-') {
			fprintf(stderr,"Unknown option: %s\n",argv[c]);
			return 1;
		} else if(forcePort<0) { forcePort=atoi(argv[c]); }
	}

#ifdef _WIN32
	{
		WSADATA wsaData;
		WSAStartup(MAKEWORD(2,0),&wsaData);
	}
#endif

#ifdef NDEBUG
#endif

	init_base64();
#if USE_SSL
	SSL_load_error_strings();                /* readable error messages */
	SSL_library_init();                      /* initialize library */
	OpenSSL_add_ssl_algorithms();
#endif
	server=getNewServer();

	server->configFile="config.php";
	server->logFile="access.log";
#ifdef _WIN32
	/* AllocConsole is needed for system() to work */
	AllocConsole();
	mkdir("data");
#else
	mkdir("data",0770);
#endif
	if(testConfig) {
		server->errorOut=stdout;
		readConfigFile(server);
		return 0;
	}
	if(!checkConfig(server,time(NULL))) { return 1; }
	if(forcePort>=0) { 
		server->listenPort=forcePort;
	}

	if(doShutdown) {
		return shutdownServer(server)==0?1:0;
	}

	if(stat("./startWanted.txt",&startWanted)!=0) {
		fprintf(stderr,"someone is trying to start when we haven't been told to by the web server, 'touch cache/startWanted.txt' to force a start.\n");
		return 0;
	}


	startServer(server);
#ifdef _WIN32
	WSACleanup();
#endif
	return 0;
}


