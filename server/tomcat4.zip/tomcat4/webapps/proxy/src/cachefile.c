
#include "pserver.h"
#include "connection.h"
#include "server.h"
#include "cachefile.h"
#include "adler32.h"
#include "dns.h"

/* cache *********************************/

static Connection *
isWritingToCacheFile(Server *this,CacheFile *cacheFile)
{
	Connection *conn;
	conn=this->firstConnection;
	while(conn!=NULL) {
		if(strcmp(conn->cacheFile.filename,cacheFile->filename)==0
		&& (conn->flags&CONNECTION_WRITE_CACHE)!=0
		&& conn->cacheFile.fd>0
		) {
			/* Found a cache file we're already writing to. */
			return conn;
		}
		conn=conn->nextConnection;
	}
	return NULL;
}

/* find and open the cache file for this url, return: NULL=no cache file */
static FILE *
findCacheFile(Connection *this,int *noAccess)
{
	unsigned long adler32num;
	FILE *in=NULL;
	char *filenameSuffix;
	const char *url;
	int cacheFileNum=0,cacheFileNumSpare=-1;
	CacheFile *cacheFile=&this->cacheFile;

	assert(this!=NULL);

	*noAccess=0;
	url=this->url;
	if(url==NULL) { url=this->otherConnection->url; }
	debugLog(25,"Find cache file for: %s\n",url);
	adler32num=adler32(0,url,strlen(url));
	filenameSuffix=cacheFile->filename+snprintf(cacheFile->filename,sizeof(cacheFile->filename),
		"data/%02x/%02x/%02x/%02x",
		(int)(adler32num>>24)&0xff,
		(int)(adler32num>>16)&0xff,
		(int)(adler32num>>8)&0xff,
		(int)(adler32num&0xff)
		);
	/* find the file with this url */
	/* we can handle upto 16 collisions on the same adler32 number */
	for(;cacheFileNum<16; cacheFileNum++) {
		char *lf;
		char line[MAX_URL_LEN];

		assert(filenameSuffix<(cacheFile->filename+sizeof(cacheFile->filename)-2));
		snprintf(filenameSuffix,cacheFile->filename+sizeof(cacheFile->filename)-filenameSuffix,"%x",cacheFileNum);
		if(isWritingToCacheFile(this->server,cacheFile)!=NULL) {
			/* we're already writing to this cache file, let's not try to read it */
			debugLog(25,"Already writing to cache file, skip: %s\n",cacheFile->filename);
			*noAccess=1;
			break;
		}
		if((in=pserver_fopen(cacheFile->filename,"rb+"))==NULL) {
			if(cacheFileNumSpare<0) {
				cacheFileNumSpare=cacheFileNum;
			}
			continue;
		}
		fgets(line,sizeof(line),in);
		if((lf=strchr(line,'\n'))!=NULL) { *lf=0; }
		if(strcmp(line,url)!=0) {
			fclose(in);
			continue;
		}

		break;
	}
	if(cacheFileNum>=16) {
		assert(filenameSuffix<(cacheFile->filename+sizeof(cacheFile->filename)-2));
		snprintf(filenameSuffix,cacheFile->filename+sizeof(cacheFile->filename)-filenameSuffix,"%x",cacheFileNumSpare);
		debugLog(20,"cache file not found, spare: %s\n",cacheFile->filename);
		if(cacheFileNumSpare<0) {
			fprintf(stderr,"whoops, too many collisions, cannot get cache filename: %s -> %s\n",this->otherConnection->url,cacheFile->filename);
		}
	} else {
		debugLog(20,"found cache file: %s\n",cacheFile->filename);
	}
	return in;
}

FILE *
loadCacheFileInfo(Connection *this)
{
	FILE *in;
	char line[MAX_URL_LEN];
	char *comma,*lf;
	int noAccess;
	CacheFile *cacheFile=&this->cacheFile;

	assert(this!=NULL);

	if((in=findCacheFile(this,&noAccess))==NULL) { return NULL; }
	fgets(line,sizeof(line),in);

	if((comma=strchr(line,','))!=NULL)  { *comma++=0; }
	else { errorLog(this->server,"bad cache header: %s, head:%s\n",cacheFile->filename,line); return 0; }
	if((lf=strchr(comma,'\n'))!=NULL) { *lf=0; }

	strncpy(cacheFile->lastModified,line,sizeof(cacheFile->lastModified));
	strncpy(cacheFile->expires,comma,sizeof(cacheFile->expires));
	return in;
}

/* opens a cache file and see if we want
 * to use the if-modified from the cache/user
 */
int
checkIfModifiedWithCacheFile(Connection *this,const char *ifModifiedLine)
{
	CacheFile *cacheFile=&this->cacheFile;
	FILE *in;

	assert(this!=NULL);
	assert(!(this->flags&CONNECTION_WEB_CONNECTION));

	cacheFile->lastModified[0]=0;
	cacheFile->expires[0]=0;

	if(this->flags&CONNECTION_CMD_GET) {
		in=loadCacheFileInfo(this);
		if(in!=NULL) {
			/* we already have this url in the cache */
			fclose(in);

			debugLog(10,"cached? %x, ifmodified:%s,incache:%s\n",(unsigned int)this,this->ifModified,cacheFile->lastModified);
			if((this->ifModified[0]==0 || cmpDateStr(this->ifModified,cacheFile->lastModified)>0) 
			&& !(this->flags&CONNECTION_NO_READ_CACHE)) {
				/* we have a cached file 
				 * and the user didn't request no-cache
				 * user either...
				 * didn't send an if-modified 
				 * or the one sent had an older date
				 * so lets send an if-modified request to the web server 
				 */
				char str[256];
				int strLen;

				qstrncpy(str,"If-Modified-Since: ",sizeof(str));
				strLen=strToRfc1123(str+19,sizeof(str)-19,cacheFile->lastModified)+19;
				qstrncpy(str+strLen,"\r\n",sizeof(str)-strLen);
				strLen+=2;
				debugLog(15,"added ifmodified header: %s\n",str);
				appendStringBuf(&this->otherConnection->headerOutBuf,str,strLen);
				this->otherConnection->flags|=CONNECTION_CACHE_MORE_RECENT_THAN_USER;
				return 1;
			}
		} else {
/* disabled: bad idea sometimes things are set private so we never receive it */
#if 0
			/* lets not send if-modified if we don't have it in the cache
			 * so that we get a copy of it in the cache.
			 */
			if(ifModifiedLine!=NULL) {
				debugLog(5,"%x: not sending if-modified so that we can get a copy of it in our cache\n",(unsigned int)this);
			}
			return 1;
#endif
		}
	}

	if(ifModifiedLine!=NULL) {
		appendStringBuf(&this->otherConnection->headerOutBuf,ifModifiedLine,strlen(ifModifiedLine));
		appendStringBufStatic(&this->otherConnection->headerOutBuf,"\n");
	}

	return 1;
}

/* close network and open the cache file for reading */
int
openReadCacheFile(Connection *this)
{
	char line[MAX_URL_LEN];
	int fd;
	char *p;

	assert(this!=NULL);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
	if(!(this->flags&CONNECTION_CMD_GET)) { return 0; }
	assert(this->flags&CONNECTION_CMD_GET);
	assert(!(this->flags&CONNECTION_WRITE_CACHE));

	debugLog(5,"open cache file for reading:web:%x,%i,%s\n",(unsigned int)this,this->flags&CONNECTION_WEB_CONNECTION,this->cacheFile.filename);
	if((fd=pserver_open(this->cacheFile.filename,O_RDONLY|O_BINARY))<0) {
		errorLog(this->server,"cannot open cache file: %s(file:%s),err:%s\n",this->otherConnection->url,this->cacheFile.filename,pserver_strerror(errno));
		return 0;
	}
	read(fd,line,sizeof(line));
	p=strchr(line,'\n');
	if(p==NULL || (p=strchr(p+1,'\n'))==NULL) {
		errorLog(this->server,"bad header: %s(file:%s)\n",this->otherConnection->url,this->cacheFile.filename);
		return 0; 
	}
	
	if(p==NULL) { return 0; }
	lseek(fd,(p-line)+1,SEEK_SET);

	/* we'll read from the cache instead of network now... */
	disconnectDnsLookup(this);
	closePipeFds(this); /* no need for dns, we're reading from cache */
	if(this->conn!=INVALID_SOCKETFD) {
		assert(this->webConn==INVALID_SOCKETFD);
		this->webConn=this->conn;
	}
	clearStringBuf(&this->currentLine);
	clearStringBuf(&this->otherConnection->writeBuf);
	clearStringBuf(&this->writeBuf);
	clearStringBuf(&this->headerOutBuf);
	this->conn=fd;
	debugLog(15,"%x: change fd to file fd: %i\n",(unsigned int)this,fd);
	this->flags|=CONNECTION_SOCKET_CONNECTED;
	this->headerLineUpto=0;
	this->webLastModified[0]=0;
	this->webExpires[0]=0;
	this->webContentLength=-1;
	this->flags|=CONNECTION_READ_CACHE;
	return 1;
}

static int
makeDirectories(Server *this,const char *filename)
{
	char dir[FILENAME_MAX];
	const char *f;
	struct stat st;

	assert(this!=NULL);
	assert(filename!=NULL);

	if(stat(filename,&st)==0) { return 0; }
	f=strrchr(filename,'/');
	strncpy(dir,filename,f-filename);
	dir[f-filename]=0;
	if(stat(dir,&st)==0) { return 0; }

	f=filename;
	while((f=strchr(f,'/'))!=NULL) {
		strncpy(dir,filename,f-filename);
		dir[f-filename]=0;
#ifdef _WIN32
#ifdef _MSC_VER
		if(mkdir(dir)!=0 && GetLastError()!=ERROR_ALREADY_EXISTS) {
#else
		if(mkdir(dir)!=0 && errno!=EEXIST) {
#endif
#else
		if(mkdir(dir,0770)!=0 && errno!=EEXIST) {
#endif
			errorLog(this,"Could not make cache dir: %s, %s\n",dir,pserver_strerror(errno));
		}
		f++;
	}
	return 1;
}

int
openWriteCacheFile(Connection *this)
{
	int fd;
	char line[MAX_URL_LEN+256];
	int lineLen;
	FILE *in;
	const char *url;
	int noAccess;

	assert(this!=NULL);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
	assert(!(this->flags&CONNECTION_READ_CACHE));

	if(!(this->flags&CONNECTION_CMD_GET)) { return 0; }

	if(this->flags&CONNECTION_NO_WRITE_CACHE || this->webLastModified[0]==0) {
		return 0;
	}
	if((in=findCacheFile(this,&noAccess))!=NULL) {
		fclose(in);
	}
	if(noAccess) { return 0; }

	url=this->otherConnection->url;
	debugLog(5,"open cache file for writing:%x:%s\n",(unsigned int)this,this->cacheFile.filename);
	makeDirectories(this->server,this->cacheFile.filename);
	if((fd=pserver_open(this->cacheFile.filename,O_WRONLY|O_CREAT|O_TRUNC|O_BINARY,0660))<0) {
		errorLog(this->server,"cannot open cache file: %s(file:%s),err:%s\n",url,this->cacheFile.filename,pserver_strerror(errno));
		return 0;
	}
	lineLen=snprintf(line,sizeof(line),"%s\n%s,%s\n",
		url,
		this->webLastModified,
		this->webExpires
		);
	write(fd,line,lineLen);

	this->cacheFile.fd=fd;
	this->flags|=CONNECTION_WRITE_CACHE;

	return 1;
}

/* write a section of the buffer to cache */
void
writeStringBufSectionToCacheFile(Connection *this,StringBuf *recvBuf,int upto,int len)
{
	assert(this!=NULL);
	assert(recvBuf!=NULL);

	if(this->flags&CONNECTION_WRITE_CACHE) {
		assert(this->cacheFile.fd>0);
		write(this->cacheFile.fd,recvBuf->buf+upto,len);
	}
}

/* write all the buf to cache file */
void
writeStringBufToCacheFile(Connection *this,StringBuf *recvBuf)
{
	assert(this!=NULL);
	assert(recvBuf!=NULL);

	writeStringBufSectionToCacheFile(this,recvBuf,recvBuf->readUpto,recvBuf->upto-recvBuf->readUpto);
}




