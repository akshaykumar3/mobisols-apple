#ifndef __GET_URL_H
#define __GET_URL_H

#if USE_SSL
#include  <openssl/ssl.h>
#endif
#include "stringbuf.h"
#include "url.h"

struct Server;

typedef struct GetUrl {
	SOCKETFD fd;
	Url url;
	StringBuf in,out;
	struct Server *server;
#if USE_SSL
	SSL *ssl;
	BIO *sslBIO;
#endif
}GetUrl;


int getUrlNew(GetUrl *this,struct Server *,char *urlStr);
void getUrlClose(GetUrl *this);
void getUrlClear(GetUrl *this);
int getUrlAll(GetUrl *this);

int getUrlRead(GetUrl *this);
int getUrlWrite(GetUrl *this);

#endif
