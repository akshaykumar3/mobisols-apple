#ifndef __CACHEFILE_H
#define __CACHEFILE_H

/* the cache file to write/read from */
typedef struct CacheFile {
	char filename[24];
	char lastModified[DATE_STR_LEN];
	char expires[DATE_STR_LEN];
	int fd;
}CacheFile;

struct Connection;

int openReadCacheFile(struct Connection *this);
int openWriteCacheFile(struct Connection *this);
FILE *loadCacheFileInfo(struct Connection *this);
int checkIfModifiedWithCacheFile(struct Connection *this,const char *ifModifiedLine);
void writeStringBufSectionToCacheFile(struct Connection *this,struct StringBuf *recvBuf,int upto,int len);
void writeStringBufToCacheFile(struct Connection *this,struct StringBuf *recvBuf);

#endif
