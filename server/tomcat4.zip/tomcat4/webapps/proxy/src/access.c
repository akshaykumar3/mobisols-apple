
#include "pserver.h"
#include "server.h"
#include "stringcache.h"
#include "connection.h"
#include "connmessages.h"
#include "access.h"


typedef struct MatchAccess {
	AccessUrl *urlUpto;
	Connection *conn;
	Access *access;
	StringCache labels;
	Access *accessMatched;
	int needProxyAuth;
}MatchAccess;

#define AUTHCMD_LOG "authCmd.log"


/* user auth *****************************************/


#define SECONDS_INBETWEEN_USER_AUTH_CHECKS 300
#define MAX_USER_NAME_LEN 512


const char base64_chars[64]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
unsigned char base64_rev_chars[256];

void
init_base64()
{
	int c;

	memset(base64_rev_chars,-1,sizeof(base64_rev_chars));
	base64_rev_chars['=']=0;
	for(c=0; c<sizeof(base64_chars); c++) {
		base64_rev_chars[(unsigned char)base64_chars[c]]=c;
	}
}

#ifndef NDEBUG

void
assertAccessUrl(AccessUrl *this) 
{
	assert(this!=NULL);
	assert(this->stype>0);
	assert(this->stype<STYPE_MAX);
	assert(this->istype>0);
	assert(this->istype<=2);
	if(this->stype==STYPE_DOW) {
		assert(this->url.wday>=0 && this->url.wday<7);
	}
}

void
assertAccess(Access *this) 
{
	int i;

	assert(this!=NULL);
	assert(this->server!=NULL);
	assert(this->mess!=NULL);
	assert(this->urlsTotal>=0);

	if(this->urlsTotal>0) {
		assert(this->urls!=NULL);
	}
	for(i=0; i<this->urlsTotal; i++) {
		assertAccessUrl(this->urls+i);
	}
}

#endif



void
clearAccess(Access *this)
{
	int u;

	assert(this!=NULL);
	assertAccess(this);

	for(u=0; u<this->urlsTotal; u++) {
		FREE_PTR(this->urls[u].str);
	}
	FREE_PTR(this->urls);
}


static int
decodeBase64(Server *this,char *dest,int destLen, const char *from)
{
	char *ptr_dest,*destEnd;
	const char *ptr;
	char buf[4];

	assert(this!=NULL);
	assert(dest!=NULL);
	assert(from!=NULL);
	assert(destLen>=4);
	ptr_dest=dest;
	destEnd=dest+(destLen&-4);
	for(ptr=from; ptr_dest<destEnd; ptr+=4,ptr_dest+=3) {
		if(ptr[0]==0) { break; }

		buf[0]=base64_rev_chars[(unsigned char)ptr[0]];
		buf[1]=base64_rev_chars[(unsigned char)ptr[1]];
		buf[2]=base64_rev_chars[(unsigned char)ptr[2]];
		buf[3]=base64_rev_chars[(unsigned char)ptr[3]];

		if(buf[0]<0 || buf[1]<0 || buf[2]<0 || buf[3]<0) {
			errorLog(this,"illegal character in stream, %c,%c,%c,%c\n",ptr[0],ptr[1],ptr[2],ptr[3]);
			return -1;
		}

		if(ptr[0] != '=') {
			ptr_dest[0]=(buf[0]<<2)|(buf[1]>>4);
			if(ptr[2] != '=') {
				ptr_dest[1]=(buf[1]<<4)|(buf[2]>>2);
				if(ptr[3] != '=') {
					ptr_dest[2]=(buf[2]<<6)|(buf[3]);
				}
				else { ptr_dest[3]=0; }
			}
			else { ptr_dest[1]=0; }
		}
		else { ptr_dest[0]=0; }
	}
	ptr_dest[0]=0;
	return ptr_dest-dest;
}



/* quote ", ' and remove control characters */
static void
strquotecpy(char *dest,int destLen,const char *from)
{
	int ch;
	char *destEnd=dest+destLen-2;

	assert(dest!=NULL);
	assert(from!=NULL);

	while((ch=*from++)!=0 && dest<destEnd) {
		if(ch=='\'') { *dest++='\\'; }
		else if(ch=='\"') { *dest++='\\'; }
		if(ch<0x20) { continue; }
		*dest++=ch;
	}
	*dest=0;
}



static int
base64ToUserPass(Server *this,char *user,char *pass,const char *base64Str)
{
	char decoded[MAX_USER_NAME_LEN];
	char *p;

	assert(this!=NULL);
	assert(user!=NULL);
	assert(pass!=NULL);
	assert(base64Str!=NULL);

	decodeBase64(this,decoded,sizeof(decoded)-1,base64Str);
	debugLog(20,"decoded: %s\n",decoded);
	p=strchr(decoded,':');
	if(p==NULL) {
		return 0;
	}
	*p++=0;
	qstrncpy(user,decoded,MAX_USER_NAME_LEN);
	qstrncpy(pass,p,MAX_USER_NAME_LEN);
	return 1;
}

static void
sendProxyAuthRequest(Connection *this,const char *mess)
{
	char messBuf[8196];

	assert(this!=NULL);
	assert(mess!=NULL);

	debugLog(20,"%x: ask for proxy password\n",(unsigned int)this);
	snprintf(messBuf,sizeof(messBuf),"Wrong username or password or domain group<p />%s",mess);
	errorConnectionMess(this,messBuf,"407 Proxy login required\r\nProxy-Authenticate: Basic realm=\"Please login to the proxy\"");
}


#if 0
static int
systemWin32(char *cmd)
{
	STARTUPINFO startupInfo;
	PROCESS_INFORMATION processInfo;
	DWORD r;

	memset(&startupInfo,0,sizeof(startupInfo));
	memset(&processInfo,0,sizeof(processInfo));
	startupInfo.cb=sizeof(startupInfo);
	startupInfo.wShowWindow=SW_HIDE;
	startupInfo.dwFlags=STARTF_USESHOWWINDOW;
	if(!CreateProcess(NULL,cmd,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS|CREATE_NEW_CONSOLE,NULL,NULL,&startupInfo,&processInfo)) {
		return 1;
	}
	WaitForSingleObject(processInfo.hProcess,INFINITE);
	GetExitCodeProcess(processInfo.hProcess,&r);
	CloseHandle(processInfo.hProcess);
	CloseHandle(processInfo.hThread);
	return (int)r;
}
#endif

#ifdef _WIN32
static int
authenticateWindows(Server *this,char *user, char *pass, const char *domain)
{
	HANDLE logonH;
	int ok=0;

	assert(this!=NULL);
	assert(user!=NULL);
	assert(pass!=NULL);
	assert(domain!=NULL);

	domain=domain[0]==0?NULL:domain;
	if(LogonUser(user,(char *)domain,pass,3,LOGON32_PROVIDER_DEFAULT,&logonH)) {
		debugLog(20,"Windows user ok: %s\\%s\n",domain,user);
		ok=1;
	}
	CloseHandle(logonH);
	return ok;
}
#endif

void 
printUserAuthCmd(char *cmd,int cmdLen,const char *format,
	const char *user,const char *pass)
{
	char userQuoted[MAX_USER_NAME_LEN];
	char passQuoted[MAX_USER_NAME_LEN];

	strquotecpy(userQuoted,MAX_USER_NAME_LEN,user);
	strquotecpy(passQuoted,MAX_USER_NAME_LEN,pass);
	snprintf(cmd,cmdLen,format,userQuoted,passQuoted);
}


void
checkAuthCmdLog(Connection *this)
{
	FILE *log;
	struct stat authCmdLogStat;
	char buf[4096];
	if(stat(AUTHCMD_LOG,&authCmdLogStat)==0 && authCmdLogStat.st_size>0) {
		if((log=pserver_fopen(AUTHCMD_LOG,"rb"))!=NULL) {
			while(fgets(buf,sizeof(buf)-1,log)!=NULL) {
				char *lf;
				if((lf=strchr(buf,'\n'))!=NULL) {
					*lf=0;
					if(lf>=buf && lf[-1]=='\r') lf[-1]=0;
				}
				if(buf[0]==0) { continue; }
				errorLog(this->server,"Auth command error: %s\n",buf);
			}
			fclose(log);
		}
	}
}

static void
setNeedProxyAuth(MatchAccess *matchAccess)
{
	assert(matchAccess->urlUpto->istype==ISTYPE_IS_NOT);
	assert(matchAccess->urlUpto->stype==STYPE_USER_AUTH);

	if(matchAccess->access->target!=TARGET_AND) {
		/* This is not an "and" so we're the last one that we need to check */
		matchAccess->needProxyAuth=1;
	}
}

/* authenticate user, send error mess if failed */
static int
authenticateUser(Connection *this,MatchAccess *matchAccess,
	AccessUrl *accessUrl)
{
	char user[MAX_USER_NAME_LEN];
	char pass[MAX_USER_NAME_LEN];
	char userPassCmd[(MAX_USER_NAME_LEN*2)+FILENAME_MAX];
	char cmd[1024];
	FILE *authCmd;
	StringCacheItem *item;
	const char *base64Str;
	const char *authCmdStr;
	static const char *authCmdFile="authCmd.bat";

	assert(this!=NULL);
	assert(accessUrl!=NULL);
	assertAccessUrl(accessUrl);
	assertConnection(this);

	authCmdStr=accessUrl->str;
	assert(authCmdStr!=NULL);
	if(authCmdStr==NULL || authCmdStr[0]==0) {
		errorLog(this->server,"err: no command for user auth\n");
	
		return 0;
	}
	if((base64Str=this->authBase64Str)==NULL) {
		setNeedProxyAuth(matchAccess);
		return 0; 
	}
	while(isspace(*base64Str)) base64Str++;
	if(!base64ToUserPass(this->server,user,pass,base64Str)) {
		setNeedProxyAuth(matchAccess);
		return 0;
	}
	/* record user in web connection so we can log it later
	 * if we're called by an internal command we won't have otherConnection
	 */
	if(this->otherConnection!=NULL) {
		/* There will already be a user set here if there was another user_auth check earlier on */
		assert(this->otherConnection->authUser==NULL || strcasecmp(this->otherConnection->authUser,user)==0);
		if(this->otherConnection->authUser==NULL) {
			this->otherConnection->authUser=strdup(user);
		}
	}

	snprintf(userPassCmd,sizeof(userPassCmd),"%s%s",base64Str,authCmdStr);
	item=findStringCacheItem(&this->server->authenticatedUsers,userPassCmd);

	if(item!=NULL && item->lastCheck>(time(NULL)-SECONDS_INBETWEEN_USER_AUTH_CHECKS)) {
		debugLog(20,"Skipping user check, this user has passed ok within the last %i seconds: %s \n",SECONDS_INBETWEEN_USER_AUTH_CHECKS,user);
		return 1;
	}

	/* do command line auth */
	printUserAuthCmd(cmd,sizeof(cmd),authCmdStr,user,pass);

	debugLog(20,"Run auth command: %s\n",cmd);
	/* make a temp file so that the password isn't visible with "ps" */
	if((authCmd=pserver_fopen(authCmdFile,"wb"))!=NULL) {
#ifdef _WIN32
		fputs("@echo off\n",authCmd);
#endif
		fputs(cmd,authCmd);
		fputs(" >" AUTHCMD_LOG " 2>&1",authCmd);
		fputc('\n',authCmd);
		fclose(authCmd);
	}


#ifdef _WIN32
	if(
	strncasecmp(authCmdStr,"windows:",8)==0?
		authenticateWindows(this->server,user,pass,authCmdStr+8)==0
		:(system(".\\authCmd.bat")!=0)
	) {
#else
	chmod(authCmdFile,0700);
	if(system("sh authCmd.bat")!=0) {
#endif
		unlink(authCmdFile);
		if(item!=NULL) { removeStringCacheItem(&this->server->authenticatedUsers,item); }
		setNeedProxyAuth(matchAccess);
		return 0;
	}

	checkAuthCmdLog(this);
	unlink(AUTHCMD_LOG);

	unlink(authCmdFile);
	if(item==NULL) {
		item=newStringCacheItem(&this->server->authenticatedUsers,userPassCmd,user); 
	}
	item->lastCheck=time(NULL);
	return 1;
}

/* access *****************************************/


static void
sendRedirect(Connection *this,const char *url)
{
	assert(this!=NULL);
	assert(url!=NULL);

	appendWriteBufStatic(this,"HTTP/1.0 301\r\nLocation: ");
	appendWriteBufVar(this,url);
	appendWriteBufStatic(this,"\r\n\r\n");
}


static int
fillMacAddresses(Server *this)
{
#ifndef _WIN32
	FILE *in;
	char line[1024];
	char *p,*macAddress;
	time_t nextUpdate=time(NULL)+300;

	assert(this!=NULL);

	if(this->macAddressUpdate<nextUpdate) {
		return 1;
	}
	this->macAddressUpdate=nextUpdate;
	clearStringCache(&this->macAddresses);
	if((in=pserver_fopen("/proc/net/arp","rb"))==NULL) {
		errorLog(this,"cannot open arp cache: %s\n",pserver_strerror(errno));
		return 0;
	}
	fgets(line,sizeof(line),in);
	while(fgets(line,sizeof(line),in)!=NULL) {
		StringCacheItem *item;
		p=line;
		while(*p && !isspace(*p)) p++;
		*p++=0;
		while(isspace(*p)) p++;
		while(*p && !isspace(*p)) p++;
		while(isspace(*p)) p++;
		while(*p && !isspace(*p)) p++;
		while(isspace(*p)) p++;
		macAddress=p;
		while(*p && !isspace(*p)) p++;
		*p=0;

		item=newStringCacheItem(&this->macAddresses,line,macAddress);
	}
	fclose(in);
#endif
	return 1;
}



static void
calcStartTm(Connection *this) 
{
	assert(this!=NULL);
	assertConnection(this);
	if(!(this->flags&CONNECTION_HAS_STARTTM)) {
		this->flags|=CONNECTION_HAS_STARTTM;
		pserver_localtime(&this->startTm,&this->lastActivity);
	}
}


static int
isAccessUrlOk(MatchAccess *this)
{
	AccessUrl *urlUpto;
	Connection *conn;
	int r=0;

	assert(this!=NULL);
	assert(this->conn!=NULL);

	conn=this->conn;
	urlUpto=this->urlUpto;
	switch(urlUpto->stype) {
	case STYPE_HOST:
	{
		char *p,*h;

		assert(urlUpto->str!=NULL);
		assert(conn->parsedUrl.host!=NULL);
		p=strchr(urlUpto->str,0);
		h=strchr(conn->parsedUrl.host,0);
		debugLog(20,"accesshost: %s ?= %s\n",urlUpto->str,conn->parsedUrl.host);
		if((p-urlUpto->str)>(h-conn->parsedUrl.host)) {
			r=0;
			break;
		}
		while(*p==*h && p>=urlUpto->str) {
			p--; h--;
		}
		if(p<urlUpto->str) {
			/* matched all of the url */
			r=1;
		}
		break;
	}
	case STYPE_URL_PATH:
		debugLog(20,"accesspath: %s ?= %s\n",urlUpto->str,conn->parsedUrl.path);
		if(strstr(conn->parsedUrl.path,urlUpto->str)!=NULL) { r=1; }
		break;
	case STYPE_URL:
		debugLog(20,"accessurl: %s ?= %s\n",urlUpto->str,conn->url);
		if(strstr(conn->url,urlUpto->str)!=NULL) { r=1; }
		break;
	case STYPE_URL_REGEX:
		debugLog(20,"accessregex: %s,%x ?= %s\n",urlUpto->str,urlUpto,conn->url);
		if(regexec(&urlUpto->url.regex,conn->url,0,NULL,0)==0) {
			r=1;
		}
		break;
	case STYPE_USER_IP:
	{
		unsigned long ip;
		ip=ntohl(conn->userAddr);
		debugLog(20,"accessuserip: %x < %x < %x\n",
			urlUpto->url.ip.min,ip,urlUpto->url.ip.max);
		if(ip>=urlUpto->url.ip.min && ip<urlUpto->url.ip.max) { r=1; }
	}
		break;
	case STYPE_MAC_ADDRESS:
	{
		StringCacheItem *item;
		struct in_addr inAddr;
		fillMacAddresses(conn->server);
		inAddr.s_addr=conn->userAddr;
		debugLog(20,"accessmac: %s ?= %s\n",conn->userAddr,urlUpto->str);
		if((item=findStringCacheItem(&conn->server->macAddresses,inet_ntoa(inAddr)))!=NULL && strcmp(item->val,urlUpto->str)==0) {
			r=1;
		}
	}
		break;
	case STYPE_TIME:
	{
		int m;
		calcStartTm(conn);
		m=(conn->startTm.tm_hour*60)+(conn->startTm.tm_min);
		debugLog(20,"accesstime: %i < current:%i < %i\n",urlUpto->url.hourMin.start,m,urlUpto->url.hourMin.end);
		if(urlUpto->url.hourMin.start>urlUpto->url.hourMin.end) {
			/* an overnight time */
			if(m>=urlUpto->url.hourMin.start || m<urlUpto->url.hourMin.end) {
				r=1;
			}
		} else {
			if(m>=urlUpto->url.hourMin.start && m<urlUpto->url.hourMin.end) {
				r=1;
			}
		}
	}
		break;
	case STYPE_DOW:
		calcStartTm(conn);
		debugLog(20,"accessdow: %i ?= %i\n",conn->startTm.tm_wday,urlUpto->url.wday);
		if(conn->startTm.tm_wday==urlUpto->url.wday) {
			r=1;
		}
		break;
	case STYPE_USER_AUTH:
		debugLog(20,"accessuser: %s ?= %s\n",conn->authBase64Str,urlUpto->str);
		if(conn->flags&CONNECTION_SOCKS) {
			/****** socks user/pass unsupported */
			r=1;
		} else if(authenticateUser(conn,this,urlUpto)) {
			r=1;
		}
		break;
	case STYPE_LABEL:
		if(findStringCacheItem(&this->labels,urlUpto->str)!=NULL) {
			debugLog(20,"accessuser: label found: %s\n",urlUpto->str);
			r=1;
		} else {
			debugLog(20,"accessuser: label not found: %s\n",urlUpto->str);
		}
		break;
	case STYPE_PORT:
	{
		int port;
		port=getUrlConnectPort(&conn->parsedUrl);
		if(port>=urlUpto->url.port.start
		&& port <=urlUpto->url.port.end) {
			r=1;
		}
	}
		break;
	default:
		errorLog(conn->server,"unknown stype: %i\n",urlUpto->stype);
		r=0;
		break;
	}

	if(urlUpto->istype==ISTYPE_IS_NOT) { r=r?0:1; }
	debugLog(20,"accessmatched? %i\n",r);
	return r;
}



void
matchConnectionMatchAccess(Connection *this,MatchAccess *matchAccess,int match)
{
	int totalAccesses;
	Access *access,*accessEnd;
	Access *accessMatched=NULL;

	assert(this!=NULL);
	memset(matchAccess,0,sizeof(matchAccess[0]));
	initStringCache(&matchAccess->labels);
	matchAccess->conn=this;

	access=this->server->accesses;
	totalAccesses=this->server->totalAccesses;
	accessEnd=access+totalAccesses;
	for(; access<accessEnd; access++) {
		AccessUrl *accessUrl,*accessUrlEnd;
		int found=0;

		matchAccess->access=access;

		if(access->target==TARGET_AND) {
#if 0
			/* see if the final target is matched */

			for(; access<accessEnd; access++) {
				if(access->target!=TARGET_AND) { break; }
			}
			if(access>=accessEnd) {
				debugLog(5,"Whoops, and cannot be the last action: %s\n",access->mess);
				break;
			}

			if(access->target!=TARGET_LABEL && !(access->target&match)) {
				/* we didn't request this target. */
				access--;
				debugLog(25,"skip target, did not request it: %i, %s\n",access->target,access->mess);
				continue; 
			}
#endif
		} else if(access->target!=TARGET_LABEL && !(access->target&match)) {
			debugLog(25,"skip target, did not request it: %i, %s\n",access->target,access->mess);
			continue;
		}

		accessUrlEnd=access->urls+access->urlsTotal;
		debugLog(25,"accesses this section: %i, %s\n",access->urlsTotal,access->mess);
		for(accessUrl=access->urls; accessUrl<accessUrlEnd; accessUrl++) {
			matchAccess->urlUpto=accessUrl;
/*~~~ if it's a label go back and check the label. */
			if(isAccessUrlOk(matchAccess)) {
				found=1;
				break; 
			}
		}
		if(access->target==TARGET_AND) {
			if(!found) {
				/* not found, let's skip till end of and... */
				for(; access<accessEnd; access++) {
					if(access->target!=TARGET_AND) {
						break;
					}
				}
				if(access<(accessEnd-1)) {
					debugLog(20,"accessand: not matched skip to: %s\n",access[1].mess);
				}
			}
			continue;
		}
		if(found && access->target==TARGET_LABEL) {
			debugLog(20,"accessuser: label marked: %s\n",access->mess);
			newStringCacheItem(&matchAccess->labels,access->mess,"");
			continue;
		}
		if(!found) { continue; }

		accessMatched=access;
		break;
	}

	clearStringCache(&matchAccess->labels);
	if(accessMatched!=NULL) {
		debugLog(20,"access matched: %s\n",accessMatched->mess);
	}
	matchAccess->accessMatched=accessMatched;
}

Access *
matchConnectionAccess(Connection *this,int match)
{
	MatchAccess matchAccess;

	matchConnectionMatchAccess(this,&matchAccess,match);

	return matchAccess.access;
}


/* check if connection access is allowed 
 * returns: 0=block/url, 1=allow, 2=no matches
 */
int
isConnectionAccessOk(Connection *this)
{
	Access *access;
	MatchAccess matchAccess;

	assert(this!=NULL);
	assert(!(this->flags&CONNECTION_WEB_CONNECTION));

	if((access=matchConnectionAccess(this,TARGET_NO_CACHE))!=NULL) {
		this->flags|=CONNECTION_NO_WRITE_CACHE;
	}
	if(isUseAnon(&this->server->anonProxy) && isProxyKeyOk(this)) {
		/* if in anonymous proxy mode,
		 * allow anybody with the right key to do a request
		 */
		return 1;
	}
	matchConnectionMatchAccess(this,&matchAccess,TARGET_BLOCK|TARGET_ALLOW|TARGET_URL);
	access=matchAccess.accessMatched;
	if(access==NULL) { return 2; }

	if(access->target==TARGET_URL) {
		sendRedirect(this,access->mess);
		return 0;
	} else if(access->target==TARGET_BLOCK) {
		debugLog(10,"Access blocked: %s\n",access->mess);
		if(matchAccess.needProxyAuth!=0) {
			sendProxyAuthRequest(this,access->mess);
		} else {
			errorConnectionMess(this,access->mess[0]==0?"Access blocked":access->mess,"403 Access blocked");
		}
		return 0;
	}
	if(access->target==TARGET_ALLOW) {
		return 1;
	}
	assert(access->target!=-1);
	return 2;
}

Access *
newAccess(Server *this)
{
	Access *access;

	assert(this!=NULL);

	this->totalAccesses++;
	this->accesses=(Access *)realloc(this->accesses,sizeof(this->accesses[0])*this->totalAccesses);
	access=this->accesses+this->totalAccesses-1;
	access->urls=NULL;
	access->urlsTotal=0;
	access->target=-1;
	access->mess=NULL;
	access->server=this;
	return access;
}

AccessUrl *
newAccessUrl(Access *this)
{
	AccessUrl *accessUrl;

	assert(this!=NULL);
	this->urlsTotal++;
	this->urls=(AccessUrl *)realloc(this->urls,sizeof(this->urls[0])*this->urlsTotal);
	accessUrl=this->urls+this->urlsTotal-1;
	accessUrl->stype=-1;
	accessUrl->istype=-1;
	accessUrl->str=NULL;
	return accessUrl;
}



