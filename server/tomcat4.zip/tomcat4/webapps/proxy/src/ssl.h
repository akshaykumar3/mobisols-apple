#ifndef __SSL_H
#define __SSL_H

#if USE_SSL
#include <openssl/ssl.h>

typedef struct SSLCert {
	X509 *x509;
	EVP_PKEY *pkey;
}SSLCert;

void printSSLCert(SSLCert *this,FILE *out);
void freeSSLCert(SSLCert *this);
SSLCert *newSSLCert(struct Server *);
SSL_CTX *newSSLCtx(struct Server *);

void thread_cleanup(void);
void thread_setup(void);

#endif

#endif
