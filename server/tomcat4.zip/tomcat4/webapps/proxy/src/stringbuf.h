#ifndef __STRINGBUF_H
#define __STRINGBUF_H


typedef struct StringBuf {
	char *buf;
	int upto,len,readUpto;
}StringBuf;

STATIC_INLINE int
isStringBufEmpty(const StringBuf *this)
{
	assert(this!=NULL);
	if(this->upto==this->readUpto) {  return 1; }
	return 0;
}

STATIC_INLINE int
countStringBuf(const StringBuf *this)
{
	assert(this!=NULL);
	return this->upto-this->readUpto;
	return 0;
}

STATIC_INLINE int
getStringBufLen(const StringBuf *this)
{
	return this->upto-this->readUpto;
}

/* empty string buf but don't free stuff */
STATIC_INLINE void
emptyStringBuf(StringBuf *this)
{
	assert(this!=NULL);
	this->readUpto=this->upto=0;
}

#define appendStringBufStatic(t,d) appendStringBuf((t),(d),sizeof((d))-1)

int getLineFromStringBuf(StringBuf *this,StringBuf *destLine);
void appendStringBuf(StringBuf *this,const char *data,int len);
void appendStringBufFromStringBuf(StringBuf *this,StringBuf *from);
void clearStringBuf(StringBuf *this);
void allocStringBuf(StringBuf *this,int len);

#endif
