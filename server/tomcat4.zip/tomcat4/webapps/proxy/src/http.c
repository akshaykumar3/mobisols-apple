
#include "pserver.h"
#include "connection.h"
#include "connmessages.h"
#include "server.h"

int
processUserHeaderLine(Connection *this,char *httpLine)
{
	debugLog(10,"user header: %s\n",httpLine);
	assert(this!=NULL);
	assert(!isHeaderDone(this));
	assert(httpLine!=NULL);
	if(this->headerLineUpto==0) {
		char *httpLineSpace;
		char *httpLineSpace2;
		Connection *otherConnection;
		char fixedUrl[MAX_URL_LEN];
		char *urlStr;

#if USE_WEB_KEEP_ALIVE == 0
		assert(this->otherConnection==NULL);
#else
		assert(this->otherConnection==NULL || (this->otherConnection->recvLen>=this->otherConnection->webContentLength));
#endif



		httpLineSpace=strchr(httpLine,' ');
		httpLineSpace2=strrchr(httpLine,' ');
		if(httpLineSpace==NULL || httpLineSpace2==httpLineSpace) {
			errorLog(this->server,"Bad request: %s",httpLine);
			return 0;
		}
		*httpLineSpace++=0;
		*httpLineSpace2++=0;

		assert(this->cmd==NULL);
		this->cmd=strdup(httpLine);

		if(strcmp(this->cmd,"GET")==0) { this->flags|=CONNECTION_CMD_GET; }
		else { this->flags|=CONNECTION_NO_READ_CACHE|CONNECTION_NO_WRITE_CACHE; }

		urlStr=httpLineSpace;
		if(strcmp(this->cmd,"CONNECT")==0) { 
			snprintf(fixedUrl,sizeof(fixedUrl),"connect://%s",urlStr);
			urlStr=fixedUrl;
			this->flags|=CONNECTION_CMD_CONNECT; 
		}

		assert(this->url==NULL);
		assert(this->httpVers==NULL);
		this->url=strdup(urlStr);
		this->httpVers=strdup(httpLineSpace2);
		if(!parse_url(&this->parsedUrl,httpLineSpace)) {
			errorConnection(this,"Bad url: %s",this->url);
			return 1;
		}
		assert(this->parsedUrl.host!=NULL);
		this->parsedUrl.port=getUrlConnectPort(&this->parsedUrl);

#if USE_WEB_KEEP_ALIVE == 0
		assert(this->otherConnection==NULL);
		{
#else 
		if(this->otherConnection==NULL)  {
#endif
			otherConnection=getNewConnection(this->server,this);
		} else {
			otherConnection=this->otherConnection;
			ftime(&otherConnection->startTime);

			assert(this->otherConnection==otherConnection);
			assert(otherConnection->otherConnection==this);
			assert(otherConnection->flags&CONNECTION_WEB_CONNECTION);
		}
		assert(otherConnection->url==NULL);
		assert(otherConnection->cmd==NULL);

		otherConnection->url=strdup(this->url);
		otherConnection->cmd=strdup(this->cmd);
		otherConnection->lastActivity=time(NULL);
		otherConnection->parsedUrl.host=strdup(this->parsedUrl.host);
		otherConnection->parsedUrl.port=this->parsedUrl.port;
		otherConnection->hostPort=htons(this->parsedUrl.port);
		otherConnection->flags|=this->flags&(CONNECTION_CMD_GET|CONNECTION_CMD_CONNECT);

/*~~~ pipe different schemes to outside programs?(windows via thread/sockets) */

	} else if(strncasecmp(httpLine,"anon-proxy-authorization:",25)==0) {
		char hex[12];
		char *p;
		unsigned int keyNum;
		AnonProxy *anonProxy;

		p=httpLine+25;
		anonProxy=&this->server->anonProxy;
		while(isspace(*p)) p++;
		strncpy(hex,p,8);
		hex[8]=0;
		keyNum=strtoul(hex,NULL,16);
		this->anonFlags|=CONNECTION_FROM_PROXY;
		if(!isAnonKey(anonProxy,keyNum)) {
			errorLog(this->server,"Bad key number:%s, line:%s, key:%08x!=%08x/%08x",inet_ntoa_l(this->userAddr),hex,keyNum,anonProxy->anonKeys[0],anonProxy->anonKeys[1]);

/***** client proxy should really reconnect instead of printing a bad key message 
 * but the header has already been sent and we don't have it anymores.
 */
			errorConnection(this,"Bad key number<br /><a href=\"registerProxy.php\">Re-register proxy</a>");
			this->otherConnection->flags|=CONNECTION_CLOSE;
			return 1;
		}
		this->anonFlags|=CONNECTION_PROXY_KEY_OK;
		if(isAnonLogs(anonProxy)) {
			this->otherConnection->flags|=CONNECTION_NO_WRITE_CACHE;
		}
		if(this->otherConnection!=NULL) {
			this->otherConnection->anonFlags|=CONNECTION_PROXY_KEY_OK;
		}
		debugLog(15,"%x: anon proxy access allowed\n",(unsigned int)this);
	} else if(strncasecmp(httpLine,"proxy-authorization:",20)==0) {
		char *p,*pend;
		int len;

		p=httpLine+20;
		while(isspace(*p)) p++;
		if(strncmp(p,"Basic",5)==0) { p+=5; }
		while(isspace(*p)) p++;
		pend=strchr(p,0);
		if(pend>p && pend[-1]=='\r') { pend--; }

		len=pend-p;
		this->authBase64Str=pserver_malloc(len+1);
		memcpy(this->authBase64Str,p,len);
		this->authBase64Str[len]=0;
	} else if(this->otherConnection!=NULL) {
		if(strncasecmp(httpLine,"content-length:",15)==0) {
			char *p;
			p=httpLine+15;
			while(isspace(*p)) p++;
			this->webContentLength=atoi(p);
		}
		if(strncasecmp(httpLine,"cache-control:",14)==0) {
			if(strstr(httpLine+14,"no-cache")!=NULL) {
				this->otherConnection->flags|=CONNECTION_NO_READ_CACHE;
			} else if(strstr(httpLine+14,"max-age=0")!=NULL) {
				this->otherConnection->flags|=CONNECTION_NO_EXPIRES;
			}
		}
		if(strncasecmp(httpLine,"pragma:",7)==0) {
			if(strstr(httpLine+7,"no-cache")!=NULL) {
				this->otherConnection->flags|=CONNECTION_NO_WRITE_CACHE;
			}
		}
#if USE_PROXY_KEEP_ALIVE >0
		if(strncasecmp(httpLine,"proxy-connection:",17)==0) {
			this->proxyConnection=strdup(httpLine+17);
			if(strstr(httpLine+17,"keep-alive")!=NULL) {
				this->flags|=CONNECTION_PROXY_KEEP_ALIVE;
			}
		} else
#endif

		if(strncasecmp(httpLine,"keep-alive:",11)==0) {
		} else if(strncasecmp(httpLine,"if-modified-since:",18)==0) {
			if(!getDateStr(this->server,this->ifModified,httpLine+18)) {
				errorLog(this->server,"problem with parsing if modified date: %s, url:%s\n",httpLine+18,this->url);
			} else {
				checkIfModifiedWithCacheFile(this,httpLine);
			}
		} else

#if USE_WEB_KEEP_ALIVE == 0
		if(strncasecmp(httpLine,"connection:",11)!=0
		|| strncasecmp(httpLine,"keep-alive:",11)!=0)
#endif
		{
			appendStringBuf(&this->otherConnection->headerOutBuf,httpLine,strlen(httpLine));
			appendStringBufStatic(&this->otherConnection->headerOutBuf,"\n");
		}
	}
	return 1;
}


int
processWebHeaderLine(Connection *this,const char *httpLine)
{
	const char *p;

	assert(this!=NULL);
	assert(httpLine!=NULL);
	assert(this->otherConnection!=NULL);
	assert(!isHeaderDone(this));
	debugLog(10,"web header: %s\n",httpLine);
	if(this->headerLineUpto==0) {
		const char *p;
		if((p=strchr(httpLine,' '))==NULL) {
			errorConnection(this,"bad header from web server");
			return 0;
		}
		this->status=atoi(p+1);
		if(this->status!=200) {
			this->flags|=CONNECTION_NO_WRITE_CACHE;
		}
/*~~~ register connection failure if this is from anon_proxy */
	} else if(strncasecmp(httpLine,"cache-control:",14)==0) {
		if(strstr(httpLine+14,"no-cache")!=NULL || strstr(httpLine+14,"no-store")!=NULL || strstr(httpLine+14,"private")!=NULL) {
			this->flags|=CONNECTION_NO_WRITE_CACHE;
		}
	} else if(strncasecmp(httpLine,"last-modified:",14)==0) {
		if(!getDateStr(this->server,this->webLastModified,httpLine+14)) {
			errorLog(this->server,"problem with parsing last-modified date: %s, url:%s\n",httpLine+14,this->url);
		}
	} else if(strncasecmp(httpLine,"expires:",8)==0) {
		if(!getDateStr(this->server,this->webExpires,httpLine+8)) {
			errorLog(this->server,"problem with parsing expires date: %s, url:%s\n",httpLine+8,this->url);
		}
	} else if(strncasecmp(httpLine,"transfer-encoding:",18)==0) {
		if(strstr(httpLine+18,"chunked")!=NULL) {
			allocStringBuf(&this->chunknum,16);
			this->flags|=CONNECTION_CHUNKED_ENCODING;
		}
	} else if(strncasecmp(httpLine,"content-length:",15)==0) {
		p=httpLine+15;
		while(isspace(*p)) p++;
		this->webContentLength=atoi(p);
	} else if(strncasecmp(httpLine,"anon-proxy:",11)==0) {
		this->anonFlags|=CONNECTION_ANON_PROXY_MESSAGE;
	}

#if USE_WEB_KEEP_ALIVE == 0 
	if( strncasecmp(httpLine,"connection:",11)!=0)
#endif
	{
		appendWriteBufVar(this->otherConnection,httpLine);
		appendWriteBufStatic(this->otherConnection,"\n");
	}
	return 1;
}


