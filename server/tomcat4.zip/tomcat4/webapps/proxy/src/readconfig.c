
#include "pserver.h"
#include "server.h"
#include "access.h"
#include "readconfig.h"

/* ReadConfig *********************************/

typedef struct ReadConfig {
	Server *server;
	int bracketUpto;
	int withinAccess;
}ReadConfig;



static void
clearAccesses(Server *this)
{
	int a;
	assert(this!=NULL);
	for(a=0; a<this->totalAccesses;a++) {
		clearAccess(this->accesses+a);
	}
	FREE_PTR(this->accesses);
	this->totalAccesses=0;
}


static int
getStype(Server *this,const char *str)
{
	assert(str!=NULL);
	if(strcmp(str,"Host")==0) { return STYPE_HOST; }
	else if(strcmp(str,"Url")==0) { return STYPE_URL; }
	else if(strcmp(str,"Dest IP")==0) { return STYPE_DEST_IP; }
	else if(strcmp(str,"User IP")==0) { return STYPE_USER_IP; }
	else if(strcmp(str,"User Auth")==0) { return STYPE_USER_AUTH; }
	else if(strcmp(str,"Url Path")==0) { return STYPE_URL_PATH; }
	else if(strcmp(str,"Mac Address")==0) { return STYPE_MAC_ADDRESS; }
	else if(strcmp(str,"Time")==0) { return STYPE_TIME; }
	else if(strcmp(str,"Port")==0) { return STYPE_PORT; }
	else if(strcmp(str,"Day of Week")==0) { return STYPE_DOW; }
	else if(strcmp(str,"Url Regex")==0) { return STYPE_URL_REGEX; }
	else if(strcmp(str,"Label")==0) { return STYPE_LABEL; }
	else {
		errorLog(this,"unknown stype: %s\n",str);
	}
	return 0;
}

static int
getIstype(const char *str)
{
	assert(str!=NULL);
	if(strcmp(str,"is")==0) { return ISTYPE_IS; }
	else if(strcmp(str,"is not")==0) { return ISTYPE_IS_NOT; }
	return 0;
}

static int
getTarget(const char *str)
{
	assert(str!=NULL);
	if(strcmp(str,"Block")==0) { return TARGET_BLOCK; }
	else if(strcmp(str,"Allow")==0) { return TARGET_ALLOW; }
	else if(strcmp(str,"No Proxy")==0) { return TARGET_NO_PROXY; }
	else if(strcmp(str,"Admin")==0) { return TARGET_ADMIN; }
	else if(strcmp(str,"No cache")==0) { return TARGET_NO_CACHE; }
	else if(strcmp(str,"Anon")==0) { return TARGET_ANON; }
	else if(strcmp(str,"Other Proxy")==0) { return TARGET_OTHER_PROXY; }
	else if(strcmp(str,"Label")==0) { return TARGET_LABEL; }
	else if(strcmp(str,"Url Redirect")==0) { return TARGET_URL; }
	else if(strncmp(str,"And",3)==0) { return TARGET_AND; }
	return 0;
}


static int
parseTime(ReadConfig *readConfig,const char *str)
{
	int h,m=0;
	const char *colon;

	assert(str!=NULL);
	h=atoi(str);
	if((colon=strchr(str,':'))!=NULL) {
		m=atoi(colon+1);
	}
	if(h<0 || h>=24) {
		errorLog(readConfig->server,"Invalid hour: %s",str);
	}
	if(m<0 || m>=60) {
		errorLog(readConfig->server,"Invalid minute: %s",str);
	}
	return (h*60)+m;
}


/* parse port numbers, max is inclusive of last port number */
static void
parsePorts(const char *str,ReadConfig *readConfig,int *start,int *end)
{
	char *maxStr;
	const char *p;

	assert(str!=NULL);
	assert(readConfig!=NULL);
	assert(start!=NULL);
	assert(end!=NULL);

	for(p=str; *p; p++) {
		if(!(isspace(*p) || isdigit(*p) || *p=='-')) {
			errorLog(readConfig->server,"Invalid non-number character for port: %s",str);
		}
	}
	while(isspace(*str)) str++;
	if((maxStr=strchr(str,'-'))!=NULL) {
		*start=atoi(str);
		maxStr++;
		while(isspace(*maxStr)) maxStr++;
		*end=atoi(maxStr);
	} else {
		*end=*start=atoi(str);
	}
	if(*end<0 || *end>=65535) {
		errorLog(readConfig->server,"Invalid minimum port: %s",str);
	}
	if(*start<0 || *start>=65535) {
		errorLog(readConfig->server,"Invalid minimum port: %s",str);
	}
}

static void
parseStartEndTime(AccessUrl *this,const char *str,ReadConfig *readConfig)
{
	const char *dash;

	assert(this!=NULL);
	assert(str!=NULL);
	this->url.hourMin.start=parseTime(readConfig,str);
	if((dash=strchr(str,'-'))!=NULL) {
		this->url.hourMin.end=parseTime(readConfig,dash+1);
	} else {
		/* defaults to 1hr */
		this->url.hourMin.end=this->url.hourMin.start+60;
	}
}

static void
setAccessUrlNetwork(AccessUrl *this,const char *str,ReadConfig *readConfig)
{
	const char *p;
	int netMaskShift;
	char line[256];
	unsigned long ip;

	assert(this!=NULL);
	assert(str!=NULL);

	if((p=strchr(str,'/'))==NULL) {
		/* one ip address only */
		this->url.ip.min=ntohl(inet_addr(str));
		this->url.ip.max=this->url.ip.min+1;
		return;
	}
	strncpy(line,str,p-str);
	line[p-str]=0;
	if((ip=inet_addr(line))==-1) {
		errorLog(readConfig->server,"Invalid ip: %s\n",line);
	}
	this->url.ip.min=ntohl(ip);
	if(strchr(p+1,'.')==NULL) {
		/* 1 number netmask */
		netMaskShift=atoi(p+1);
		if(netMaskShift<0 || netMaskShift>32) {
			errorLog(readConfig->server,"Invalid netmask: %s\n",p+1);
		}
		this->url.ip.max=this->url.ip.min+(1<<(32-netMaskShift));
	} else {
		if((ip=inet_addr(p+1))==-1) {
			errorLog(readConfig->server,"Invalid netmask: %s\n",p+1);
		}
		this->url.ip.max=this->url.ip.min+(-1^ntohl(ip));
	}
}

static void
setAccessUrlFromStr(AccessUrl *this,char *str,ReadConfig *config)
{
	assert(this!=NULL);
	assert(str!=NULL);
	assert(config!=NULL);

	if(this->stype<0) { this->stype=getStype(config->server,str); }
	else if(this->istype<0) { this->istype=getIstype(str); }
	else if(this->str==NULL) { 
		this->str=strdup(str);
		if(this->stype==STYPE_DEST_IP || this->stype==STYPE_USER_IP) {
			setAccessUrlNetwork(this,str,config);
		}
		else if(this->stype==STYPE_TIME) {
			parseStartEndTime(this,str,config);
		}
		else if(this->stype==STYPE_DOW) {
			this->url.wday=parseDow(config->server,str);
		} else if(this->stype==STYPE_PORT) {
			int start,end;
			parsePorts(str,config,&start,&end);
			this->url.port.start=start;
			this->url.port.end=end;
		} else if(this->stype==STYPE_URL_REGEX) {
			if(regcomp(&this->url.regex,str,REG_EXTENDED|REG_ICASE|REG_NOSUB)!=0) {
				errorLog(config->server,"cannot compile regex: %s\n",str);
			}
		}
	}
	else {
		errorLog(config->server,"too much stuff in this access url: %s\n",str);
	}
}

static void
setAccessFromStr(Access *this,const char *str,ReadConfig *config)
{
	assert(this!=NULL);
	assert(str!=NULL);
	assert(config!=NULL);

	if(this->target<0) { this->target=getTarget(str); }
	else if(this->mess==NULL) { 
		this->mess=strdup(str); 
		if(this->target==TARGET_LABEL && strlen(this->mess)==0) {
			errorLog(config->server,"Label must have a name!\n");
		}
	}
	else {
		errorLog(config->server,"too much stuff in this access: %s\n",str);
	}
}


static int
readQuotedStr(ReadConfig *this,char *dest,int destLen,FILE *in)
{
	char *destEnd,*upto;
	int ch;
	int quoteChar=-1;

	assert(this!=NULL);
	assert(dest!=NULL);
	assert(destLen>0);
	assert(in!=NULL);

	destEnd=dest+destLen-1;
	upto=dest;
	while((ch=fgetc(in))!=EOF && upto<destEnd) {
		if(quoteChar>0) {
			if(ch==quoteChar) {
				*upto=0;
				return upto-dest;
			} else {
				if(ch=='\\') {
					*upto++=fgetc(in);
				} else {
					*upto++=ch;
				}
			}
			continue;
		}
		else if(ch=='\'' || ch=='"') {
			quoteChar=ch;
		} else if(ch=='(') {
			this->bracketUpto++;
		} else if(ch==')') {
			if(--this->bracketUpto<0) {
				errorLog(this->server,"internal err: config has too many )s\n");
			}
			if(this->withinAccess>=0 && this->bracketUpto<this->withinAccess) {
				this->withinAccess=-1;
			}
		}
	}
	return -1;
}



static void
clearConfig(Server *this)
{
	assert(this!=NULL);

	this->listenPort=8080;
	this->ourUrl=NULL;
	this->userAuthCmd="/usr/local/samba/bin/ntlm_auth '--username=%s' '--password=%s' '--domain=%s'";
}


static const int minTimeOut=5;

/* check if somebody's updated the config file */
int
checkConfig(Server *this,time_t t)
{
	struct stat st;
	int r=1;

	assert(this!=NULL);
	if(t<this->nextConfigFileCheck) {
		return 0;
	}
	this->nextConfigFileCheck=t+5;
	if(stat(this->configFile,&st)!=0) {
		errorLog(this,"Cannot find config file: %s, %s\n",this->configFile,pserver_strerror(errno));
		return 0;
	}
	if(st.st_mtime>this->configFileLoaded) {
		r=readConfigFile(this);
		this->configFileLoaded=st.st_mtime;
	}
	return r;
}

static void
checkValidAccessSettings(Server *this) 
{
	struct Access *lastAccess,*access;
	struct AccessUrl *accessUrl,*accessUrlEnd;
	StringCache labels;

	initStringCache(&labels);
	if(this->totalAccesses>0) {
		lastAccess=this->accesses+this->totalAccesses-1;
		if(lastAccess->target==TARGET_AND) {
			errorLog(this,"The last target should not be 'and..'\n");
		}

		/* check all labels are valid */
		for(access=this->accesses; access<=lastAccess; access++) {
			accessUrlEnd=access->urls+access->urlsTotal;
			for(accessUrl=access->urls; accessUrl<accessUrlEnd; accessUrl++) {
				if(accessUrl->stype==STYPE_USER_AUTH) {
					if((access->target!=TARGET_BLOCK && access->target!=TARGET_AND) || accessUrl->istype!=ISTYPE_IS_NOT) {
						errorLog(this,"Must pick 'Block'+'is not' when using the 'user auth' command: %s (%s)\n",accessUrl->str,access->mess);
					}
				}
				if(accessUrl->stype!=STYPE_LABEL) { continue; }
				if(findStringCacheItem(&labels,accessUrl->str)==NULL) {
					errorLog(this,"Unknown label: %s\n",accessUrl->str);
				}
			}

			if(access->target==TARGET_LABEL) {
				newStringCacheItem(&labels,access->mess,"");
			}
		}
	}
}

static void
checkValidAnonSettings(Server *this) 
{
	if(this->anonProxy.useAnon) {
		if(this->anonProxy.timeout<minTimeOut) {
			errorLog(this,"Data time out is too small: %i\n",this->dataTimeOutSeconds);
		}
		if(this->anonProxy.listenPort==0) {
			errorLog(this,"Must have a valid anon proxy port number\n");
		}
	}
}


static void
checkValidServerSettings(Server *this) 
{
	if(this->timeOutSeconds<minTimeOut) {
		errorLog(this,"Time out is too small: %i\n",this->timeOutSeconds);
	}
	if(this->dataTimeOutSeconds<minTimeOut) {
		errorLog(this,"Data time out is too small: %i\n",this->dataTimeOutSeconds);
	}
	if(this->listenPort==0) {
		errorLog(this,"Must have a valid port number\n");
	}

	checkValidAnonSettings(this);
	checkValidAccessSettings(this);
}

int
readConfigFile(Server *this)
{
	FILE *in;
	char line[8196];
	ReadConfig readConfig;
	int accessUrlDepth=-1;
	AccessUrl *currentAccessUrl=NULL;
	Access *currentAccess=NULL;
	char *filename=this->configFile;
#ifdef _WIN32
	OVERLAPPED overlap = {0,0,0,0,NULL};
#endif

	assert(this!=NULL);
	assert(filename!=NULL);
	readConfig.bracketUpto=0;
	readConfig.server=this;
	readConfig.withinAccess=-1;

	debugLog(5,"load config file...\n");
	clearConfig(this);
	clearAccesses(this);
	if((in=pserver_fopen(filename,"rb"))==NULL) {
		errorLog(this,"Could not open config:%s: %s\n",filename,pserver_strerror(errno));
		assert(0);
	}
#ifdef _WIN32
	/* this is same as the php lock */
	if(LockFileEx((HANDLE)_get_osfhandle(fileno(in)),LOCKFILE_EXCLUSIVE_LOCK|LOCKFILE_FAIL_IMMEDIATELY,0,1,0,&overlap)==0) {
#else
	if(flock(fileno(in),LOCK_NB|LOCK_EX)<0) {
#endif
		/* still writing to the config file... */
		fclose(in);
		return 1;
	}

#define READ_CONF(x,y) \
	} else if(strcmp(line,x)==0) {	\
		readQuotedStr(&readConfig,line,sizeof(line),in);	\
		y;	\
		continue;

#define READ_INT_CONF(x,y) READ_CONF(x,this->y=atoi(line))
#define READ_STR_CONF(x,y) FREE_PTR(this->y) READ_CONF(x,this->y=strdup(line))

	while(readQuotedStr(&readConfig,line,sizeof(line),in)>=0) {
		if(readConfig.withinAccess>=0) {
			if(currentAccess==NULL) { accessUrlDepth=readConfig.bracketUpto; }
			if(currentAccess==NULL || currentAccess->mess!=NULL) {
				currentAccess=newAccess(this);
			}
			if(accessUrlDepth!=readConfig.bracketUpto) {
				setAccessFromStr(currentAccess,line,&readConfig);
			} else {
				if(currentAccessUrl==NULL || currentAccessUrl->str!=NULL) {
					currentAccessUrl=newAccessUrl(currentAccess);
				}
				setAccessUrlFromStr(currentAccessUrl,line,&readConfig);
			}
		} else if(strcmp(line,"access")==0) {
			readConfig.withinAccess=readConfig.bracketUpto+1;
			continue;
		READ_STR_CONF("pid_file",pid_file)
		READ_STR_CONF("ourUrl",ourUrl)
		READ_INT_CONF("timeOutSeconds",timeOutSeconds)
		READ_INT_CONF("dataTimeOutSeconds",dataTimeOutSeconds)
		READ_STR_CONF("userAuthCmd",userAuthCmd)
		READ_INT_CONF("port",listenPort)
		READ_INT_CONF("anonPort",anonProxy.listenPort)
		READ_INT_CONF("maxCacheMegs",maxCacheMegs)
		READ_INT_CONF("maxLogFileSize",maxLogFileSize)
		READ_INT_CONF("maxLogRotate",maxLogRotate)
		READ_INT_CONF("anonProxy",anonProxy.useAnon)
		READ_INT_CONF("anonProxyFailAbort",anonProxy.failAbort)
		READ_INT_CONF("anonProxyBlockIntranet",anonProxy.blockIntranet)
		READ_INT_CONF("anonProxyTimeout",anonProxy.timeout)
		READ_INT_CONF("anonProxyMaxFails",anonProxy.maxFails)
		READ_STR_CONF("anonProxyHomeBase",anonProxy.homeBase)
		}
	}
#ifdef _WIN32
	UnlockFileEx((HANDLE)_get_osfhandle(fileno(in)),0,1,0,&overlap);
#else
	flock(fileno(in),LOCK_UN);
#endif
	fclose(in);

	checkValidServerSettings(this);

	return 1;
}


