#ifndef __PSERVER_H
#define __PSERVER_H



#ifdef _WIN32
#define _WIN32_WINNT 0x0500
#ifndef _MT 
#define _MT 
#endif 


#include <winsock2.h>
#include <windows.h>
#include <Ws2tcpip.h>
#include <io.h>
#include <share.h>

#endif

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/stat.h>


#ifdef _WIN32

#ifdef _MSC_VER
/* MSVC doesn't have dirent.h */
#include "win32_dirent.h"
#else
#include <dirent.h>
#endif

#include "regex.h"
#else
#include <dirent.h>
#include <regex.h>
#endif





#ifdef NDEBUG
#define DEBUGLVL 0

#define debugLog(...)

#else

#ifndef DEBUGLVL
/* 29 doesn't print the data downloaded, 30 will */
#define DEBUGLVL 29
/* #define DEBUGLVL 30 */

#endif
void debugLog(int lvl,const char *mess,...);

#endif

struct Server;

void errorLog(struct Server *this,const char *mess,...);








#ifndef _MSC_VER
#include <unistd.h>
#include <sys/file.h>
#include <sys/time.h>

#define STATIC_INLINE static inline 
#define LONG_LONG long long


STATIC_INLINE void pserver_localtime(struct tm *tmPtr,time_t *t) {
	memcpy(tmPtr,localtime(t),sizeof(tmPtr[0]));
}
STATIC_INLINE void pserver_gmtime(struct tm *tmPtr,time_t *t) {
	memcpy(tmPtr,gmtime(t),sizeof(tmPtr[0]));
}

STATIC_INLINE char *qstrncpy(char *destOrig, const char *src,int destLen) {
	char *destEnd=destOrig+destLen-1;
	char *dest=destOrig;
	while(dest<destEnd && *src) {
		*dest++=*src++;
	}
	*dest=0;
	return destOrig;
}


#define pserver_open open
#define pserver_strerror strerror
#define pserver_fopen fopen
#define pserver_vsnprintf vsnprintf
#define pserver_close close


#else
/* msvc */

#define STATIC_INLINE static __inline
#define LONG_LONG __int64
#define qstrncpy(dest,src,len) strcpy_s(dest,len,src)



STATIC_INLINE int pserver_vsnprintf(char *dest,size_t destLen,const char *format,va_list ap) {
	int len=vsnprintf_s(dest,destLen,_TRUNCATE,format,ap);
	if(len<0) dest[destLen-1]=0;
	return len;
}

STATIC_INLINE FILE *pserver_fopen(const char *filename,const char *mode) {
	FILE *p;
	if((p=_fsopen(filename,mode,_SH_DENYWR))==NULL) {
		return NULL;
	}
	return p;
}

STATIC_INLINE int pserver_open(const char *filename,int mode,...) {
	int fd;
	_sopen_s(&fd,filename,_O_CREAT|_O_BINARY|O_RDWR,_SH_DENYNO,_S_IREAD|_S_IWRITE);
	return fd;
}

#include <process.h>

#define strcasecmp _stricmp
#define strncasecmp _strnicmp
#define pserver_close _close
#define read _read
#define lseek _lseek
#define write _write
#define unlink _unlink
#define strdup _strdup
#define fileno _fileno
#define getpid _getpid
#define pserver_localtime localtime_s
#define pserver_gmtime gmtime_s
#define strncpy(dest,src,len) strncpy_s(dest,len+1,src,len)
#define S_ISDIR(x) ((x)&_S_IFDIR)


STATIC_INLINE char *pserver_strerror(int err) {
	static char buf[256];
	strerror_s(buf,sizeof(buf),err);
	return buf;
}




STATIC_INLINE int snprintf(char *dest,int destLen,const char *format,...) {
	int ret;
	va_list args;
	va_start(args,format);
	ret=pserver_vsnprintf(dest,destLen,format,args);
	va_end(args);
	if(ret>=destLen) {
		debugLog(5,"snprintf buffer not big enough: %s",format);
	}
	return ret;
}


STATIC_INLINE int mkdir(const char *dir) {
	return CreateDirectory(dir,NULL)?0:-1;
}

STATIC_INLINE void getcwd(char *buf, int buf_size) {
	GetCurrentDirectory(buf_size,buf);
}
STATIC_INLINE void chdir(const char *dir) {
	if(SetCurrentDirectory(dir)==0) {
		errorLog(NULL,"Cannot change to dir: %s\n",dir);
		assert(0);
	}
}

/* endif msvc */
#endif









#ifdef _WIN32
/* win32...*/

#include <wincrypt.h>
#include <share.h>





#define SOCKETFD SOCKET
#define MUTEX_HANDLE HANDLE
#define THREAD_HANDLE unsigned int
#define DONT_SELECT_FILE_FDS 1
#define INVALID_SOCKETFD INVALID_SOCKET
#define USE_SOCKET_PIPE 1
#define usleep(x) Sleep((x)/1000)

/* _beginthread returns =1L on error _beginthreadex returns =0L on error
 * pthread_create returns !=0 on error
 */
#define pthread_create(thread,n,proc,ptr) \
	(((((thread)[0])=_beginthread((void (__cdecl *)(void *))(proc),0,(ptr)))==1L)?1:0)

/*
	_beginthreadex(NULL,0,(unsigned (__stdcall *)(void *))(proc),(ptr),0,thread);
*/

/* string to print "long long" in printf */
#define PRINTF_LONG_LONG "%I64d"

#else
/* linux...*/
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/poll.h>
#define USE_POLL 1
#define SOCKETFD int
#define INVALID_SOCKETFD -1
#define MUTEX_HANDLE pthread_mutex_t
#define THREAD_HANDLE pthread_t
#define USE_SOCKET_PIPE 0
#define Sleep(x) usleep((x)*1000)

STATIC_INLINE int closesocket(int fd) 
{
	assert((fd)>0); 
	return close((fd));
}

#ifndef O_BINARY
#define O_BINARY 0
#endif


#define PRINTF_LONG_LONG "%lli"

/* endif linux */
#endif

/* calculate stats 1=while downloading or 0=after downloading finishes */
#define CALC_STATS_ON_DOWNLOAD 1
#define DNS_CACHE_SECS 60

#define USE_PROXY_KEEP_ALIVE 1
#define USE_WEB_KEEP_ALIVE 1

/*
 * ssl anon proxy not done: not sure how to do in windows.
 */
#define USE_SSL 1







#define SOCKS_PROXY_VER 0x7e


#define DATE_STR_LEN 16
#define EMPTY_DATE "000000000000000" 




#define FREE_PTR(x) if((x)!=NULL) { free((x)); (x)=NULL; }



void timeToStr(char *dest,time_t tnum);
int strToRfc1123(char *dest,int destLen,const char *str);
int getDateStr(struct Server *this,char *dateStr,const char *from);
long getMSecDiff(struct timeb *t1, struct timeb *t2);
int parseDow(struct Server *this,const char *str);


const char *sockErrorStr();



STATIC_INLINE
const char *
inet_ntoa_l(unsigned long i)
{
	struct in_addr inAddr;
	inAddr.s_addr=i;
	return inet_ntoa(inAddr);
}

STATIC_INLINE int
cmpDateStr(const char *d1,const char *d2)
{
	assert(d1!=NULL);
	assert(d2!=NULL);
	return strcmp(d1+1,d2+1);
}

/* returns: -1=more than 1 day away, 1=less than 1 day away. */
STATIC_INLINE int
cmpDayStr(const char *d1,const char *d2)
{
	int dayDiff,timeDiff;

	assert(d1!=NULL);
	assert(d2!=NULL);
	dayDiff=strncmp(d1+1,d2+1,8);
	timeDiff=strcmp(d1+9,d2+9);
	if(dayDiff>0) { /* d1>d2 */
		return timeDiff>0?1:0;
	}
	else if(dayDiff<0) { /* d1>d2 */
		return timeDiff<0?-1:0;
	}
	return 0;
}


STATIC_INLINE void *pserver_malloc(size_t size) {
	void *ptr;
	ptr=malloc(size);
	if(ptr==NULL) {
		errorLog(NULL,"Out of memory\n");
		exit(1);
		return NULL;
	}
	return ptr;
}



#endif
