#ifndef __CONNECTION_H
#define __CONNECTION_H

#if USE_SSL
#include  <openssl/ssl.h>
#include  <openssl/err.h>
#endif
#include "stringbuf.h"
#include "cachefile.h"
#include "url.h"

enum {
	CONNECTION_WEB_CONNECTION=1,
	CONNECTION_CLOSE=2,
	CONNECTION_SOCKET_CONNECTED=4,

	/**** command type.... */
	CONNECTION_CMD_CONNECT=8,
	CONNECTION_CMD_INTERNAL=0x10,
	CONNECTION_CMD_GET=0x20,

	/**** web connection settings.... */
	CONNECTION_NO_READ_CACHE=0x40,	/* don't read from the cache */
	CONNECTION_WRITE_CACHE=0x80,	/* write to cache */
	CONNECTION_READ_CACHE=0x100,	/* read from cache */
	/* if cache is more recent we'll read from the cache when we get a 304 */
	CONNECTION_CACHE_MORE_RECENT_THAN_USER=0x200,
	CONNECTION_NO_EXPIRES=0x400,
	CONNECTION_NO_WRITE_CACHE=0x800,
	CONNECTION_DNS_THREAD_RUNNING=0x1000,
	/* dns step 2. thread ended... */
	CONNECTION_DNS_DONE=0x2000,
	/* dns step 3. connect up to the server... */
	CONNECTION_DNS_DONE_PROCESSED=0x4000,
	CONNECTION_CHUNKED_ENCODING=0x8000,
	CONNECTION_BODY_RECEIVED=0x20000,

	/* set if the startTm structure has been set */
	CONNECTION_HAS_STARTTM=0x40000,

	/**** user connection settings.... */
	CONNECTION_PROXY_KEEP_ALIVE=0x80000,  /* keep this connection alive with the proxy(user connection only) */
	/* using something straight from cache without checking
	 * because it has not expired
	 */
	CONNECTION_USING_UNEXPIRED	=0x100000,
	CONNECTION_SOCKS		=0x400000,
	CONNECTION_SOCKS_CONNECT	=0x800000,
	CONNECTION_SOCKS_BIND		=0x1000000,
	CONNECTION_SOCKS_ACCEPTED	=0x2000000,
	CONNECTION_SOCKS_VER4		=0x4000000,
	CONNECTION_SOCKS_WAIT_FOR_ZERO	=0x8000000,
	/* read again without selecting/polling, used for ssl
	 * when ssl fills the whole buf, there may still be stuff
	 * there inside the bio. selecting/polling only detects
	 * new data, doesn't check the bio.
	 */
	CONNECTION_READ_AGAIN		=0x20000000,
	/* we need to retry write so don't read any more into here */
	CONNECTION_RETRY_WRITE		=0x40000000
};

enum {
	/* this connection is being forwarded to another proxy */
	CONNECTION_FROM_PROXY		=0x1,
	CONNECTION_TO_PROXY		=0x2,
	CONNECTION_ANON_PROXY_MESSAGE	=0x4,
	CONNECTION_PROXY_KEY_OK		=0x8
};

#define isToProxy(conn) ((conn)->anonFlags&CONNECTION_TO_PROXY)
#define isProxyKeyOk(conn) ((conn)->anonFlags&CONNECTION_PROXY_KEY_OK)

typedef struct Connection {
	SOCKETFD conn;		/* current connection, can be to a cached file */
	SOCKETFD webConn;	/* backed up connection to web server if conn is something else */

	unsigned long userAddr;
	unsigned int userPort;

	char *url;
	Url parsedUrl;

	unsigned int flags;
	unsigned int anonFlags;
	StringBuf writeBuf;
	/* header out buf contains the users' header
	 * it'll be sent to writeBuf when the header finishes.
	 * (only used in web connection)
	 */
	StringBuf headerOutBuf;
	struct Connection *otherConnection;
	time_t lastActivity;
	struct Server *server;


	/* header */
	int status;
	char *cmd;
	char *httpVers;
	int headerLineUpto; /* -1=header done */
	StringBuf currentLine; /* current header line */
	char ifModified[DATE_STR_LEN];
	char webLastModified[DATE_STR_LEN];
	char webExpires[DATE_STR_LEN];
	char *authBase64Str;
	int webContentLength;
	char *proxyConnection;

	/* access */
	struct timeb startTime;
	struct tm startTm;  /* only used when user has time/dow restrictions */
	char *authUser;

	/* counters */
	int recvLen,recvBodyLen;
	int sentLen;
	int totalResets,totalRecvLen,totalSentLen;

	char *errorImg;

	int currentChunkTodo;
	StringBuf chunknum;

	CacheFile cacheFile;

	/* the looked up host address 
	 * and the currently connected host address 
	 */
	unsigned long hostAddr,connectedAddr;
	unsigned short hostPort,connectedPort;
	struct {
		unsigned long addr;
		unsigned short port;
		struct OtherProxy *otherProxy;
	}*hostAddrs;
	int hostAddrsUpto,hostAddrsTotal;
	int anonProxyAuthStrUpto;

	/* dns */
	MUTEX_HANDLE lock;
	struct DnsLookup *dnsLookup;
	THREAD_HANDLE dnsThread;
	SOCKETFD pipeFds[2];
#if USE_SSL
	SSL *ssl;
	BIO *sslBIO;
#endif

	struct Connection *nextConnection,*prevConnection;
}Connection;


Connection *getNewConnection(struct Server *this,Connection *creator);
void closeConnection(Connection *);
void appendWriteBuf(Connection *this,const char *data,int len);


#define appendWriteBufStatic(t,d) appendWriteBuf((t),(d),sizeof((d))-1)
#define appendWriteBufVar(t,d) appendWriteBuf((t),(d),strlen((d)))


SOCKETFD connectToNextAddress(Connection *this);
SOCKETFD connectToAddress(Connection *this);

void closeMarkedConnection(struct Server *this,Connection *conn);
int readConnection(Connection *this);
int writeConnection(Connection *this);
void nonBlockSocket(SOCKETFD webConn,unsigned long on);

void closePipeFds(Connection *this);
#ifndef NDEBUG
void assertConnection(Connection *this);
#else
#define assertConnection(x)
#endif


/*********** inlines */
STATIC_INLINE int
isReconnectOk(Connection *this)
{
	if(this->flags&CONNECTION_WEB_CONNECTION 
	&& this->sentLen==0
	&& !isStringBufEmpty(&this->writeBuf)) {
		return 1;
	}
	return 0;
}


STATIC_INLINE void
lockConnection(Connection *this)
{
#ifdef _WIN32
	WaitForSingleObject(this->lock,INFINITE);
#else
	pthread_mutex_lock(&this->lock);
#endif
}
STATIC_INLINE void
unlockConnection(Connection *this)
{
#ifdef _WIN32
	if(!ReleaseMutex(this->lock)) {
		errorLog(this->server,"unable to release mutex\n");
	}
#else
	pthread_mutex_unlock(&this->lock);
#endif
}

STATIC_INLINE int
isHeaderDone(Connection *this)
{
	return this->headerLineUpto<0?1:0;
}


#endif
