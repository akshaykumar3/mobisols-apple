
#include "pserver.h"
#include "connection.h"
#include "usagestats.h"
#include "server.h"
#include "access.h"
#include "socks.h"
#include "internalcmd.h"
#include "cachefile.h"
#include "connmessages.h"
#include "dns.h"
#include "http.h"

#if USE_SSL
#include <openssl/ssl.h>
#endif

/* connection misc *****************************************/


void
nonBlockSocket(SOCKETFD webConn,unsigned long on)
{

#ifdef _WIN32
	assert(webConn!=INVALID_SOCKETFD);
	ioctlsocket(webConn,FIONBIO,&on);
#else
	int flags;
	assert(webConn!=INVALID_SOCKETFD);

	flags=fcntl(webConn,F_GETFL,0);
	if(on) { flags|=O_NONBLOCK; }
	else { flags&=-1^O_NONBLOCK; }
	fcntl(webConn,F_SETFL,flags);
#endif
}



void
appendWriteBuf(Connection *this,const char *data,int len)
{
	assert(this!=NULL);
	assert(data!=NULL);

	if(this->flags&CONNECTION_READ_CACHE) { return; }
	debugLog(25,"appendWriteBuf: %x,upto:%i,len:%i(%c)\n",(unsigned int)this,this->writeBuf.upto,len,len>0?data[0]:' ');
	appendStringBuf(&this->writeBuf,data,len);
}






/* connection *********************************/



/* reset connection to get next request
 * force: 0 = can be "marked" for close and we close it later
 * 	  1 = force it to be closed(only used by closeConnection when the connection is taken off the link list)
 */
static void
resetConnection(Connection *this,int force)
{
	int flags;

	assert(this!=NULL);

#if USE_WEB_KEEP_ALIVE == 0
	assert(this->flags&CONNECTION_PROXY_KEEP_ALIVE);
	assert(!(this->flags&CONNECTION_WEB_CONNECTION));
#endif

	debugLog(5,"resetConnection: %x\n",(unsigned int)this);

	if(this->url!=NULL) {
		logConnection(this);

		if(this->flags&CONNECTION_WRITE_CACHE) {
			assert(this->flags&CONNECTION_WEB_CONNECTION);
			assert(this->cacheFile.fd>0);
			pserver_close(this->cacheFile.fd);
			if(this->recvBodyLen!=this->webContentLength) {
				debugLog(5,"not closed properly removing:%x: %s,recvbody:%i,contentlen:%i\n",(unsigned int)this,this->cacheFile.filename,this->recvBodyLen,this->webContentLength);
				unlink(this->cacheFile.filename);
			}
		}
	}

	if((this->flags&CONNECTION_READ_CACHE)) {
		assert(this->conn!=INVALID_SOCKETFD);

		if(this->webConn==INVALID_SOCKETFD && force==0) {
			debugLog(5,"%x: mark as close, only reading from file, not from web\n",(unsigned int)this);
			this->flags|=CONNECTION_CLOSE;
			return;
		}
		assert(this->conn>0);
		/* BUG: Problem here in windows, sometimes has problems closing */
		pserver_close(this->conn);
		this->flags&=-1^CONNECTION_READ_CACHE;
		this->conn=this->webConn;
		this->webConn=INVALID_SOCKETFD;
	}

	closePipeFds(this);
	FREE_PTR(this->url);
	clearUrl(&this->parsedUrl);
	FREE_PTR(this->httpVers);
	FREE_PTR(this->cmd);
	FREE_PTR(this->proxyConnection);
	this->headerLineUpto=0;
	this->anonProxyAuthStrUpto=0;
	clearStringBuf(&this->currentLine);
	clearStringBuf(&this->writeBuf);
	clearStringBuf(&this->headerOutBuf);

	flags=this->flags;
	this->flags=flags&(CONNECTION_WEB_CONNECTION|CONNECTION_SOCKET_CONNECTED|CONNECTION_PROXY_KEEP_ALIVE);
	this->anonFlags=0;
	disconnectDnsLookup(this);
	if(!(this->flags&CONNECTION_WEB_CONNECTION)) {
		/* no need ever to do dns on users' connection */
		this->flags|=CONNECTION_DNS_DONE_PROCESSED;
	}
	this->totalResets++;
	this->totalRecvLen+=this->recvLen;
	this->totalSentLen+=this->sentLen;
	this->recvLen=this->recvBodyLen=this->sentLen=0;
	this->ifModified[0]=0;
	this->webLastModified[0]=0;
	this->webExpires[0]=0;
	FREE_PTR(this->authBase64Str);
	FREE_PTR(this->authUser);
	this->webContentLength=-1;
	this->status=0;
	this->hostAddr=0;
	this->hostPort=0;
	FREE_PTR(this->hostAddrs);
	clearStringBuf(&this->chunknum);
	this->hostAddrsUpto=this->hostAddrsTotal=0;
	this->currentChunkTodo=0;
}

static int
checkClose(Connection *this)
{
	assert(this!=NULL);
	assertConnection(this);

	debugLog(20,"%x: check close, empty:%i, other:%x\n",(unsigned int)this,isStringBufEmpty(&this->writeBuf),(unsigned int)this->otherConnection);

#if USE_WEB_KEEP_ALIVE == 0
	if(this->otherConnection==NULL
	&& (this->flags&CONNECTION_WEB_CONNECTION || isStringBufEmpty(&this->writeBuf))
	) {
		debugLog(6,"mark for closing later: %x\n",(unsigned int)this);
		/* we've written everything over or we're the web connection, 
		 * and the other side has closed connection, lets close too.
		 */
		this->flags|=CONNECTION_CLOSE;
		return 0;
	}
#else
	/* close/reset the users' connection if we've received and 
	 * sent everything.
	 * close the web connection if the users' connection is off.
	 */
	if(
	(this->otherConnection==NULL && this->flags&CONNECTION_WEB_CONNECTION)
	||
		(!(this->flags&CONNECTION_WEB_CONNECTION) 
		&& (this->flags&CONNECTION_BODY_RECEIVED || this->otherConnection==NULL) 
		&& isStringBufEmpty(&this->writeBuf) )
	) {
		if(this->flags&CONNECTION_PROXY_KEEP_ALIVE) {
			resetConnection(this,0);
		} else {
			this->flags|=CONNECTION_CLOSE;
		}
		return 0;
	}
#endif
	return 1;
}






void
closeConnection(Connection *conn)
{
	Server *this;

	assert(conn!=NULL);

	this=conn->server;
	assert(this!=NULL);

	debugLog(5,"closeConn:%x\n",(unsigned int)conn);

	if(conn->nextConnection!=NULL) {
		assert(conn->nextConnection->prevConnection==conn);
		conn->nextConnection->prevConnection=conn->prevConnection;
	}
	if(conn->prevConnection!=NULL) {
		assert(conn->prevConnection->nextConnection==conn);
		conn->prevConnection->nextConnection=conn->nextConnection;
	} else {
		assert(this->firstConnection==conn);
		this->firstConnection=conn->nextConnection;
	}

	if(conn->otherConnection!=NULL) {
		assert(conn->otherConnection->otherConnection==conn);
		conn->otherConnection->otherConnection=NULL;
		debugLog(15,"clearing other conn:%x\n",(unsigned int)conn->otherConnection);

		if(conn->flags&(CONNECTION_WEB_CONNECTION)) {

			if(conn->webContentLength<=0 || conn->recvBodyLen<conn->webContentLength) {
				/* not everything received 
				 * don't keep-alive the user's connection
				 */
				debugLog(10,"no content-length/aborted/web closed connection: cancel proxy keep-alive: %x, recved:%i!=contentlen:%i\n",(unsigned int)conn->otherConnection,conn->recvBodyLen,conn->webContentLength);
				conn->otherConnection->flags&=-1^CONNECTION_PROXY_KEEP_ALIVE;
			} else {
				debugLog(10,"download ok, proxy keep-alive ok: %x, %i==%i\n",(unsigned int)conn->otherConnection,conn->recvBodyLen,conn->webContentLength);
			}
		}
		checkClose(conn->otherConnection);
	}

	if(this->shutdownConnection==conn) { this->shutdownConnection=NULL; }
	if(conn->conn!=INVALID_SOCKETFD) {
		/* sometimes conn is not set because dns errored */
#if USE_SSL
		if(conn->ssl!=NULL) {
#if 0
/*** this was causing the "bad header" bug */
			SSL_shutdown(conn->ssl);
#endif
			SSL_free(conn->ssl);
		}
#endif
		if(conn->flags&CONNECTION_READ_CACHE) {
			/* win32 needs to run close differently on sockets and on files */
			if(pserver_close(conn->conn)!=0) {
				errorLog(this,"Couldn't close cache file fd:%i, %s\n",conn->conn,pserver_strerror(errno));
			}
		}
		else if(closesocket(conn->conn)!=0) {
			errorLog(this,"Couldn't close socket:%s:%i(sock:%i), %s\n",inet_ntoa_l(conn->userAddr),ntohs(conn->userPort),conn->conn,sockErrorStr());
		}
	}

	if(conn->webConn!=INVALID_SOCKETFD) {
		if(closesocket(conn->webConn)!=0) {
			errorLog(this,"Couldn't close web socket:%i, %s:%i, %s\n",conn->webConn,inet_ntoa_l(conn->userAddr),ntohs(conn->userPort),sockErrorStr());
		}
	}

	resetConnection(conn,1);

	this->totalConnections--;
#ifdef _WIN32
	CloseHandle(conn->lock);
#else
	pthread_mutex_destroy(&conn->lock);
#endif
	debugLog(15,"closeConnection done:%x,%i\n",
		(unsigned int)conn,conn->userPort);
	free(conn);
}





/* close pipe fds and bring back the web fd */
void
closePipeFds(Connection *this)
{
	assert(this!=NULL);

	debugLog(15,"close pipe fds: %x\n",(unsigned int)this);
	if(this->pipeFds[0]!=INVALID_SOCKETFD) {
#if USE_SOCKET_PIPE
		closesocket(this->pipeFds[0]);
#else
		assert(this->pipeFds[0]>0);
		pserver_close(this->pipeFds[0]);
#endif
		if(this->pipeFds[0]==this->conn)  {
			this->conn=this->webConn; 
			this->webConn=INVALID_SOCKETFD;
		}
		this->pipeFds[0]=-1; 
	}
	if(this->pipeFds[1]!=INVALID_SOCKETFD) { 
#if USE_SOCKET_PIPE
		closesocket(this->pipeFds[1]);
#else
		assert(this->pipeFds[1]>0);
		pserver_close(this->pipeFds[1]);
#endif
		this->pipeFds[1]=-1; 
	}
}



#ifndef NDEBUG

void
assertConnection(Connection *this)
{
	assert(this!=NULL);
	assert(this->server!=NULL);
	assert(this->lastActivity<=(time(NULL)+2));
	assert(this->recvLen>=0);
	assert(this->recvBodyLen>=0);
	assert(this->sentLen>=0);

	/* shouldn't read/write to the cache at the same time */
	if(this->flags&CONNECTION_READ_CACHE) {
		assert(!(this->flags&CONNECTION_WRITE_CACHE));
	}
	else {
		if(this->connectedAddr>0) {
			assert(this->conn!=INVALID_SOCKETFD);
		}
	}
	if(this->flags&CONNECTION_WRITE_CACHE) {
		assert(!(this->flags&CONNECTION_READ_CACHE));
	}
	if(this->flags&CONNECTION_DNS_DONE_PROCESSED) {
		assert(this->pipeFds[0]==INVALID_SOCKETFD);
		assert(this->pipeFds[1]==INVALID_SOCKETFD);
	} else if(this->dnsLookup!=NULL) {
		assert(this->pipeFds[0]!=INVALID_SOCKETFD);
		assert(this->pipeFds[1]!=INVALID_SOCKETFD);
	}

	if(this->flags&CONNECTION_WEB_CONNECTION) {
#if USE_WEB_KEEP_ALIVE == 0
		assert(this->url!=NULL);
#endif
		if(this->otherConnection!=NULL) {
			assert(!(this->otherConnection->flags&CONNECTION_WEB_CONNECTION));
			if(isHeaderDone(this->otherConnection)) {
				assert(this->conn!=INVALID_SOCKETFD);
				/* we should have flushed out headerOutBuf to writeBuf when we received the users' header */
				assert(isStringBufEmpty(&this->headerOutBuf));
			}
		}
	} else {
		if(isHeaderDone(this)) {
			assert(this->conn!=INVALID_SOCKETFD);
		}
		assert(isStringBufEmpty(&this->headerOutBuf));
		assert(this->webConn==INVALID_SOCKETFD);
		if(!(this->flags&CONNECTION_SOCKS) && this->url!=NULL) {
			assert(this->cmd!=NULL);
			assert(this->httpVers!=NULL);
			if(this->flags&CONNECTION_CMD_CONNECT) {
				assert(strcmp(this->cmd,"CONNECT")==0);
			}
		}
		if(this->otherConnection!=NULL) {
			assert(this->otherConnection->flags&CONNECTION_WEB_CONNECTION);
		}
	}
	if(this->flags&CONNECTION_CHUNKED_ENCODING) {
		assert(this->chunknum.buf!=NULL);
		assert(this->chunknum.len>0);
	}
#if USE_SSL
	if(this->ssl!=NULL) {
		assert(this->sslBIO!=NULL);
	}
#endif
}

#endif




SOCKETFD
connectToNextAddress(Connection *this)
{
	OtherProxy *otherProxy;
	assert(this!=NULL);

	if(this->hostAddrsUpto>=this->hostAddrsTotal) {
		return INVALID_SOCKETFD;
	}

	assert(this->hostAddrs!=NULL);
	assert(this->hostAddrsUpto>0);
	this->hostAddr=this->hostAddrs[this->hostAddrsUpto].addr;
	this->hostPort=this->hostAddrs[this->hostAddrsUpto].port;
	if((otherProxy=getCurrentOtherProxy(this))!=NULL) {
		otherProxy->fails++;
	}
	this->hostAddrsUpto++;
	if((otherProxy=getCurrentOtherProxy(this))!=NULL) {
		/* change the auth key to the new proxy's key */
		setAnonAuthorization(this);
	}
	assert(this->hostAddr!=0);
	assert(this->hostPort!=0);
	debugLog(10,"%x: trying next address: %s:%i\n",(unsigned int)this,inet_ntoa_l(this->hostAddr),ntohs(this->hostPort));
	return connectToAddress(this);
}

static void
freeSSLConnection(Connection *this)
{
	assert(this!=NULL);
	if(this->ssl!=NULL) {
		assert(this->sslBIO!=NULL);
		SSL_shutdown(this->ssl);
		SSL_free(this->ssl);
		this->ssl=NULL;
		this->sslBIO=NULL;
	}
}


SOCKETFD
connectToAddress(Connection *this)
{
	SOCKETFD webConn;
	struct sockaddr_in connectAddr;
	int r;

	assert(this!=NULL);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
	assert(this->flags&CONNECTION_DNS_DONE_PROCESSED);
	assert(!(this->flags&CONNECTION_READ_CACHE));
	assert(this->hostAddr!=0);

	if(isUseAnon(&this->server->anonProxy) 
	&& this->server->anonProxy.blockIntranet
	&& !isToProxy(this)
	) {
		if(((unsigned char *)&this->hostAddr)[0]==10
		||
	        (((unsigned char *)&this->hostAddr)[0]==192
		 && ((unsigned char *)&this->hostAddr)[1]==168
		)
		) {
			errorConnection(this,"Access to intranet IPs is blocked for anonymous proxy mode.");
			this->flags|=CONNECTION_CLOSE;
			return INVALID_SOCKETFD;
		}
	}

	if(this->hostAddr==this->server->localhost) {
		errorConnection(this,"Don't use proxy for localhost, use the .pac config instead of manual proxy.");
		this->flags|=CONNECTION_CLOSE;
		return INVALID_SOCKETFD;
	}

	debugLog(5,"connect to address:%x: %s:%i\n",(unsigned int)this,inet_ntoa_l(this->hostAddr),ntohs(this->hostPort));
	this->lastActivity=time(NULL);

#if USE_SSL
	freeSSLConnection(this);
#endif

#if USE_WEB_KEEP_ALIVE > 0
	if(this->hostAddr==this->connectedAddr
	&& this->hostPort==this->connectedPort) {
		/* already connected to the same host */
		debugLog(5,"%x: already connected to: %s:%i, won't reconnect\n",(unsigned int)this,inet_ntoa_l(this->hostAddr),ntohs(this->hostPort));
		return this->conn;
	} else if(this->connectedAddr>0) {
		assert(this->conn!=INVALID_SOCKETFD);
		debugLog(5,"%x: close previous connection to: %lx:%i, and reconnect to: %lx:%i\n",(unsigned int)this,ntohl(this->connectedAddr),ntohs(this->connectedPort),ntohl(this->hostAddr),ntohs(this->hostPort));
		closesocket(this->conn);
		this->conn=INVALID_SOCKETFD;
		this->connectedAddr=0;
		this->connectedPort=0;
	} else {
		assert(this->conn==INVALID_SOCKETFD);
	}
#endif

	/* connect to a new ip... */
	this->totalRecvLen=this->totalSentLen=this->totalResets=0;

	if(this->hostAddr!=0 && !isToProxy(this)) {
		struct in_addr inAddr;
		inAddr.s_addr=this->hostAddr;
		replaceStringCacheItem(&this->server->ipAddresses,this->parsedUrl.host,inet_ntoa(inAddr),0);
	}

	this->flags|=CONNECTION_SOCKET_CONNECTED;
	webConn=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	nonBlockSocket(webConn,1);
	memset(&connectAddr,0,sizeof(connectAddr));
	connectAddr.sin_family=AF_INET;
	connectAddr.sin_addr.s_addr=this->hostAddr;
	connectAddr.sin_port=this->hostPort;
	if(connectAddr.sin_addr.s_addr==this->server->localhost) {
		errorLog(this->server,"huh? localhost1: %s",this->parsedUrl.host);
	}
	r=connect(webConn,(struct sockaddr *)&connectAddr,sizeof(connectAddr));
	assert(r<0);  /* should return a not block error */
	this->connectedAddr=this->hostAddr;
	this->connectedPort=this->hostPort;
	this->conn=webConn;

	if(this->flags&CONNECTION_SOCKS && !isToProxy(this)) {
		assert(this->otherConnection!=NULL);
		sendSocksReply(this->otherConnection);
	}
#if USE_SSL
	if(isToProxy(this)) {
		BIO *bio;

		assert(this->server->sslCtx!=NULL);
		this->ssl=SSL_new(this->server->sslCtx);
		debugLog(20,"%x: connecting to proxy with SSL\n",(unsigned int)this);
		this->sslBIO=bio=BIO_new_socket(this->conn,0);
		SSL_set_connect_state(this->ssl);
		SSL_set_bio(this->ssl,bio,bio);
		BIO_set_nbio(bio,1);
		SSL_connect(this->ssl);
	}
#endif
	debugLog(25,"%x: new fd:%i to %s:%i\n",(unsigned int)this,this->conn,
		inet_ntoa_l(this->connectedAddr),ntohs(this->connectedPort));
	return webConn;
}






/*
 * We've received the header of the request from the browser.
 * Let's create a connection or get something from a file.
 */
static int
endOfHeader(Connection *this)
{
	assert(this!=NULL);
	debugLog(5,"end of header: %x\n",(unsigned int)this);

	/* get file from cache if we have it already */
	if(this->flags&CONNECTION_WEB_CONNECTION) {
		if(this->flags&CONNECTION_CHUNKED_ENCODING) {
			this->webContentLength=1;
		}
#if USE_PROXY_KEEP_ALIVE == 0
		appendWriteBufStatic(this->otherConnection,"Connection: close\r\n");
#endif
		if(this->webContentLength<0) {
		       if(this->status==304 || this->status==204 || (this->status>=100 && this->status<200)) {
				this->webContentLength=0;
			}
		} 
		if(this->status==304 && this->flags&CONNECTION_CACHE_MORE_RECENT_THAN_USER) {
			/* if 304 + cache is more recent, lets read from the cache */
			debugLog(10,"%x: 304 received, Grabbing from cache\n",(unsigned int)this);
			openReadCacheFile(this);
			return 0;
		} else if(this->webContentLength>0 && !(this->flags&(CONNECTION_WRITE_CACHE|CONNECTION_READ_CACHE))) {
			openWriteCacheFile(this);
		}
	} else if(this->otherConnection!=NULL && (this->flags&(CONNECTION_NO_READ_CACHE|CONNECTION_NO_EXPIRES))==0) {
		char nowStr[DATE_STR_LEN];
		FILE *in;
		Connection *otherConnection=this->otherConnection;

		/* grab from the cache if it's expires: has not been reached */
		timeToStr(nowStr,time(NULL));
		if((in=loadCacheFileInfo(otherConnection))!=NULL) {
			fclose(in);
			debugLog(10,"expires check:%x: %s, now:%s\n",(unsigned int)otherConnection,otherConnection->cacheFile.expires,nowStr);
			if(otherConnection->cacheFile.expires[0]!=0
			&& cmpDateStr(nowStr,otherConnection->cacheFile.expires)<0) {
				/* this cached file has not expired yet, 
				 * lets use it.
				 */
				debugLog(5,"use cache item, it has not expired: %s\n",this->url);
				otherConnection->flags|=CONNECTION_USING_UNEXPIRED;
				openReadCacheFile(otherConnection);
				return 0;
			}
		}
	}


	/* we've received the header from the users' connection 
	 * lets create the web connection if needed
	 */
	if(!(this->flags&CONNECTION_WEB_CONNECTION) && this->otherConnection!=NULL) {
		Connection *otherConnection=this->otherConnection;
		Access *accessAnon;
		struct in_addr hostAddrSt;

		if(
		strcmp(this->parsedUrl.host,"anon_proxy_server")==0
		) {
			this->otherConnection->flags|=CONNECTION_CLOSE;
			this->otherConnection->flags|=CONNECTION_CMD_INTERNAL;
			this->flags|=CONNECTION_CMD_INTERNAL;
			return internalCommand(this,this->parsedUrl.path);
		}
		if(!isStringBufEmpty(&this->writeBuf)) {
			debugLog(20,"%x: lets not create web connection, we've errored\n",(unsigned int)this);
			return 1;
		}

		if(!isConnectionAccessOk(this)) {
			this->otherConnection->flags|=CONNECTION_CLOSE;
			return 1; 
		}

		if(this->ifModified[0]==0) {
			checkIfModifiedWithCacheFile(this,NULL);
		}

		if(this->webContentLength<0) {
			/* default content-length to 0 if browser doesn't tell us */
			this->webContentLength=0;
		}

		/* we're reading from the local file cache */
		if(otherConnection->flags&CONNECTION_READ_CACHE) {
			clearStringBuf(&otherConnection->headerOutBuf);
			return 1;
		}

		if(isUseAnon(&this->server->anonProxy)
		&& !isProxyKeyOk(this)
		&& (accessAnon=matchConnectionAccess(this,TARGET_ANON))!=NULL
		) {
			int r;
			debugLog(20,"%x: use anon proxy ok...\n",(unsigned int)this);
			r=getProxyAddrs(otherConnection);
			if(r==-1) { return 0; }
			else if(r>0) {
				/* connect to other anon proxys */
				otherConnection->anonFlags|=CONNECTION_TO_PROXY;
				goto hostDone;
			}
		}

		/* do dns stuff... */
#ifdef _WIN32
		if((hostAddrSt.s_addr=inet_addr(this->parsedUrl.host))==INADDR_NONE) {
#else
		if(!inet_aton(this->parsedUrl.host,&hostAddrSt)) {
#endif
			StringCacheItem *item;

			/* grab dns from cache */
			if((item=findStringCacheItem(&this->server->ipAddresses,this->parsedUrl.host))!=NULL && item->lastCheck>=(time(NULL)-DNS_CACHE_SECS)) {
				debugLog(10,"grabbed dns from cache: %s -> %s\n",this->parsedUrl.host,item->val);

/*~~~ grab list of addresses? */
				otherConnection->hostAddr=inet_addr(item->val);
			} 
		} else {
			otherConnection->hostAddr=hostAddrSt.s_addr;
		}
hostDone:;

		if(otherConnection->hostAddr!=0) {
			/* lets just connect cause we have an ip */
			otherConnection->flags|=CONNECTION_DNS_DONE_PROCESSED;
			if(connectToAddress(otherConnection)==INVALID_SOCKETFD) {
				return 0;
			}
		} else {
			/* look up the ip from the dns */
			if(!createDnsThread(otherConnection)) {
				return 0;
			}
		}

#if USE_WEB_KEEP_ALIVE == 0
		appendStringBufStatic(&otherConnection->headerOutBuf,"Connection: close\r\n");
#endif

		assert(isStringBufEmpty(&this->writeBuf));
		/* send the first line of request...*/
		if(!(this->flags&CONNECTION_CMD_CONNECT)) {
			if(isToProxy(otherConnection)) {
				appendWriteBufVar(otherConnection,this->cmd);
				appendWriteBufStatic(otherConnection," ");
				appendWriteBufVar(otherConnection,this->url);
			} else {
				appendWriteBufVar(otherConnection,this->cmd);
				appendWriteBufStatic(otherConnection," ");
				appendWriteBufVar(otherConnection,this->parsedUrl.path);
				if(this->parsedUrl.query[0]!=0) {
					appendWriteBufStatic(otherConnection,"?");
					appendWriteBufVar(otherConnection,this->parsedUrl.query);
				}
			}
			appendWriteBufStatic(otherConnection," ");
			appendWriteBufVar(otherConnection,this->httpVers);
			appendWriteBufStatic(otherConnection,"\n");
		} else {
			assert(otherConnection->flags&CONNECTION_CMD_CONNECT);
			if(isToProxy(otherConnection)) {
				appendWriteBufVar(otherConnection,this->cmd);
				appendWriteBufStatic(otherConnection," ");
				appendWriteBufVar(otherConnection,this->url);
				appendWriteBufStatic(otherConnection," ");
				appendWriteBufVar(otherConnection,this->httpVers);
				appendWriteBufStatic(otherConnection,"\n");
			} else {
				otherConnection->headerLineUpto=-1;
				/* we won't need to send any headers, this is a direct CONNECT */
				clearStringBuf(&otherConnection->headerOutBuf);
				appendWriteBufStatic(this,"HTTP/1.0 200 Connection established\r\n\r\n");
			}
		}

		/* copy the headerOut buffer, if it's not a https connection */
		appendStringBufFromStringBuf(&otherConnection->writeBuf,&otherConnection->headerOutBuf);
		clearStringBuf(&otherConnection->headerOutBuf);

		/* any extra headers... */
		if(isToProxy(otherConnection)) {
			if(this->proxyConnection!=NULL) {
				appendWriteBufStatic(otherConnection,
					"Proxy-Connection:");
				appendWriteBufVar(otherConnection,this->proxyConnection);
				appendWriteBufStatic(otherConnection,"\n");
			}
			appendAnonAuthorization(otherConnection);
		}
	}
	return 1;
}

static int
checkBodyLen(Connection *this)
{
	assert(this!=NULL);

	if((this->flags&CONNECTION_WEB_CONNECTION) && this->webContentLength>=0 && this->recvBodyLen>=this->webContentLength) {
		debugLog(5,"all of body received: %x %s\n",(unsigned int)this,this->url);
		if(this->otherConnection!=NULL) {
			this->otherConnection->flags|=CONNECTION_BODY_RECEIVED;
		}
#if USE_WEB_KEEP_ALIVE == 0
		/* we've received all the data, lets close */
		if(this->recvBodyLen>this->webContentLength) {
			errorLog(this->server,"more contentlength than expected: %i>%i, %s\n",this->recvBodyLen,this->webContentLength,this->url);
		}
		closeConnection(this);
#else
#if 0
		if(this->flags&CONNECTION_CHUNKED_ENCODING) {
			/* no keep-alive for chunked encoding */
			this->flags|=CONNECTION_CLOSE;
		} else 
#endif
		{

			resetConnection(this,0);
		}
#endif
		return 0;
	}
	return 1;
}

static int
countChunkEncoding(Connection *this,char *recvPtr,int bufLen)
{
	char *p,*pend;

	assert(this!=NULL);
	assert(bufLen>=0);
	assert(recvPtr!=NULL);

	if(!(this->flags&CONNECTION_CHUNKED_ENCODING)) {
		return 1;
	}

	pend=recvPtr+bufLen;
	p=recvPtr;
	this->webContentLength+=bufLen;

	debugLog(25,"%x: recv/length... %i -> %i, chunktodo: %i\n",(unsigned int)this,this->recvBodyLen,this->webContentLength,this->currentChunkTodo);

	while(1) {
		char *cfrom;
		int found=0;

		p+=this->currentChunkTodo;
		if(p>=pend) {
			/* rest of this chunk is still to come */
			this->currentChunkTodo=p-pend;
			debugLog(25,"chunk left todo: %i\n",this->currentChunkTodo);
			break;
		}

		/* grab new chunk number */
		cfrom=p;
		while(cfrom<pend) {
			if(countStringBuf(&this->chunknum)>32) {
				errorLog(this->server,"chunk num too long: aborting: %s\nchunknum:%s\n",this->url,p);
				return 0;
			}
			if(*cfrom=='\n') {
				found=1;
				break; 
			}
			cfrom++;
		}
		appendStringBuf(&this->chunknum,p,cfrom-p);
		if(!found) { 
			/* still doing the chunk number */
			this->currentChunkTodo=0;
			break;
		}
		appendStringBuf(&this->chunknum,"",1);
		p=cfrom+3;

		this->currentChunkTodo=strtol(this->chunknum.buf,NULL,16);
		emptyStringBuf(&this->chunknum);

		debugLog(20,"%x: chunk received: %i,:%s:\n",(unsigned int)this,this->currentChunkTodo,this->chunknum.buf);
		if(this->currentChunkTodo==0) {
			/* all chunks received */
			this->webContentLength--;
			assert(this->webContentLength==this->recvBodyLen);
			return 1;
		}
	}
	return 1;
}


STATIC_INLINE int
isNoHeaderConnection(Connection *this)
{
	assert(this!=NULL);

	/* if it's a connect command directly to the web server
	 * not via a proxy then we don't send a header
	 */
	if(this->flags&CONNECTION_CMD_CONNECT 
	&& !isToProxy(this)
	&& this->flags&CONNECTION_WEB_CONNECTION) {
		return 1;
	}
	return 0;
}

#if 0
static int
isSSLWanting(Connection *this,int sslErr)
{
	assert(this!=NULL);

	if(sslErr==SSL_ERROR_WANT_READ
	|| sslErr==SSL_ERROR_WANT_WRITE) {
		/* we're still doing ssl stuff */
		return 1;
	}
	return 0;
}
#endif

int
readConnection(Connection *this)
{
	int bufLen;
	StringBuf line;
	StringBuf *recvBuf;
	char *recvPtr;
	int maxReadLen;
	OtherProxy *otherProxy;
	int r=1;

	assert(this!=NULL);
	this->lastActivity=time(NULL);
	debugLog(20,"readConnection:%x, fd:%i\n",(unsigned int)this,this->conn);

	if(this->flags&CONNECTION_WEB_CONNECTION
	&& this->flags&CONNECTION_SOCKS_BIND
	&& !(this->flags&CONNECTION_SOCKS_ACCEPTED)) {
		/* accept a socks bind */
		struct sockaddr_in acceptAddr;
		SOCKETFD newSock;
		socklen_t acceptAddrLen=sizeof(acceptAddr);
		char reply[]={5,0,0,1,0,0,0,0,0,0};

		newSock=accept(this->conn,(struct sockaddr *)&acceptAddr,&acceptAddrLen);
		assert(this->conn>0);
		pserver_close(this->conn);
		this->conn=newSock;
		memcpy(reply+8,&acceptAddr.sin_port,2);
		memcpy(reply+4,&acceptAddr.sin_addr.s_addr,4);
		debugLog(15,"socks accepted from: %s:%i\n",inet_ntoa(acceptAddr.sin_addr),ntohs(acceptAddr.sin_port));
		appendWriteBuf(this->otherConnection,reply,sizeof(reply));

		this->flags|=CONNECTION_SOCKS_ACCEPTED;
		return 1;
	}

	if(isHeaderDone(this) && this->otherConnection==NULL) {
		/* other connection was closed while we were doing the body, lets close too. */
		debugLog(15,"readConn:%x, other connection has been closed\n",(unsigned int)this);
		return 0;
	}
	recvBuf=this->headerLineUpto<0?&this->otherConnection->writeBuf:&this->currentLine;
	allocStringBuf(recvBuf,4000); /* init stringbuf if needed */

	recvPtr=recvBuf->buf+recvBuf->upto;
	maxReadLen=recvBuf->len-recvBuf->upto-1;
	if(this->flags&CONNECTION_READ_CACHE) {
		bufLen=read(this->conn,recvPtr,maxReadLen);
#if USE_SSL
	} else if(this->ssl!=NULL) {
		bufLen=SSL_read(this->ssl,recvPtr,maxReadLen);
		/* if we fill the full buf, 
		 * then there may be more stuff in the ssl bio
		 */
		if(bufLen==maxReadLen) {
			this->flags|=CONNECTION_READ_AGAIN;
		}
		if(bufLen<0) {
			int sslErr;
			if(BIO_should_retry(this->sslBIO)) {
				debugLog(30,"retry SSL read\n");
				return 1; 
			}
			sslErr=SSL_get_error(this->ssl,bufLen);
			errorLog(this->server,"problem reading ssl data: %s\n",ERR_error_string(sslErr,NULL));
			return 0;
		}
#endif
	} else {
		bufLen=recv(this->conn,recvPtr,maxReadLen,0);
	}
	if(bufLen<0) {
#ifdef _WIN32
		/* winsock hup error */
		if(WSAGetLastError()!=10054)
#endif
		errorLog(this->server,"problem reading: %i, %s\n",this->conn,sockErrorStr());
	}

	if(bufLen<=0) {
		if(isReconnectOk(this)
		&& connectToNextAddress(this)!=INVALID_SOCKETFD) {
			/* we have something to write and never got to write it, lets reconnect */
			debugLog(10,"%x: trying next proxy\n",(unsigned int)this);
			return 1;
		}
		debugLog(5,"%x: End of connection or error, closing\n",(unsigned int)this);
		return 0;
	}
	recvBuf->buf[recvBuf->upto+bufLen]=0;
#if DEBUGLVL >= 30
	debugLog(30,"%x: recv: ******\n",(unsigned int)this);
	fwrite(recvBuf->buf+recvBuf->upto,1,bufLen,stderr);
	debugLog(30,"\n******\n");
#endif

	if(this->recvLen==0 && (otherProxy=getCurrentOtherProxy(this))!=NULL) {
		/* we've received something so this proxy must be working */
		otherProxy->fails=0;
	}


#if CALC_STATS_ON_DOWNLOAD
	if(this->flags&CONNECTION_WEB_CONNECTION)
		updateConnServerStats(this,totalBytes+=bufLen);
#endif

	/* write to cache */
	writeStringBufSectionToCacheFile(this,recvBuf,recvBuf->upto,bufLen);

	recvBuf->upto+=bufLen;

	debugLog(15,"read:%x, len:%i\n",(unsigned int)this,bufLen);
	this->recvLen+=bufLen;
	if(isHeaderDone(this)) {
		/* just forward the body no need to process it... */
		this->recvBodyLen+=bufLen;

		if(!countChunkEncoding(this,recvPtr,bufLen)) {
			return 0;
		}
		checkWaitForZero(this);


		checkBodyLen(this);
		return 1;
	}

	/* process the header lines... */
	if(!isHeaderDone(this)) {
		int ch;
		ch=this->currentLine.buf[this->currentLine.readUpto];
		if(!(this->flags&CONNECTION_WEB_CONNECTION)
		&& ((this->headerLineUpto==0 && (ch==4 || ch==5 || ch==SOCKS_PROXY_VER)) || this->flags&CONNECTION_SOCKS)
		) {
			/* user connection, socks mode... */
			debugLog(10,"%x: Socks connection\n",(unsigned int)this);
			this->flags|=CONNECTION_SOCKS|CONNECTION_NO_READ_CACHE|CONNECTION_NO_WRITE_CACHE;
			while(!isHeaderDone(this) 
			&& !isStringBufEmpty(&this->currentLine)) {
				int r;
				if(!(r=processSocksUserHeader(this))) {
					return 0;
				}
				if(r==2) {break; }
			}
			return 1;
		}
	}

	memset(&line,0,sizeof(line));
	while(!isHeaderDone(this)) {
		char *linePtr;
		int emptyLine=0;

		clearStringBuf(&line);
		if(getLineFromStringBuf(&this->currentLine,&line)<0) {
			debugLog(30,"need to read more header to get a full line:%i\n",this->currentLine.upto-this->currentLine.readUpto);
			break;
		}
		linePtr=line.buf;
		if(line.upto==0 || line.buf[0]=='\r') {
			if(!endOfHeader(this)) { break; }

			emptyLine=1;
			linePtr=line.buf==NULL?"":line.buf;

			this->headerLineUpto=-1;
			if(this->otherConnection!=NULL) {
				int l;
				if(!isNoHeaderConnection(this->otherConnection)) {
					/* don't send header if it's a direct connection */
					appendWriteBufVar(this->otherConnection,linePtr);
					appendWriteBufStatic(this->otherConnection,"\n");
					if(this->flags&CONNECTION_WEB_CONNECTION && this->otherConnection!=NULL && this->anonFlags&CONNECTION_ANON_PROXY_MESSAGE) {
						sendBaseHref(this->otherConnection);
					}
				}
				l=this->currentLine.upto-this->currentLine.readUpto;
				appendWriteBuf(this->otherConnection,this->currentLine.buf+this->currentLine.readUpto,l);
				this->recvBodyLen+=l;
				countChunkEncoding(this,this->currentLine.buf+this->currentLine.readUpto,l);
				/* write the header to cache */
				writeStringBufToCacheFile(this,&this->otherConnection->writeBuf);

				checkBodyLen(this);
			}
			this->currentLine.upto=this->currentLine.readUpto=0;
		} else {
			if(this->flags&CONNECTION_WEB_CONNECTION) {
				if(!processWebHeaderLine(this,linePtr)) {
					r=0; break;
				}
			} else if(!processUserHeaderLine(this,linePtr)) {
				r=0; break;
			}
			this->headerLineUpto++;
		}
	}
	clearStringBuf(&line);

	return r;
}

void
closeMarkedConnection(Server *this,Connection *conn)
{
	assert(this!=NULL);
	assert(conn!=NULL);

	debugLog(6,"closeMarkedConnection: %x\n",(unsigned int)conn);
	if(conn->otherConnection==NULL
	&& !(conn->flags&CONNECTION_WEB_CONNECTION)
	&& (conn->flags&CONNECTION_PROXY_KEEP_ALIVE)) {
		/* keep-alive user's connection */
		resetConnection(conn,0);
		return;
	}
	closeConnection(conn);
}


int
writeConnection(Connection *this)
{
	char *ptr;
	int ptrLen;

	assert(this!=NULL);
	if(!isStringBufEmpty(&this->writeBuf)) {
		int len;

		ptr=this->writeBuf.buf+this->writeBuf.readUpto;
		ptrLen=this->writeBuf.upto-this->writeBuf.readUpto;

		debugLog(10,"%x: writeConn:(fd:%i), readUpto:%i,upto:%i,buf:%x(ch:%x),len:%i,\n",(unsigned int)this,this->conn,this->writeBuf.readUpto,this->writeBuf.upto,(unsigned int)this->writeBuf.buf,this->writeBuf.buf[this->writeBuf.readUpto],ptrLen);
#if DEBUGLVL >= 35
{
	debugLog(35,"writebuf...\n");
	fwrite(this->writeBuf.buf+this->writeBuf.readUpto,1,this->writeBuf.upto-this->writeBuf.readUpto,stderr);
	debugLog(35,"\n****\n");
}
#endif

#if USE_SSL
		if(this->ssl!=NULL) {
			len=SSL_write(this->ssl,ptr,ptrLen);
			if(len<0) {
				int sslErr;
				if(BIO_should_retry(this->sslBIO)) {
					debugLog(30,"retry SSL write\n");
					this->flags|=CONNECTION_RETRY_WRITE;
					return 1; 
				}
				sslErr=SSL_get_error(this->ssl,len);
				errorLog(this->server,"problem sending ssl data: %s\n",ERR_error_string(sslErr,NULL));
				return 0;
			}
			this->flags&=-1^CONNECTION_RETRY_WRITE;
		} else
#endif
		{
			len=send(this->conn,ptr,ptrLen,0);
		}
		if(len<0) {
			errorLog(this->server,"problem sending data: %s\n",sockErrorStr());
			return 0;
		}

		debugLog(15,"writeConn:%x, len written:%i, len wanted:%i\n",(unsigned int)this,len,ptrLen);
		this->sentLen+=len;
		this->writeBuf.readUpto+=len;
		this->lastActivity=time(NULL);
	}

	checkClose(this);
	return 1;
}

