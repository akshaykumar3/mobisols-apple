#ifndef __READCONFIG_H
#define __READCONFIG_H
	
int readConfigFile(Server *this);
int checkConfig(Server *this,time_t t);

#endif
