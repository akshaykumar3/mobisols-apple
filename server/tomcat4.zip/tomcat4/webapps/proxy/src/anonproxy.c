
#include "pserver.h"
#include "server.h"
#include "connection.h"
#include "geturl.h"
#include "connmessages.h"

int
isProxyOk(AnonProxy *this,OtherProxy *proxy)
{
	if(proxy->fails>=this->maxFails) {
		return 0;
	}
	/* Don't try to connect to ourself */
	if(isAnonKey(this,ntohl(proxy->key))) { return 0; }
	if(proxy->addr==this->server->localhost) { return 0; }
	if((this->publicAddress==proxy->addr && ntohs(this->listenPort)==proxy->port)
	) {
		return 0;
	}
	return 1;
}


static unsigned int
newAnonKey(AnonProxy *this)
{
	unsigned int key;
#ifdef _WIN32
	HCRYPTPROV cryptContext;
	int contextOk=1;

	assertAnonProxy(this);

	if(!CryptAcquireContext(&cryptContext,NULL,NULL,PROV_RSA_FULL,0)) {
		if(!CryptAcquireContext(&cryptContext,NULL,NULL,PROV_RSA_FULL,CRYPT_NEWKEYSET)) {
			errorLog(this->server,"cannot get crypt context:%i\n",GetLastError());
			contextOk=0;
		}
	}
	if(!contextOk 
	|| !CryptGenRandom(cryptContext,sizeof(key),(BYTE *)&key)
	) {
		struct timeb tv;
		unsigned int k;

		errorLog(this->server,"Failed to make random number, error::%i\n",GetLastError());
		ftime(&tv);
		k= (unsigned int)(((tv.time<<8)+tv.millitm)^this->anonKeys[0]);
		return k;
	}	
	CryptReleaseContext(cryptContext,0);
#else

	assertAnonProxy(this);

	key=rand();
#if RAND_MAX < 65536
	key|=rand()<<16;
#endif
#endif
	return key;
}

void
addAnonKey(AnonProxy *this)
{
	time_t t;
	unsigned int key;

	assert(this!=NULL);
	assertAnonProxy(this);

	t=time(NULL);
	if(t>=this->nextAnonKeyRotate) {
		key=newAnonKey(this);
		memmove(this->anonKeys+1,this->anonKeys,sizeof(this->anonKeys)-sizeof(this->anonKeys[0]));
		this->anonKeys[0]=key;
		this->nextAnonKeyRotate=t+(this->registerProxySecs);
	}
}


static const char *anonKeySaveFile="prevAnonKeys.lst";
void
readAnonKeys(AnonProxy *this)
{
	FILE *fd;
	unsigned int *keyPtr;

	assertAnonProxy(this);

	srand((unsigned int)time(NULL));
	if((fd=pserver_fopen(anonKeySaveFile,"rb"))!=NULL) {
		fread(&this->nextAnonKeyRotate,1,sizeof(this->nextAnonKeyRotate),fd);
	}
	for(keyPtr=this->anonKeys; keyPtr<(this->anonKeys+(sizeof(this->anonKeys)/sizeof(this->anonKeys[0]))); keyPtr++) {
		if(fd!=NULL) {
			fread(keyPtr,1,sizeof(keyPtr[0]),fd);
		} else {
			*keyPtr=newAnonKey(this);
		}
	}
	if(fd!=NULL) { fclose(fd); }
}

static void
writeAnonKeys(AnonProxy *this)
{
	FILE *fd;
	unsigned int *keyPtr;

	assertAnonProxy(this);

	if((fd=pserver_fopen(anonKeySaveFile,"wb"))==NULL) {
		errorLog(this->server,"Cannot open anonkeys file: %s, %s\n",anonKeySaveFile,pserver_strerror(errno));
		return;
	}
	fwrite(&this->nextAnonKeyRotate,1,sizeof(this->nextAnonKeyRotate),fd);
	for(keyPtr=this->anonKeys; keyPtr<(this->anonKeys+(sizeof(this->anonKeys)/sizeof(this->anonKeys[0]))); keyPtr++) {
		fwrite(keyPtr,1,sizeof(keyPtr[0]),fd);
	}
	fclose(fd);
}


/* anon proxy *********************************/

void
initAnonProxy(AnonProxy *this,Server *server)
{
	assert(this!=NULL);
	assert(server!=NULL);

	memset(&this->anonKeys,0,sizeof(this->anonKeys));
	this->timeout=15;
	this->maxFails=3;
	this->registerProxySecs=60*6;
	this->registerProxySecsFirstFew=30;
	this->registerProxyAttempted=0;
	this->registerProxyCompleted=0;
	this->server=server;
	this->otherProxys.proxys=pserver_malloc(PROXY_LIST_SIZE);
}

void
clearAnonProxy(AnonProxy *this)
{
	assertAnonProxy(this);

	FREE_PTR(this->otherProxys.proxys);
	FREE_PTR(this->homeBase);
}


struct RandIP {
	unsigned long addr;
	unsigned short port;
	OtherProxy *proxy;
	int randSort;
};

static int
cmpRandIP(const struct RandIP *ip1,const struct RandIP *ip2) 
{
	return ip1->randSort-ip2->randSort;
}



/* 
 * Connect via an anon proxy instead of normal address
 * Fill up connection->hostAddrs with a list of proxies
 * 0= fail no proxy
 * 1= ok using proxy
 * -1= fail, sent error message
 */
int
getProxyAddrs(Connection *this)
{
	OtherProxys *proxys;
	OtherProxy *proxy,*proxysStart;
	AnonProxy *anonProxy;
	time_t earliestRegisterTime;
	int upto=0;
	int stepRand;
	int totalUseableProxys;
#define toFill 5
	struct RandIP randIP[toFill];


	assert(this!=NULL);
	/* let's not assert connection is not setup yet, assertConnection(this);*/

	anonProxy=&this->server->anonProxy;
	proxys=&anonProxy->otherProxys;
	if(proxys->total==0) {
		if(anonProxy->failAbort) { 
			errorConnection(this,"Did not download any proxys from home proxy");
			this->flags|=CONNECTION_CLOSE;
			return -1;
		}
		return 0;
	}
	earliestRegisterTime=getEarliestProxyRegisterTime(anonProxy);
	assert(this->hostAddrs==NULL);

	this->hostAddrs=pserver_malloc(sizeof(this->hostAddrs[0])*toFill);
	totalUseableProxys=0;
	for(proxy=proxys->proxys+proxys->total-1; proxy>=proxys->proxys; proxy-- ) {
		if(proxy->registerTime<earliestRegisterTime) { 
			break;
		}
		if(!isProxyOk(anonProxy,proxy)) {
			continue; 
		}
		totalUseableProxys++;
	}

	upto=0;
	proxysStart=proxys->proxys;
	proxy=proxysStart+proxys->total-1; 
	if(proxy<proxysStart) { proxy=proxysStart; }

	/* If we have more proxys 
	 * available than we need then skip a few randomly 
	 */
	stepRand=totalUseableProxys/toFill;
	if(stepRand<1) { stepRand=1; }


	if(proxy<proxysStart) { proxy=proxysStart; }
	for(; upto<toFill; 
		proxy-=1+(rand()%stepRand) ) {

		if(proxy<proxysStart) {
			/* start from latest proxy again if we've reached the first proxy */
			proxy=proxysStart+proxys->total-
				(proxysStart-proxy);
		}

		debugLog(25,"key: %s:%i, fails:%i,key:%08x,time:%x > earliest:%x\n",inet_ntoa_l(proxy->addr),ntohs(proxy->port),proxy->fails,ntohl(proxy->key),proxy->registerTime,earliestRegisterTime);
		if(proxy->registerTime<earliestRegisterTime) { 
			/* key is too old */
			break;
		}
		if(!isProxyOk(anonProxy,proxy)) {
			continue; 
		}


		randIP[upto].addr=proxy->addr;
		randIP[upto].port=proxy->port;
		randIP[upto].proxy=proxy;
		randIP[upto].randSort=rand();
		
		upto++;
	}


	if(upto==0) {
		debugLog(5,"Whoops, not enough proxys downloaded? total:%i\n",proxys->total);
		if(anonProxy->failAbort) { 
			errorConnection(this,"No working anon proxys.<br />Must have 2 or more to use an anon proxy network<br /><a href=\"registerProxy.php\">Re-register proxy</a>");
			this->flags|=CONNECTION_CLOSE;
			return -1;
		}
		return 0;
	}
	this->hostAddrsTotal=upto;

	qsort(&randIP,this->hostAddrsTotal,sizeof(randIP[0]),
		(int(*)(const void *,const void *))cmpRandIP );

	for(upto=0; upto<this->hostAddrsTotal; upto++) {
		this->hostAddrs[upto].addr=randIP[upto].addr;
		this->hostAddrs[upto].port=randIP[upto].port;
		this->hostAddrs[upto].otherProxy=randIP[upto].proxy;
	}

	this->hostAddrsUpto=1;
	this->hostAddr=this->hostAddrs[0].addr;
	this->hostPort=this->hostAddrs[0].port;
	debugLog(10,"picked an anon proxy:%s:%i, key:%08x\n",
		inet_ntoa_l(this->hostAddr),ntohs(this->hostPort),
		ntohl(this->hostAddrs[0].otherProxy->key)
		);
	return 1;
}


/* clear all connection's proxy list */
static void
clearOtherProxyPtrs(AnonProxy *this)
{
	Connection *conn;

	assert(this!=NULL);
	assertAnonProxy(this);

	for(conn=this->server->firstConnection; conn!=NULL; conn=conn->nextConnection) {
		int i;
		if(conn->hostAddrsTotal==0 || conn->hostAddrs==NULL) { continue; }
		for(i=0; i<conn->hostAddrsTotal; i++) {
			conn->hostAddrs[i].otherProxy=NULL;
		}
	}
}


static int
countSameAddressProxys(OtherProxy *proxy,OtherProxy *proxyEnd,OtherProxy *sameProxy)
{
	int count=0;
	for(; proxy<proxyEnd; proxy++) {
		if(sameProxy->addr==proxy->addr && sameProxy->port==proxy->port) {
			count++;
		}
	}
	return count;
}

/* grab other proxys list */
static void
getOtherProxys(AnonProxy *this,char *newProxys,int len)
{
	OtherProxy *proxy,*proxyend;
	OtherProxys *otherProxys;

	assert(this!=NULL);
	assert(newProxys!=NULL);
	assert(len>=0);
	assertAnonProxy(this);

	/* proxy list has been read, lets use it */
	clearOtherProxyPtrs(this);
	otherProxys=&this->otherProxys;
	assert(otherProxys->proxys!=NULL);
	memcpy(otherProxys->proxys,newProxys,len>PROXY_LIST_SIZE?PROXY_LIST_SIZE:len);
	assert((len%sizeof(otherProxys->proxys[0]))==0);

	otherProxys->total=len/sizeof(otherProxys->proxys[0]);
	proxyend=otherProxys->proxys+otherProxys->total;
	for(proxy=otherProxys->proxys; proxy<proxyend; proxy++) {
		proxy->registerTime=ntohl(proxy->registerTime);

	}

	/* the proxy list is sorted oldest to newest */
	/* Only use the latest key from each proxy */
	for(proxy=proxyend-1; proxy>otherProxys->proxys; proxy--) {
		if(countSameAddressProxys(proxy+1,proxyend,proxy)>=1) {
			proxy->registerTime=0;
		}
	}

	debugLog(5,"total proxys read: %i,latest:%x\n",
		otherProxys->total,
		otherProxys->total>0?proxyend[-1].registerTime:0
		);
}


static int
registerProxyConnect(AnonProxy *this,const char *urlBase)
{
	char *p,*bufend,*buf;
	int headerLen;
	unsigned int proxyListLen;
	char url[MAX_URL_LEN];
	GetUrl getUrl;
	int r=1;

	assert(this!=NULL);
	assert(urlBase!=NULL);
	assertAnonProxy(this);

	debugLog(15,"trying new key:%08x,oldkey:%08x time:%08x\n",this->anonKeys[0],this->anonKeys[1],time(NULL));
	snprintf(url,sizeof(url),"%s/anon.php?port=%i&key=%08x",
		urlBase,
#if USE_SSL
		this->listenPort,
#else
		this->server->listenPort,
#endif
		this->anonKeys[0]);

	if(getUrlNew(&getUrl,this->server,url)
	&& getUrlAll(&getUrl)
	) {

		buf=getUrl.in.buf+getUrl.in.readUpto;
		bufend=getUrl.in.buf+getUrl.in.upto;
		p=buf;

		headerLen=ntohl(((int *)p)[0]);
		p+=4;
		this->timeDiff=(int)(time(NULL)-ntohl(((int *)p)[0]));
		memcpy(&this->publicAddress,p+4,sizeof(this->publicAddress));
		memcpy(&proxyListLen,p+8,sizeof(proxyListLen));
		proxyListLen=ntohl(proxyListLen);
		p+=headerLen;

		if(bufend<=p) {
			debugLog(25,"no anon proxys retreived from home proxy: headerlen:%i, buftotal:%i, buf:\n",headerLen,bufend-buf);
#if DEBUGLVL>=25
			fwrite(buf,1,bufend-buf,stderr);
#endif
			r=0;
		} else {
			getOtherProxys(this,p,bufend-p);
		}
		debugLog(5,"Registered new key:%08x time:%08x, public address:%x\n",this->anonKeys[0],time(NULL),this->publicAddress);
	}

	getUrlClose(&getUrl);
	getUrlClear(&getUrl);
	return r;
}


static int
registerProxyHomeBase(AnonProxy *this,char *homeBase)
{
	char homeBaseUrl[MAX_URL_LEN];
	int r=1;

	assert(homeBase!=NULL);
	assertAnonProxy(this);

	qstrncpy(homeBaseUrl,homeBase,MAX_URL_LEN);

	debugLog(5,"Registering proxy via:%s\n",homeBaseUrl);
	if(!(r=registerProxyConnect(this,homeBaseUrl))) {
		this->registeredOk=0;
	} else {
		writeAnonKeys(this);
		this->registeredOk=1;
	}
	return r;
}

/* register ourselves */
static int
registerProxyThread1(AnonProxy *this)
{
	FILE *homeBaseFd;
	char homeBase[1024];
	char homeBaseFile[FILENAME_MAX];
	int total=0;
	int r=1;

	assert(this!=NULL);
	assertAnonProxy(this);

	if(this->homeBase!=NULL && this->homeBase[0]!=0) {
		/* user has manually selected a home base */
		return registerProxyHomeBase(this,this->homeBase);
	}

	/* Pick a home base from the list in the file... */
	snprintf(homeBaseFile,sizeof(homeBaseFile),"%s/homebase.lst",this->server->baseDir);
	if((homeBaseFd=pserver_fopen(homeBaseFile,"rb"))==NULL) {
		errorLog(this->server,"Cannot open home base file: %s,%s\n",homeBaseFile,pserver_strerror(errno));
		return 0;
	}
	while(fgets(homeBase,sizeof(homeBase),homeBaseFd)!=NULL) {
		char *lf;

		if((lf=strchr(homeBase,'\n'))!=NULL) { *lf=0; }
		if(homeBase[0]=='#' || homeBase[0]==0) { continue; }
		total++;
		r=registerProxyHomeBase(this,homeBase);
		if(r) { break; }
	}
	fclose(homeBaseFd);
	this->registerProxyCompleted++;
	if(total==0) {
		errorLog(this->server,"No urls in the homebase file!\n");
		return 0;
	}
	return r;
}



void
registerProxyThread(AnonProxy *this)
{
	unsigned int oldKeys[MAX_ANON_KEYS];
	time_t nextRotate;
	int count=0;
	int ok=0;

	assertAnonProxy(this);

	nextRotate=this->nextAnonKeyRotate;
	memcpy(oldKeys,this->anonKeys,sizeof(oldKeys));
	addAnonKey(this);
	while(count++<3) {
		if(registerProxyThread1(this)) { ok=1; break; }
		Sleep(30000);
	}
	if(!ok) {
		/* restore anon keys, proxy update failed */
		this->nextAnonKeyRotate=nextRotate;
		memcpy(this->anonKeys,oldKeys,sizeof(oldKeys));
	}
	this->registerProxyRunning=0;
#ifdef _WIN32
	_endthread();
	/* CloseHandle((HANDLE)this->registerProxyThread); */
#endif
}

static void
getAnonAuthString(Connection *this,char *keyhex,int *len)
{
	OtherProxy *otherProxy;
	assertConnection(this);
	assert(keyhex!=NULL);
	assert(len!=NULL);

	if((otherProxy=getCurrentOtherProxy(this))!=NULL) {
		*len=snprintf(keyhex,KEYHEX_LEN,"Anon-Proxy-Authorization: %08x\r\n",(unsigned int)ntohl(otherProxy->key));
	} else {
		errorLog(this->server,"getAnonAuthString: No other anon proxys available.\n");
	}
}

void
appendAnonAuthorization(Connection *this)
{
	char keyhex[KEYHEX_LEN];
	int len;

	assert(this!=NULL);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
	assertConnection(this);

	getAnonAuthString(this,keyhex,&len);
	debugLog(25,"append anon auth string using key: %x,%x\n",keyhex,this->writeBuf.upto);
	this->anonProxyAuthStrUpto=this->writeBuf.upto;
	appendWriteBuf(this,keyhex,len);
}

void
setAnonAuthorization(Connection *this)
{
	char keyhex[KEYHEX_LEN];
	int len;
	char *ptr;

	assert(this!=NULL);
	assert(this->sentLen==0);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
/* ~~~ BUG: here, why does it try to set the AnonAuthorization here? */
	if(this->anonProxyAuthStrUpto<=0) {
		errorLog(this->server,"anonProxyAuthStr fail: conn:%x, fd:%i, flags:%x\n",this,this->conn,this->flags);
		return;
	}
	assert(this->anonProxyAuthStrUpto>0);
	assert(this->anonProxyAuthStrUpto<this->writeBuf.upto);

	ptr=this->writeBuf.buf+this->anonProxyAuthStrUpto;
	if(this->flags&CONNECTION_SOCKS) {
		OtherProxy *otherProxy;
		if((otherProxy=getCurrentOtherProxy(this))==NULL) {
			errorLog(this->server,"setAnonAuthorization: No other anon proxys available.\n");
		} else {
			memcpy(ptr,&otherProxy->key,4);
		}
	}
	else {
		getAnonAuthString(this,keyhex,&len);
		strncpy(ptr,keyhex,len);
	}
}

void
registerProxyStart(AnonProxy *this)
{
	assertAnonProxy(this);
	
	if(++this->registerProxyAttempted>6) {
		this->nextRegisterProxy=time(NULL)+this->registerProxySecs;
	} else {
		this->nextRegisterProxy=time(NULL)+this->registerProxySecsFirstFew;
	}

	if(this->registerProxyRunning) {
		errorLog(this->server,"Previous registerProxy has taken too long, cancelling. failed %i times\n",this->registerProxyRunning);
#ifndef _WIN32
		if(pthread_cancel(this->registerProxyThread)==0) {
			errorLog(this->server,"Could not cancel thread: %s",pserver_strerror(errno));
		}
#else
		if(TerminateThread((HANDLE)this->registerProxyThread,1)==0) {
			errorLog(this->server,"Could not cancel thread: winerror:%i",GetLastError());
		}
#endif
		this->registerProxyRunning=0;
	}

	this->registerProxyRunning++;

	if(pthread_create(&this->registerProxyThread,NULL,(void *(*)(void *))&registerProxyThread,this)!=0) {
		errorLog(this->server,"Could not create thread: %s",pserver_strerror(errno));
	}
#ifndef _WIN32
	if(this->registerProxyThread!=0) {
		pthread_detach(this->registerProxyThread);
		this->registerProxyThread=0;
	}
#endif
}


void
checkAnonKeys(AnonProxy *this,time_t t)
{
	assertAnonProxy(this);

	if(isUseAnon(this)) {
		if(this->nextRegisterProxy<=t) {
			registerProxyStart(this);
		}
	} else {
		/* rotate the key anyways so we don't stay on the same key forever */
		addAnonKey(this); 
	}
}

OtherProxy *
getCurrentOtherProxy(Connection *this) 
{
	assert(this!=NULL);
	if(this->hostAddrsUpto<=0) { return NULL; }
	return this->hostAddrs[this->hostAddrsUpto-1].otherProxy;
}

time_t
getEarliestProxyRegisterTime(AnonProxy *this)
{
	/* if we grabbed the proxy list 6mins ago, 
	 * then we'll  have a list of proxys 6-12mins old.
	 */
	/* it could take an extra 30 secs to retreive the list of anon proxys */

	assertAnonProxy(this);

	return time(NULL)-30-((this->registerProxySecs)*3)-this->timeDiff;
}


#ifndef NDEBUG

void
assertOtherProxy(OtherProxy *this)
{
	assert(this!=NULL);
	assert(this->addr!=0);
	assert(this->port!=0);
	assert(this->key!=0);
}

void
assertOtherProxys(OtherProxys *this)
{
	int i;

	assert(this!=NULL);
	if(this->total>0) {
		assert(this->proxys!=NULL);
		for(i=0; i<this->total; i++) {
			assertOtherProxy(this->proxys+i);
		}
	}
}

void
assertAnonProxy(AnonProxy *this)
{
	assert(this!=NULL);
	assert(this->server!=NULL);
	if(this->useAnon) {
		assert(this->homeBase!=NULL);
		assert(this->listenPort>0);
		/* check that the next time we register the proxy isn't too far away */
		if(this->nextRegisterProxy!=0)
			assert((this->nextRegisterProxy-this->registerProxySecs)<=time(NULL));
		if(this->nextAnonKeyRotate!=0)
			assert((this->nextAnonKeyRotate-this->registerProxySecs)<=time(NULL));
	}
}

#endif

