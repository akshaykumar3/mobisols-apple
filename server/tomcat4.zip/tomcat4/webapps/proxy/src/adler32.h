#ifndef __ADLER32_H
#define __ADLER32_H

unsigned long adler32(unsigned long adler, const char *buf, unsigned int len);

#endif
