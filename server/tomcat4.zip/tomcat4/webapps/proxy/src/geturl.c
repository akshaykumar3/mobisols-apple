
#include "pserver.h"
#include "geturl.h"
#include "server.h"




int
getUrlRead(GetUrl *this)
{
	int len;

	assert(this!=NULL);

	allocStringBuf(&this->in,4096);
	assert(this->in.upto<this->in.len);

	if(this->ssl!=NULL) {
		len=SSL_read(this->ssl,this->in.buf+this->in.upto,this->in.len-this->in.upto);
	} else {
		len=recv(this->fd,this->in.buf+this->in.upto,this->in.len-this->in.upto,0);
	}
	if(len<0) { 
		return -1; 
	}
	this->in.upto+=len;
	return len;
}

int
getUrlWrite(GetUrl *this)
{
	int len;

	assert(this!=NULL);
	if(this->out.readUpto==this->out.upto) {
		return 0;
	}

	if(this->ssl!=NULL) {
		len=SSL_write(this->ssl,this->out.buf+this->out.readUpto,
			this->out.upto-this->out.readUpto);
	} else {
		len=send(this->fd,this->out.buf+this->out.readUpto,
			this->out.upto-this->out.readUpto,0);
	}
	if(len<0) {
		return -1;
	}
	this->out.readUpto+=len;
	return len;
}

void
getUrlClear(GetUrl *this) 
{
	assert(this!=NULL);

	getUrlClose(this);
	clearUrl(&this->url);
	clearStringBuf(&this->in);
	clearStringBuf(&this->out);
}

void
getUrlClose(GetUrl *this) 
{
	assert(this!=NULL);

	if(this->ssl!=NULL) {
		SSL_shutdown(this->ssl);
		SSL_free(this->ssl);
		this->ssl=NULL;
		this->sslBIO=NULL;
	}
	if(this->fd!=INVALID_SOCKETFD) {
		closesocket(this->fd);
		this->fd=INVALID_SOCKETFD;
	}
}

int
getUrlNew(GetUrl *this,struct Server *server,char *urlStr)
{
	struct sockaddr_in connectAddr;
	struct hostent *hostEntry;
	int buflen;
	char buf[MAX_URL_LEN];

	assert(this!=NULL);
	assert(server!=NULL);
	assert(urlStr!=NULL);

	memset(this,0,sizeof(this[0]));
	this->server=server;
	if(!parse_url(&this->url,urlStr)) {
		errorLog(this->server,"bad url: %s\n",urlStr);
		return 0;
	}

	memset(&connectAddr,0,sizeof(connectAddr));
	connectAddr.sin_family=AF_INET;
	connectAddr.sin_port=htons(getUrlConnectPort(&this->url));

	this->fd=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);

	if((connectAddr.sin_addr.s_addr=inet_addr(this->url.host))==-1) {
		if((hostEntry=gethostbyname(this->url.host))==NULL) {
			errorLog(this->server,"problem getting dns name for home base:%s\n",this->url.host);
			return 0;
		} else {
			connectAddr.sin_addr.s_addr=((struct in_addr *)hostEntry->h_addr_list[0])->s_addr;
		}
	}

	if(this->fd==INVALID_SOCKETFD || connect(this->fd,(struct sockaddr *)&connectAddr,sizeof(connectAddr))<0) {
		errorLog(this->server,"problem connecting to url, %s,  %s\n",this->url,sockErrorStr());
		return 0;
	}

	if(strcmp(this->url.scheme,"https")==0) {
		this->ssl=SSL_new(this->server->sslCtx);

		this->sslBIO=BIO_new_socket(this->fd,0);
		SSL_set_connect_state(this->ssl);
		SSL_set_bio(this->ssl,this->sslBIO,this->sslBIO);
		BIO_set_nbio(this->sslBIO,1);
		SSL_connect(this->ssl);
	}

	buflen=snprintf(buf,sizeof(buf),"GET %s%s%s HTTP/1.0\r\nHost: %s",
		this->url.path,
		this->url.query[0]!=0?"?":"",
		this->url.query,
		this->url.host
		);
	appendStringBuf(&this->out,buf,buflen);
	if(this->url.port!=0) {
		buflen=snprintf(buf,sizeof(buf),":%i",this->url.port);
	}
	appendStringBuf(&this->out,buf,buflen);
	appendStringBufStatic(&this->out,"\r\nConnection: close\r\n\r\n");
	return 1;
}

int
getUrlAll(GetUrl *this)
{
	int lf;
	char *p,*bufend;

	assert(this!=NULL);

	while(getUrlWrite(this)>0) { }

	/* read the header */
	while(getUrlRead(this)>0) { }
	bufend=this->in.buf+this->in.upto;
	p=this->in.buf+this->in.readUpto;
	while(p<bufend && !isspace(*p) && *p) p++;
	while(p<bufend && isspace(*p)) p++;
	if(atoi(p)!=200) {
		char *lfPtr;
		if((lfPtr=strchr(p,'\n'))!=NULL) { *lfPtr=0; }
		bufend[0]=0;
		errorLog(this->server,"bad return from url:%s\n",p);
		if(lfPtr!=NULL) { *lfPtr='\n'; }
#if DEBUGLVL >=25
		debugLog(25,"bad return from url: %s\n",p);
		fwrite(p,1,this->in.readUpto+this->in.upto,stderr);
#endif
		return 0;
	}

	/* find end of header */
	p=this->in.buf+this->in.readUpto;
	lf=0;
	while(p<bufend) {
		if(*p=='\n') {
			if(++lf>=2) { p++; break; }
		}
		else if(*p!='\r') {
			lf=0;
		}
		p++;
	}
	this->in.readUpto=p-this->in.buf;
	assert(this->in.readUpto<=this->in.upto);

	return 1;
}


