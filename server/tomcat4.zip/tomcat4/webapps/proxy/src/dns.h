#ifndef __DNS_H
#define __DNS_H

typedef struct DnsLookup {
	struct Connection *connection;
	struct Server *server;
	char *hostToLookup;
	int portToLookup;
}DnsLookup;
	
void disconnectDnsLookup(struct Connection *this);
int finishDnsThread(struct Connection *this);
int createDnsThread(struct Connection *this);


#endif
