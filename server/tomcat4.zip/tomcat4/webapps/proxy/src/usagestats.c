
#include "pserver.h"
#include "server.h"
#include "connection.h"
#include "usagestats.h"

void
sendUsageStatsArray(Connection *this,
	UsageStats *usages,int total,const char *name,
	const char *totalName)
{
	char namePref[256];
	char line[1024];
	char *l;
	int c;

	assert(this!=NULL);
	assert(usages!=NULL);
	assert(name!=NULL);
	assert(totalName!=NULL);

#define sendUsageStats1Line(n,val) \
	l=line+snprintf(line,sizeof(line),"%s,%s,",name,n); \
	for(c=0; c<total;c++) { l+=snprintf(l,line+sizeof(line)-l,PRINTF_LONG_LONG,usages[c].val); if((c+1)<total) *l++=','; } \
	*l++='\n'; *l=0; appendWriteBufVar(this,line);


	snprintf(namePref,sizeof(namePref),"%s bytes",totalName);
	sendUsageStats1Line(namePref,totalBytes);
	snprintf(namePref,sizeof(namePref),"%s requests",totalName);
	sendUsageStats1Line(namePref,totalRequests);
}


void
calcServerStatsHour(ServerStats *this,time_t t)
{
	struct tm tmHour;

	assert(this!=NULL);

	pserver_localtime(&this->currentHour,&t);
	assert(this->currentHour.tm_hour<24);
	assert(this->currentHour.tm_wday<7);

	/* round off to the hour */
	memcpy(&tmHour,&this->currentHour,sizeof(tmHour));
	tmHour.tm_min=0;
	tmHour.tm_sec=0;
	this->currentHourEnd=mktime(&tmHour)+(60*30);
}


void
calcConnectionStats(Server *this,Connection *conn)
{
	assert(this!=NULL);
#if !CALC_STATS_ON_DOWNLOAD
	if(conn->flags&CONNECTION_WEB_CONNECTION)
		updateConnServerStats(conn,totalBytes+=conn->recvLen);
#endif
}


void
writeServerStats(ServerStats *this,FILE *fd)
{
	long size=htonl(sizeof(this[0]));
	assert(this!=NULL);
	assert(fd!=NULL);
	fwrite(&size,1,4,fd);
	fwrite(this,1,sizeof(this[0]),fd);
}

void
readServerStats(ServerStats *this,FILE *fd)
{
	long size;

	assert(this!=NULL);
	assert(fd!=NULL);

	fread(&size,1,4,fd);
	size=ntohl(size);
	if(size==sizeof(this[0])) {
		/* compatible structure */
		ServerStats temp;
		memcpy(&temp,this,sizeof(temp));

		fread(this,1,sizeof(this[0]),fd);

		memcpy(&this->startTime,&temp.startTime,
			sizeof(this[0])-(((char *)&temp.startTime)-(char *)&temp));
	}
}


#ifndef NDEBUG

void
addUsageStats(UsageStats *dest,const UsageStats *from)
{
	dest->totalRequests+=from->totalRequests;
	dest->totalBytes+=from->totalBytes;
}

void
assertServerStats(ServerStats *this)
{
	int c=0;
	UsageStats totalHours;
	UsageStats totalDow;

	memset(&totalHours,0,sizeof(totalHours));
	memset(&totalDow,0,sizeof(totalDow));
	for(c=0; c<24; c++) {
		addUsageStats(&totalHours,&this->hours[c]);
	}
	for(c=0; c<7; c++) {
		addUsageStats(&totalDow,&this->dayOfWeek[c]);
	}
	assert(totalHours.totalRequests==this->total.totalRequests);
	assert(totalHours.totalBytes==this->total.totalBytes);
}

#endif


