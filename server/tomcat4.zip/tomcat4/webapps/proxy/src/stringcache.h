#ifndef __STRINGCACHE_H
#define __STRINGCACHE_H

typedef struct StringCacheItem {
	time_t lastCheck;
	char *key,*val;
	struct StringCacheItem *prev,*next;
}StringCacheItem;

typedef struct StringCacheBucket {
	StringCacheItem *firstItem;
	int totalItems;
}StringCacheBucket;

#define STRINGCACHE_ITEMS 128
typedef struct StringCache {
	StringCacheBucket items[STRINGCACHE_ITEMS];
	int totalItems;
}StringCache;

void initStringCache(StringCache *this);
StringCacheItem *replaceStringCacheItem(StringCache *this,
		const char *key,const char *val,
		int updateLastCheck);
StringCacheItem *findStringCacheItem(StringCache *this,const char *key);
void removeStringCacheItem(StringCache *this,StringCacheItem *item);
void clearStringCache(StringCache *this);
StringCacheItem *newStringCacheItem(StringCache *this,const char *key,const char *val);

#ifndef NDEBUG
void assertStringCache(StringCache *this);
#else
#define assertStringCache(x)
#endif


#endif
