
#include "pserver.h"
#include "server.h"
#include "connection.h"
#include "dns.h"
#include "access.h"

static SOCKETFD
bindToPort(Connection *this)
{
	SOCKETFD conn;
	struct sockaddr_in listenAddr;

	assert(this!=NULL);
	assert(this->flags&CONNECTION_WEB_CONNECTION);
	assert(this->flags&CONNECTION_SOCKS_BIND);
	assert(this->conn==INVALID_SOCKETFD);

	debugLog(5,"binding to port: %i\n",ntohs(this->hostPort));
	conn=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	memset(&listenAddr,0,sizeof(listenAddr));
	listenAddr.sin_family=AF_INET;
	listenAddr.sin_port=this->hostPort;
	if(conn==INVALID_SOCKETFD || bind(conn,(struct sockaddr *)&listenAddr,sizeof(listenAddr))<0) {
		errorLog(this->server,"Cannot bind to %i: %s\n",ntohs(this->hostPort),sockErrorStr());
		return 0;
	}
	this->conn=conn;
	return 1;
}

void
sendSocksReply(Connection *this)
{
	char reply5[]={5,0,0,1,0,0,0,0,0,0};
	char reply4[]={0,90,0,0,0,0,0,0};
	struct sockaddr_in sockName;
	socklen_t sockNameLen;

	assert(this!=NULL);
	assert(this->otherConnection!=NULL);
	assert(!(this->flags&CONNECTION_WEB_CONNECTION));
	assert(this->flags&CONNECTION_SOCKS);
	assert(this->otherConnection->conn!=INVALID_SOCKETFD);

	/* send socks reply */
	sockNameLen=sizeof(sockName);
	getsockname(this->otherConnection->conn,(struct sockaddr *)&sockName,&sockNameLen);
	if(this->flags&CONNECTION_SOCKS_VER4) {
		memcpy(reply4+2,&sockName.sin_port,2);
		memcpy(reply4+4,&sockName.sin_addr.s_addr,4);
		appendWriteBuf(this,reply4,sizeof(reply4));
	} else {
		memcpy(reply5+8,&sockName.sin_port,2);
		memcpy(reply5+4,&sockName.sin_addr.s_addr,4);
		appendWriteBuf(this,reply5,sizeof(reply5));
	}
	debugLog(15,"socks reply: %s:%i\n",inet_ntoa(sockName.sin_addr),ntohs(sockName.sin_port));
}

static int
getSocksStr(StringBuf *this,char *dest, int destLen)
{
	unsigned char len;

	assert(this!=NULL);
	assert(dest!=NULL);
	assert(destLen>0);

	destLen--;
	len=this->buf[this->readUpto];
	if(len>=(this->upto-this->readUpto)) {
		return 0;
	}
	if(len>=destLen) { len=destLen; }
	memcpy(dest,this->buf+this->readUpto+1,len);
	dest[len]=0;
	this->readUpto+=len+1;
	return 1;
}



int
processSocksUserHeader(Connection *this)
{
	char *buf,*bufend;

	assert(this!=NULL);
	assert(this->currentLine.readUpto==0);

	buf=this->currentLine.buf+this->currentLine.readUpto;
	bufend=this->currentLine.buf+this->currentLine.upto;

	/* headerLineUpto: 
	 * 0=method neg
	 * 1=request
	 * -1=data
	 */
	switch(this->headerLineUpto) {
	case 0:
	{
		Connection *otherConnection;
		char *p;
		char ver;

		assert(this->otherConnection==NULL);

		ver=buf[0];
		if(ver==SOCKS_PROXY_VER) {
			AnonProxy *anonProxy;
			/* from a another proxy, check the key */
			unsigned int key;
			memcpy(&key,buf+1,4);
			anonProxy=&this->server->anonProxy;
			if(!isUseAnon(anonProxy)
			|| !isAnonKey(anonProxy,ntohl(key))) {
				errorLog(this->server,"Bad key number:%s, key:%08x!=%08x/%08x",inet_ntoa_l(this->userAddr),key,anonProxy->anonKeys[0],anonProxy->anonKeys[1]);
				return 0;
			}
			this->anonFlags|=CONNECTION_PROXY_KEY_OK;
		}
		if(ver==4) {
			if((bufend-buf)<8) {
				debugLog(20,"%x: the whole socks header has not been read yet\n",(unsigned int)this);
				return 2; 
			}

			p=buf+8;
			while(1) {
				/* if we haven't received the full packet lets
				 * return
				 */ 
				if(p>=bufend) {
					debugLog(20,"%x: the socks4 string header has not been read yet, maybe its in the next packet\n",(unsigned int)this);
					this->flags|=CONNECTION_SOCKS_WAIT_FOR_ZERO;
					break;
				}
				if(*p==0) {break; }
				p++; 
			}
		}


		otherConnection=getNewConnection(this->server,this);
		otherConnection->flags|=CONNECTION_SOCKS
			|(this->flags&(CONNECTION_SOCKS_VER4));
		otherConnection->anonFlags|=this->flags&CONNECTION_PROXY_KEY_OK;
		this->otherConnection=otherConnection;
/*~~~ ask for user/pass? */
		this->headerLineUpto++;
		if(ver==5) {
			const char methodReply[]={5,0};
			this->currentLine.readUpto+=buf[1]+2;
			appendWriteBuf(this,methodReply,sizeof(methodReply));
			break;
		}
		if(isProxyKeyOk(this)) {
			/* this is from another proxy lets continue on... */
			this->currentLine.readUpto+=buf[5]+6;
			buf=this->currentLine.buf+this->currentLine.readUpto;
		}
	}
	case 1:
	{
		/* request packet */
		char host[1024];
		char url[1024];
		int ver;
		unsigned long addr=0;
		unsigned short port=0;
		int isHostName=0;

		assert(this->otherConnection!=NULL);

		ver=buf[0];
		if(ver==4) {
			/* socks4 */
			char *p;

			memcpy(&port,buf+2,2);
			memcpy(&addr,buf+4,4);
			qstrncpy(host,inet_ntoa_l(addr),sizeof(host));
			p=strchr(buf+8,0);
			this->currentLine.readUpto+=(p-buf)+1;
			this->flags|=CONNECTION_SOCKS_VER4;
		} else {
			if(buf[3]==3) {
				/* host name, needs lookup */
				this->currentLine.readUpto+=4;
				getSocksStr(&this->currentLine,host,sizeof(host));
				isHostName=1;
			} else {
				memcpy(&addr,buf+4,4);
				qstrncpy(host,inet_ntoa_l(addr),sizeof(host));
				this->currentLine.readUpto+=8;
			}

			memcpy(&port,this->currentLine.buf+this->currentLine.readUpto,2);
		}

		this->otherConnection->hostAddr=addr;
		this->otherConnection->hostPort=port;

		assert(this->parsedUrl.host==NULL);
		assert(this->otherConnection->parsedUrl.host==NULL);
		assert(this->otherConnection->url==NULL);
		assert(this->url==NULL);
		snprintf(url,sizeof(url),"socks://%s:%i",host,ntohs(port));
		this->url=strdup(url);
		this->otherConnection->url=strdup(url);

		parse_url(&this->otherConnection->parsedUrl,url);
		qstrncpy(url,this->url,sizeof(url));
		parse_url(&this->parsedUrl,url);

		if(this->parsedUrl.port==0) {
			errorLog(this->server,"socks has port number of 0, let's close the connection: %s:%i\n",host,ntohs(this->otherConnection->hostPort));

			this->flags|=CONNECTION_CLOSE;
			return 0;
		}
		assert(this->parsedUrl.port!=0);
		assert(this->parsedUrl.scheme!=NULL);

		this->headerLineUpto=-1;
		this->otherConnection->headerLineUpto=-1;

		debugLog(20,"socks addr: %s:%i\n",host,ntohs(this->otherConnection->hostPort));

		/* check acccess */
		if(!isConnectionAccessOk(this)) {
			this->flags|=CONNECTION_CLOSE;
			return 0;
		}

		switch(buf[1]) {
		case 1:
			this->flags|=CONNECTION_SOCKS_CONNECT;
			debugLog(10,"%x: socks connect\n",(unsigned int)this);

			if(isUseAnon(&this->server->anonProxy)
			&& !isProxyKeyOk(this)
			&& getProxyAddrs(this->otherConnection)>0
			) {
				/* to another proxy??? */
				this->otherConnection->anonFlags|=CONNECTION_TO_PROXY;
				isHostName=0;
			}

			if(isHostName) {
				/* create dns */
				if(!createDnsThread(this->otherConnection)) {
					return 0;
				}
			} else {
				this->otherConnection->flags|=CONNECTION_DNS_DONE_PROCESSED;
				if(connectToAddress(this->otherConnection)==INVALID_SOCKETFD) {
					return 0;
				}
			}

			if(isToProxy(this->otherConnection)) {
				/* send auth to other proxy */
				char socksProxyMess[]={SOCKS_PROXY_VER,0,0,0,0,0};
				unsigned int keyn;
				OtherProxy *otherProxy;


				assert(!isProxyKeyOk(this));
				if((otherProxy=getCurrentOtherProxy(this->otherConnection))==NULL) {
					errorLog(this->server,"Not able to find another anon proxy.\n");
					return 0;
				}

				keyn=otherProxy->key;
				memcpy(socksProxyMess+1,&keyn,4);
				debugLog(25,"%x: set anonProxyAuthStrUpto: %i\n",this,this->writeBuf.upto+1);
				this->anonProxyAuthStrUpto=this->writeBuf.upto+1;
				appendWriteBuf(this->otherConnection,socksProxyMess,sizeof(socksProxyMess));
				appendWriteBuf(this->otherConnection,buf,
					(this->currentLine.buf+this->currentLine.upto)-buf);
			}
			break;
		case 2:
			debugLog(10,"%x: socks bind\n",(unsigned int)this);
			this->flags|=CONNECTION_SOCKS_BIND;
			if(isUseAnon(&this->server->anonProxy)
			&& !isProxyKeyOk(this)
			) {
				/*~~~ connect another proxy??? */
			} else {
				/* bind to port */
				if(bindToPort(this->otherConnection)) {
					sendSocksReply(this);
				} else {
					closeConnection(this);
				}
			}
			break;
#if 0
		case 3:
			this->flags|=CONNECTION_SOCKS_UDP;
			break;
#endif
		default:
			errorLog(this->server,"unknown socks cmd: %i\n",buf[1]);
			return 0;
		}

		break;
	}
	}
	clearStringBuf(&this->currentLine);
	return 1;
}


/* skip till zero if needed, used when we didn't receive a zero from the header packet */
void
checkWaitForZero(Connection *this)
{
	StringBuf *writeBuf;
	char *buf,*bufend;

	assert(this!=NULL);
	assert(this->otherConnection!=NULL);
	if(!(this->flags&CONNECTION_SOCKS_WAIT_FOR_ZERO)) {
		return;
	}

	writeBuf=&this->otherConnection->writeBuf;
	buf=writeBuf->buf+writeBuf->readUpto;
	bufend=writeBuf->buf+writeBuf->upto;

	/* still waiting for the first header */
	while(*buf) {
		if(buf>=bufend) {
			debugLog(20,"%x: the socks4 string header has not been read yet\n",(unsigned int)this);
			writeBuf->upto=writeBuf->readUpto;
			return;
		}
		buf++;
	}
	debugLog(20,"%x: skipped zeros: %i\n",(unsigned int)this,(buf-writeBuf->buf)-writeBuf->readUpto);
	writeBuf->upto=buf-writeBuf->buf;
	this->flags&=-1^CONNECTION_SOCKS_WAIT_FOR_ZERO;
}

	
