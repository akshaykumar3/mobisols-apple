
#include "pserver.h"
#include "server.h"
#include "cleancache.h"

/* clean cache *********************************/



static CleanCacheItem *
pushCleanCacheItem(CleanCache *this,const char *filename,struct stat *st)
{
	int num[4];
	const char *p;
	CleanCacheItem *item;

	assert(this!=NULL);
	assert(filename!=NULL);
	assert(st!=NULL);

	if((this->uptoCacheItems+1)>=this->totalCacheItems) {
		this->totalCacheItems+=8196;
		this->cacheItems=realloc(this->cacheItems,sizeof(this->cacheItems[0])*this->totalCacheItems);
	}
	item=this->cacheItems+this->uptoCacheItems;

	item->lastAcc=st->st_atime;
	item->size=st->st_size;
	if((p=strrchr(filename,'/'))==NULL) {
		return NULL;
	}
	num[3]=strtol(p+1,NULL,16);
	if(p>=filename) p--;
	while(p>=filename && *p!='/') { p--; }
	num[2]=strtol(p+1,NULL,16);
	if(p>=filename) p--;
	while(p>=filename && *p!='/') { p--; }
	num[1]=strtol(p+1,NULL,16);
	if(p>=filename) p--;
	while(p>=filename && *p!='/') { p--; }
	num[0]=strtol(p+1,NULL,16);
	if(p==filename) { return NULL; }

	item->fileNum=(num[0]<<16)+(num[1]<<8)+num[2];
	item->fileNum2=num[3];

	this->uptoCacheItems++;

	return item;
}


static CleanCacheDir *
pushCleanCacheDir(CleanCache *this,const char *dirStr)
{
	DIR *dir;
	char dirName[FILENAME_MAX];
	CleanCacheDir *dirStruct;

	assert(this!=NULL);
	assert(dirStr!=NULL);

	if(this->totalDirs==0) {
		assert(this->dirs==NULL);
		this->totalDirs=64;
		this->dirs=pserver_malloc(this->totalDirs*sizeof(this->dirs[0]));
		memset(this->dirs,0,sizeof(this->dirs[0])*this->totalDirs);
	}
	if((this->uptoDirs+1)>=this->totalDirs) {
		errorLog(this->server,"cache directories too deep\n");
		return NULL;
	}
	if(this->uptoDirs==0) { qstrncpy(dirName,dirStr,sizeof(dirName)); }
	else {
		snprintf(dirName,sizeof(dirName),"%s/%s",
			this->dirs[this->uptoDirs-1].dirName,dirStr);
	}
	if((dir=opendir(dirName))==NULL) {
		errorLog(this->server,"problem opening dir: %s, %s\n",dirName,pserver_strerror(errno));
		return NULL;
	}
	dirStruct=this->dirs+this->uptoDirs;
	dirStruct->dir=dir;
	dirStruct->dirName=strdup(dirName);
	this->uptoDirs++;
	return dirStruct;
}

static CleanCacheDir *
popCleanCacheDir(CleanCache *this)
{
	CleanCacheDir *dir;

	assert(this!=NULL);
	assert(this->uptoDirs>0);

	this->uptoDirs--;
	assert(this->dirs[this->uptoDirs].dirName!=NULL);
	dir=this->dirs+this->uptoDirs;
	closedir(dir->dir); dir->dir=NULL;
	free(dir->dirName); dir->dirName=NULL;

	if(this->uptoDirs==0) { return NULL; }
	return this->dirs+this->uptoDirs-1;
}


/* returns: 1=all done, 0=still more to go */
int
findCacheItems(CleanCache *this)
{
	char file[FILENAME_MAX];
	struct CleanCacheDir *dir;
	struct dirent *dirEntry;
	time_t endSec;

	assert(this!=NULL);

	/* go through dirs and find items */
	endSec=time(NULL)+1;
	if(this->uptoDirs==0) {
		if((dir=pushCleanCacheDir(this,"data"))==NULL) {
			return 1;
		}
	} else {
		dir=this->dirs+this->uptoDirs-1;
	}
	debugLog(20,"going through cache for old files, upto: %i\n",this->uptoCacheItems);
	while(1) {
		struct stat st;
		assert(dir!=NULL);

		if(time(NULL)>=endSec) {
			return 0;
		}
		if((dirEntry=readdir(dir->dir))==NULL) {
			/* end of this directory */
			if((dir=popCleanCacheDir(this))==NULL) {
				this->done=1;
				debugLog(5,"found all items in cache\n");
				break; 
			}
			continue;
		}
		/* mingw  returns null for d_name sometimes when nothing is found. */
		if(dirEntry->d_name==NULL) { continue; }
		if(dirEntry->d_name[0]=='.') { continue; }
		snprintf(file,sizeof(file),"%s/%s",
			dir->dirName,dirEntry->d_name);
		if(stat(file,&st)!=0) {
			if(errno!=ENOENT) {
				errorLog(this->server,"Could not stat cache file: %s, %s",file,pserver_strerror(errno));
			}
			debugLog(10,"Could not stat cache file: %s, %s",file,pserver_strerror(errno));
			continue;
		}
		if(S_ISDIR(st.st_mode)) {
			struct CleanCacheDir *d;
			if((d=pushCleanCacheDir(this,dirEntry->d_name))!=NULL) {
				dir=d;
			}
			continue;
		}
		if(pushCleanCacheItem(this,file,&st)!=NULL) {
			this->totalBytes+=st.st_size;
		}
	}
	debugLog(5,"found %i items in cache\n",this->uptoCacheItems);
	return 1;
}

static int
sortCacheItem(const CleanCacheItem *i1,const CleanCacheItem *i2)
{
	return ((int)i2->lastAcc)-((int)i1->lastAcc);
}

int
removeCacheItems(CleanCache *this,LONG_LONG maxBytes)
{
	LONG_LONG bytesToDelete;
	CleanCacheItem *i,*iend;
	int removed=0;

	assert(this!=NULL);
	assert(this->done);

	bytesToDelete=this->totalBytes-maxBytes;
	debugLog(10,"Remove cache items max bytes: %li, deleting oldest: %li bytes\n",maxBytes,bytesToDelete);
	if(bytesToDelete<=0) { 
		debugLog(5,"Nothing to delete from cache: " PRINTF_LONG_LONG " bytes\n",
			this->totalBytes);
		return 0; 
	}
	qsort(this->cacheItems,this->uptoCacheItems,sizeof(this->cacheItems[0]),
		(int (*)(const void *,const void *))sortCacheItem);
	
	iend=this->cacheItems+this->uptoCacheItems;
	for(i=this->cacheItems; bytesToDelete>0 && i<iend; i++) {
		char filename[FILENAME_MAX];
		snprintf(filename,sizeof(filename),"data/%02x/%02x/%02x/%03x",
			(int)((i->fileNum>>16)&0xff),
			(int)((i->fileNum>>8)&0xff),
			(int)((i->fileNum)&0xff),
			(int)i->fileNum2
			);
		debugLog(20,"removing from cache: %s, size:%i\n",filename,i->size);
		if(unlink(filename)==0) {
			bytesToDelete-=i->size;
			removed++;
		} else {
			errorLog(this->server,"Could not remove cache file:%s, %s\n",filename,pserver_strerror(errno));
		}
	}

	return removed;
}

void
clearCleanCache(CleanCache *this)
{
	Server *server;
	assert(this!=NULL);
	if(this->uptoDirs>0) {
		while(popCleanCacheDir(this)!=NULL) {
		}
	}
	FREE_PTR(this->dirs);
	FREE_PTR(this->cacheItems);
	server=this->server;
	memset(this,0,sizeof(this[0]));
	this->server=server;
}


