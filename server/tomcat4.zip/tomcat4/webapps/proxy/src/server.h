#ifndef __SERVER_H
#define __SERVER_H

#include "cleancache.h"
#include "stringbuf.h"
#include "stringcache.h"
#include "usagestats.h"
#include "anonproxy.h"

#if USE_SSL
#include <openssl/ssl.h>
#endif


enum {
	SERVER_SHUTDOWN=0x1
};

typedef struct Server {
	/* config */
	time_t nextConfigFileCheck;
	time_t configFileLoaded;
	char *configFile;

	char *pid_file;
	char *ourUrl;
	char *userAuthCmd;
	unsigned long listenAddr;
	int listenPort;
	time_t nextTimeoutCheck;
	int dataTimeOutSeconds; /* how many seconds before we timeout a connection that we've connected to and are waiting for data to come through */
	int timeOutSeconds;
	int maxCacheMegs;
	int totalDnsRunning;

	int serverFlags;
	struct Connection *shutdownConnection;

	char baseDir[FILENAME_MAX];

	/* logging */
	const char *logFile;
	FILE *errorOut;
	FILE *logFileOut;
	time_t nextLogFileFlush;
	int maxLogFileSize;
	int maxLogRotate;

	/* connections */
	struct Connection *firstConnection;
	int totalConnections;
	SOCKETFD listenSocket;

	/* clean cache */
	time_t nextCleanCache;
	CleanCache cleanCache;

	/* other proxys */
	AnonProxy anonProxy;

	/* access */
	struct Access *accesses;
	int totalAccesses;

	StringCache authenticatedUsers;
	time_t macAddressUpdate;
	StringCache macAddresses;
	StringCache ipAddresses;
	ServerStats webStats;
	ServerStats cachedStats;
	ServerStats nonWebStats; /* socks/https stats */
	ServerStats anonStats;

	unsigned long localhost;
#if USE_SSL
	SSL_CTX *sslCtx;
	SOCKETFD anonListenSocket;
#endif
}Server;


int rotateLogFile(Server *this);
int startServer(Server *this);


#ifndef NDEBUG
void assertServer(Server *this);
#else
#define assertServer(x)
#endif




#endif
