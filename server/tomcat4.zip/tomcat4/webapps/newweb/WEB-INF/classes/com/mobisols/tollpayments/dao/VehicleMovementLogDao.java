package com.mobisols.tollpayments.dao;

public interface VehicleMovementLogDao {

}
