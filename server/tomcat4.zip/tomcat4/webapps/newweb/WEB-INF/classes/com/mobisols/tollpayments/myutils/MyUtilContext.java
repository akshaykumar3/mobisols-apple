package com.mobisols.tollpayments.myutils;

public interface MyUtilContext {

}
