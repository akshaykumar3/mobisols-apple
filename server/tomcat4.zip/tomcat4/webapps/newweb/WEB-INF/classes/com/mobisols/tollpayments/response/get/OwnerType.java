package com.mobisols.tollpayments.response.get;

public class OwnerType {
	private String name;
	private String description;
	
	public OwnerType()
	{

	}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
}