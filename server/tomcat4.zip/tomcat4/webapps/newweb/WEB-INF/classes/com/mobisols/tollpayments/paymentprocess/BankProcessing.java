package com.mobisols.tollpayments.paymentprocess;

class BankProcessing {
	public  int process(String acNumber,String bankName,String branch,Double amount)
	{
		int status=0;
		return status;
	}
}
