package com.mobisols.tollpayments.dao;

import java.util.List;

public interface ServicePlanDao {
	public List getServiceList();
}
