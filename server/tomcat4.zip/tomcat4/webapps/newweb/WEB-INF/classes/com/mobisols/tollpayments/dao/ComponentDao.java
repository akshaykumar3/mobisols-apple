package com.mobisols.tollpayments.dao;

import com.mobisols.tollpayments.model.Component;

public interface ComponentDao {
	public Component getComponent(String name);
}
