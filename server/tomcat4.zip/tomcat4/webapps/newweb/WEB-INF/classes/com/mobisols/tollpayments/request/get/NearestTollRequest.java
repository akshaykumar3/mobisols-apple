package com.mobisols.tollpayments.request.get;

public class NearestTollRequest {

	private double latitude1;
	private double longitude1;
	public double getLatitude1() {
		return latitude1;
	}
	public void setLatitude1(double latitude1) {
		this.latitude1 = latitude1;
	}
	public double getLongitude1() {
		return longitude1;
	}
	public void setLongitude1(double longitude1) {
		this.longitude1 = longitude1;
	}
}
