package com.mobisols.tollpayments.daoImpl;

import com.mobisols.tollpayments.dao.VehicleMovementLogDao;

public class VehicleMovementLogDaoImpl implements VehicleMovementLogDao{

}
