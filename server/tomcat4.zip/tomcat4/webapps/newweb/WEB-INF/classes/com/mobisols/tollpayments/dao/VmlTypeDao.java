package com.mobisols.tollpayments.dao;

import java.util.List;

public interface VmlTypeDao {
	
	public List getVmlTypeList(); 
	public int getVmlTypeId(String name);
}
