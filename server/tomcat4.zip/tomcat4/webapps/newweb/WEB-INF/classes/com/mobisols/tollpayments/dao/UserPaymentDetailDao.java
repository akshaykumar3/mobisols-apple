package com.mobisols.tollpayments.dao;

import com.mobisols.tollpayments.model.UserPaymentDetail;

public interface UserPaymentDetailDao {
	public void save(UserPaymentDetail upd);
}
