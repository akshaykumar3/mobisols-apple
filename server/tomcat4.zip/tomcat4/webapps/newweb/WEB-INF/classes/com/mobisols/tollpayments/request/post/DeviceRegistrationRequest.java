package com.mobisols.tollpayments.request.post;

public class DeviceRegistrationRequest {
	private String deviceName;

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
}
