package com.mobisols.tollpayments.dao;

import com.mobisols.tollpayments.model.VehicleMovementLog;

public interface VmlDao {

	public void save(VehicleMovementLog vml);
}
