package com.mobisols.tollpayments.dao;

public interface UserPaymentDetailHistoryDao {
	public int getLatestUserPaymentDetailHistoryId(int paymentDetailId);
}
