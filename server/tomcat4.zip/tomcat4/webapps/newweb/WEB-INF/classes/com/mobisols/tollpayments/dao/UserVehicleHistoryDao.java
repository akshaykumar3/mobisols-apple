package com.mobisols.tollpayments.dao;

public interface UserVehicleHistoryDao {

	public int getLatestUvhId(int userVehicleId);
}
