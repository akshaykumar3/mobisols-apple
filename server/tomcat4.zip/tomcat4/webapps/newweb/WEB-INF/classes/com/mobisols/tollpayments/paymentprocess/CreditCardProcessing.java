package com.mobisols.tollpayments.paymentprocess;

import java.util.Date;

public class CreditCardProcessing {

	public  int process(String ccNumber,String ccType,Date date,Double amount)
	{
		int status=0;
		return status;
	}
}
