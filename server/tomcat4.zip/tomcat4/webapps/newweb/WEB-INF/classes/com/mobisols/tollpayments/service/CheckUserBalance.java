package com.mobisols.tollpayments.service;

public interface CheckUserBalance {
	
}
