package com.mobisols.tollpayments.response.post;

public class MakeTollPaymentsResponse {

}
