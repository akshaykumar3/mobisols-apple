package com.mobisols.tollpayments.response.get;

public class VmlType {

	private String name;
	private String description;
	
	public VmlType()
	{
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
