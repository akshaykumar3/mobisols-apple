package com.mobisols.tollpayments.dao;

import com.mobisols.tollpayments.model.PaymentTransaction;

public interface PaymentTransactionDao {
	public void save(PaymentTransaction paymentTransaction);
}
